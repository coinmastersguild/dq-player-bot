import{createCanonicalMorphActivity}from"./chunk-kpv6y21e.js";import"./chunk-7jhxxf1p.js";export{createCanonicalMorphActivity};
