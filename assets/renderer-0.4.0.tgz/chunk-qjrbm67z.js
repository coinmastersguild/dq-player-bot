var retirement=Promise.resolve();function acquireNativePreviewLifetime(){let previous=retirement,finish;retirement=new Promise((resolve)=>finish=resolve);let released=!1;return{previous,release(){if(!released)released=!0,finish()}}}var waitForNativePreviewRetirement=()=>retirement;
export{acquireNativePreviewLifetime,waitForNativePreviewRetirement};
