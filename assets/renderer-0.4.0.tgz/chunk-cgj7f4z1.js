import{MORPH_WORKSHOP_CONFIGS,getMorphWorkshopFace}from"./chunk-kfhg1eq2.js";import"./chunk-7jhxxf1p.js";export{getMorphWorkshopFace,MORPH_WORKSHOP_CONFIGS};
