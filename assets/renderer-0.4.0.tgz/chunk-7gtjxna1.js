import{createHighElfFemaleHair}from"./chunk-h2sf9nn8.js";import"./chunk-7jhxxf1p.js";export{createHighElfFemaleHair};
