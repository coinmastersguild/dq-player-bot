export * from "./bodyDeformation.worker-awkr81r9.js";
