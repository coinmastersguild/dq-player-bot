var OGRE_FEMALE_SURFACE_MARKS=Object.freeze({mouthLeft:Object.freeze([[-0.0342372,1.6461361],[-0.0333434,1.6409061],[-0.0307145,1.6347855],[-0.0266765,1.6275216]].map(Object.freeze)),mouthRight:Object.freeze([[0.0301483,1.646514],[0.0335827,1.6398779],[0.0287685,1.6341686],[0.0225666,1.6275362]].map(Object.freeze)),slash:Object.freeze([[0.0081596,1.7527899],[0.0081446,1.7468774],[0.0081178,1.7373869],[0.0074574,1.7295903],[0.005542,1.7030133],[0.0054354,1.6930178],[0.0067437,1.6823419],[0.010659,1.6724625],[0.0138567,1.6632093],[0.0151093,1.65369],[0.0154547,1.6487712]].map(Object.freeze)),chin:Object.freeze([[0.0153131,1.6346673],[0.0160512,1.6293346],[0.0174902,1.6224477]].map(Object.freeze)),mouthRadius:Object.freeze([0.0011,0.0025]),slashRadius:Object.freeze([0.0008,0.0017])}),clamp=(x)=>Math.max(0,Math.min(1,x)),smooth=(a,b,x)=>{let t=clamp((x-a)/(b-a));return t*t*(3-2*t)};function distance(p,a,b){let dx=b[0]-a[0],dy=b[1]-a[1],t=clamp(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy));return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)}function lineMask(p,line,radius){let d=1/0;for(let i=1;i<line.length;i++)d=Math.min(d,distance(p,line[i-1],line[i]));return 1-smooth(...radius,d)}function ogreFemaleSurfaceMarkMasks(position,eligible=1){if(!Array.isArray(position)||position.length!==3||!Array.from(position).every(Number.isFinite)||!Number.isFinite(eligible))throw TypeError("Expected a finite native position and eligibility.");let gate=clamp(eligible)*smooth(0.07,0.078,position[2]),s=OGRE_FEMALE_SURFACE_MARKS;return{mouth:gate*Math.max(lineMask(position,s.mouthLeft,s.mouthRadius),lineMask(position,s.mouthRight,s.mouthRadius)),slash:gate*Math.max(lineMask(position,s.slash,s.slashRadius),lineMask(position,s.chin,s.slashRadius))}}var v=(p)=>`vec2(${p.map((n)=>n.toFixed(7)).join(",")})`,segments=(name,line,radius)=>line.slice(1).map((p,i)=>`${name}=max(${name},1.0-smoothstep(${radius[0].toFixed(7)},${radius[1].toFixed(7)},dqOgreMarkSegment(p.xy,${v(line[i])},${v(p)})));`).join(`
`),OGRE_FEMALE_SURFACE_MARKS_GLSL=`
float dqOgreMarkSegment(vec2 p,vec2 a,vec2 b){vec2 d=b-a;return length(p-a-d*clamp(dot(p-a,d)/dot(d,d),0.0,1.0));}
vec2 dqOgreSurfaceMarkMasks(vec3 p,float eligible){
  float mouth=0.0;float slash=0.0;
  ${segments("mouth",OGRE_FEMALE_SURFACE_MARKS.mouthLeft,OGRE_FEMALE_SURFACE_MARKS.mouthRadius)}
  ${segments("mouth",OGRE_FEMALE_SURFACE_MARKS.mouthRight,OGRE_FEMALE_SURFACE_MARKS.mouthRadius)}
  ${segments("slash",OGRE_FEMALE_SURFACE_MARKS.slash,OGRE_FEMALE_SURFACE_MARKS.slashRadius)}
  ${segments("slash",OGRE_FEMALE_SURFACE_MARKS.chin,OGRE_FEMALE_SURFACE_MARKS.slashRadius)}
  return vec2(mouth,slash)*clamp(eligible,0.0,1.0)*smoothstep(0.070,0.078,p.z);
}
vec3 dqOgreReconstructMarkColor(vec3 sourceColor,vec3 localSkinColor,float mask,float sourceAmount){
  return mix(sourceColor,localSkinColor,clamp(mask,0.0,1.0)*(1.0-clamp(sourceAmount,0.0,1.0)));
}
vec3 dqOgreReconstructMarkNormal(vec3 sourceNormal,float mask,float sourceAmount){
  float amount=clamp(mask,0.0,1.0)*(1.0-clamp(sourceAmount,0.0,1.0));
  if(amount<=0.0)return sourceNormal;
  return normalize(mix(sourceNormal,vec3(0.0,0.0,1.0),amount));
}
`;
export{OGRE_FEMALE_SURFACE_MARKS,ogreFemaleSurfaceMarkMasks,OGRE_FEMALE_SURFACE_MARKS_GLSL};
