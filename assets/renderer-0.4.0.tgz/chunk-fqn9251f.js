function renderPreparationFrame(presentation,renderer){let frame=renderer._nodes?.nodeFrame;if(!frame?.update)throw Error("Graphics preparation frame clock is unavailable");frame.update(),renderer.info.frame=frame.frameId,presentation.render()}
export{renderPreparationFrame};
