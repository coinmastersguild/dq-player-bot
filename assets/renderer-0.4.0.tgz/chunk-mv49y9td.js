import{createFaceIdentityController}from"./chunk-6taymsn2.js";import"./chunk-7jhxxf1p.js";export{createFaceIdentityController};
