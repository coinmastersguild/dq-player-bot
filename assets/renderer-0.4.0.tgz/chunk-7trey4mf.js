import{getRaceIdentityConfig}from"./chunk-y5zb6fae.js";import"./chunk-7jhxxf1p.js";export{getRaceIdentityConfig};
