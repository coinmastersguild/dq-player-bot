async function yieldPreparation(signal){signal.throwIfAborted();let scheduler=globalThis.scheduler;if(scheduler?.yield)await scheduler.yield();else await new Promise((resolve)=>setTimeout(resolve,0));signal.throwIfAborted()}
export{yieldPreparation};
