import{ACESFilmicToneMapping,AddEquation,AddOperation,AdditiveAnimationBlendMode,AdditiveBlending,AgXToneMapping,AlphaFormat,AlwaysCompare,AlwaysDepth,AlwaysStencilFunc,AmbientLight,AnimationAction,AnimationClip,AnimationLoader,AnimationMixer,AnimationObjectGroup,AnimationUtils,ArcCurve,ArrayCamera,ArrowHelper,AttachedBindMode,Audio,AudioAnalyser,AudioContext,AudioListener,AudioLoader,AxesHelper,BackSide,BasicDepthPacking,BasicShadowMap,BatchedMesh,BezierInterpolant,Bone,BooleanKeyframeTrack,Box2,Box3,Box3Helper,BoxGeometry,BoxHelper,BufferAttribute,BufferGeometry,BufferGeometryLoader,ByteType,Cache,Camera,CameraHelper,CanvasTexture,CapsuleGeometry,CatmullRomCurve3,CineonToneMapping,CircleGeometry,ClampToEdgeWrapping,Clock,Color,ColorKeyframeTrack,ColorManagement,Compatibility,CompressedArrayTexture,CompressedCubeTexture,CompressedTexture,CompressedTextureLoader,ConeGeometry,ConstantAlphaFactor,ConstantColorFactor,Controls,CubeCamera,CubeDepthTexture,CubeReflectionMapping,CubeRefractionMapping,CubeTexture,CubeTextureLoader,CubeUVReflectionMapping,CubicBezierCurve,CubicBezierCurve3,CubicInterpolant,CullFaceBack,CullFaceFront,CullFaceFrontBack,CullFaceNone,Curve,CurvePath,CustomBlending,CustomToneMapping,CylinderGeometry,Cylindrical,Data3DTexture,DataArrayTexture,DataTexture,DataTextureLoader,DataUtils,DecrementStencilOp,DecrementWrapStencilOp,DefaultLoadingManager,DepthFormat,DepthStencilFormat,DepthTexture,DetachedBindMode,DirectionalLight,DirectionalLightHelper,DiscreteInterpolant,DodecahedronGeometry,DoubleSide,DstAlphaFactor,DstColorFactor,DynamicCopyUsage,DynamicDrawUsage,DynamicReadUsage,EdgesGeometry,EllipseCurve,EqualCompare,EqualDepth,EqualStencilFunc,EquirectangularReflectionMapping,EquirectangularRefractionMapping,Euler,EventDispatcher,ExternalTexture,ExtrudeGeometry,FileLoader,Float16BufferAttribute,Float32BufferAttribute,FloatType,Fog,FogExp2,FramebufferTexture,FrontSide,Frustum,FrustumArray,GLBufferAttribute,GLSL1,GLSL3,GreaterCompare,GreaterDepth,GreaterEqualCompare,GreaterEqualDepth,GreaterEqualStencilFunc,GreaterStencilFunc,GridHelper,Group,HTMLTexture,HalfFloatType,HemisphereLight,HemisphereLightHelper,IcosahedronGeometry,ImageBitmapLoader,ImageLoader,ImageUtils,IncrementStencilOp,IncrementWrapStencilOp,InstancedBufferAttribute,InstancedBufferGeometry,InstancedInterleavedBuffer,InstancedMesh,Int16BufferAttribute,Int32BufferAttribute,Int8BufferAttribute,IntType,InterleavedBuffer,InterleavedBufferAttribute,Interpolant,InterpolateBezier,InterpolateDiscrete,InterpolateLinear,InterpolateSmooth,InterpolationSamplingMode,InterpolationSamplingType,InvertStencilOp,KeepStencilOp,KeyframeTrack,LOD,LatheGeometry,Layers,LessCompare,LessDepth,LessEqualCompare,LessEqualDepth,LessEqualStencilFunc,LessStencilFunc,Light,LightProbe,Line,Line3,LineBasicMaterial,LineCurve,LineCurve3,LineDashedMaterial,LineLoop,LineSegments,LinearFilter,LinearInterpolant,LinearMipMapLinearFilter,LinearMipMapNearestFilter,LinearMipmapLinearFilter,LinearMipmapNearestFilter,LinearSRGBColorSpace,LinearToneMapping,LinearTransfer,Loader,LoaderUtils,LoadingManager,LoopOnce,LoopPingPong,LoopRepeat,MOUSE,Material,MaterialBlending,MaterialLoader,MathUtils,Matrix2,Matrix3,Matrix4,MaxEquation,Mesh,MeshBasicMaterial,MeshDepthMaterial,MeshDistanceMaterial,MeshLambertMaterial,MeshMatcapMaterial,MeshNormalMaterial,MeshPhongMaterial,MeshPhysicalMaterial,MeshStandardMaterial,MeshToonMaterial,MinEquation,MirroredRepeatWrapping,MixOperation,MultiplyBlending,MultiplyOperation,NearestFilter,NearestMipMapLinearFilter,NearestMipMapNearestFilter,NearestMipmapLinearFilter,NearestMipmapNearestFilter,NeutralToneMapping,NeverCompare,NeverDepth,NeverStencilFunc,NoBlending,NoColorSpace,NoNormalPacking,NoToneMapping,NormalAnimationBlendMode,NormalBlending,NormalGAPacking,NormalRGPacking,NotEqualCompare,NotEqualDepth,NotEqualStencilFunc,NumberKeyframeTrack,Object3D,ObjectLoader,ObjectSpaceNormalMap,OctahedronGeometry,OneFactor,OneMinusConstantAlphaFactor,OneMinusConstantColorFactor,OneMinusDstAlphaFactor,OneMinusDstColorFactor,OneMinusSrcAlphaFactor,OneMinusSrcColorFactor,OrthographicCamera,PCFShadowMap,PCFSoftShadowMap,Path,PerspectiveCamera,Plane,PlaneGeometry,PlaneHelper,PointLight,PointLightHelper,Points,PointsMaterial,PolarGridHelper,PolyhedronGeometry,PositionalAudio,PropertyBinding,PropertyMixer,QuadraticBezierCurve,QuadraticBezierCurve3,Quaternion,QuaternionKeyframeTrack,QuaternionLinearInterpolant,R11_EAC_Format,RAD2DEG,RED_GREEN_RGTC2_Format,RED_RGTC1_Format,REVISION,RG11_EAC_Format,RGBADepthPacking,RGBAFormat,RGBAIntegerFormat,RGBA_ASTC_10x10_Format,RGBA_ASTC_10x5_Format,RGBA_ASTC_10x6_Format,RGBA_ASTC_10x8_Format,RGBA_ASTC_12x10_Format,RGBA_ASTC_12x12_Format,RGBA_ASTC_4x4_Format,RGBA_ASTC_5x4_Format,RGBA_ASTC_5x5_Format,RGBA_ASTC_6x5_Format,RGBA_ASTC_6x6_Format,RGBA_ASTC_8x5_Format,RGBA_ASTC_8x6_Format,RGBA_ASTC_8x8_Format,RGBA_BPTC_Format,RGBA_ETC2_EAC_Format,RGBA_PVRTC_2BPPV1_Format,RGBA_PVRTC_4BPPV1_Format,RGBA_S3TC_DXT1_Format,RGBA_S3TC_DXT3_Format,RGBA_S3TC_DXT5_Format,RGBDepthPacking,RGBFormat,RGBIntegerFormat,RGB_BPTC_SIGNED_Format,RGB_BPTC_UNSIGNED_Format,RGB_ETC1_Format,RGB_ETC2_Format,RGB_PVRTC_2BPPV1_Format,RGB_PVRTC_4BPPV1_Format,RGB_S3TC_DXT1_Format,RGDepthPacking,RGFormat,RGIntegerFormat,RawShaderMaterial,Ray,Raycaster,RectAreaLight,RedFormat,RedIntegerFormat,ReinhardToneMapping,RenderTarget,RenderTarget3D,RepeatWrapping,ReplaceStencilOp,ReverseSubtractEquation,ReversedDepthFuncs,RingGeometry,SIGNED_R11_EAC_Format,SIGNED_RED_GREEN_RGTC2_Format,SIGNED_RED_RGTC1_Format,SIGNED_RG11_EAC_Format,SRGBColorSpace,SRGBTransfer,Scene,ShaderMaterial,ShadowMaterial,Shape,ShapeGeometry,ShapePath,ShapeUtils,ShortType,Skeleton,SkeletonHelper,SkinnedMesh,Source,Sphere,SphereGeometry,Spherical,SphericalHarmonics3,SplineCurve,SpotLight,SpotLightHelper,Sprite,SpriteMaterial,SrcAlphaFactor,SrcAlphaSaturateFactor,SrcColorFactor,StaticCopyUsage,StaticDrawUsage,StaticReadUsage,StereoCamera,StreamCopyUsage,StreamDrawUsage,StreamReadUsage,StringKeyframeTrack,SubtractEquation,SubtractiveBlending,TOUCH,TangentSpaceNormalMap,TetrahedronGeometry,Texture,TextureLoader,TextureUtils,Timer,TimestampQuery,TorusGeometry,TorusKnotGeometry,Triangle,TriangleFanDrawMode,TriangleStripDrawMode,TrianglesDrawMode,TubeGeometry,UVMapping,Uint16BufferAttribute,Uint32BufferAttribute,Uint8BufferAttribute,Uint8ClampedBufferAttribute,Uniform,UniformsGroup,UniformsUtils,UnsignedByteType,UnsignedInt101111Type,UnsignedInt248Type,UnsignedInt5999Type,UnsignedIntType,UnsignedShort4444Type,UnsignedShort5551Type,UnsignedShortType,VSMShadowMap,Vector2,Vector3,Vector4,VectorKeyframeTrack,VideoFrameTexture,VideoTexture,WebGL3DRenderTarget,WebGLArrayRenderTarget,WebGLCoordinateSystem,WebGLRenderTarget,WebGPUCoordinateSystem,WebXRController,WireframeGeometry,WrapAroundEnding,ZeroCurvatureEnding,ZeroFactor,ZeroSlopeEnding,ZeroStencilOp,cloneUniforms,createCanvasElement,createElementNS,error,getByteLength,getConsoleFunction,getUnlitUniformColorSpace,log,mergeUniforms,probeAsync,setConsoleFunction,warn,warnOnce}from"./chunk-pz7tgqgm.js";import{__export}from"./chunk-7jhxxf1p.js";var exports_three_module={};__export(exports_three_module,{warnOnce:()=>warnOnce,warn:()=>warn,setConsoleFunction:()=>setConsoleFunction,log:()=>log,getConsoleFunction:()=>getConsoleFunction,error:()=>error,createCanvasElement:()=>createCanvasElement,ZeroStencilOp:()=>ZeroStencilOp,ZeroSlopeEnding:()=>ZeroSlopeEnding,ZeroFactor:()=>ZeroFactor,ZeroCurvatureEnding:()=>ZeroCurvatureEnding,WrapAroundEnding:()=>WrapAroundEnding,WireframeGeometry:()=>WireframeGeometry,WebXRController:()=>WebXRController,WebGPUCoordinateSystem:()=>WebGPUCoordinateSystem,WebGLUtils:()=>WebGLUtils,WebGLRenderer:()=>WebGLRenderer,WebGLRenderTarget:()=>WebGLRenderTarget,WebGLCubeRenderTarget:()=>WebGLCubeRenderTarget,WebGLCoordinateSystem:()=>WebGLCoordinateSystem,WebGLArrayRenderTarget:()=>WebGLArrayRenderTarget,WebGL3DRenderTarget:()=>WebGL3DRenderTarget,VideoTexture:()=>VideoTexture,VideoFrameTexture:()=>VideoFrameTexture,VectorKeyframeTrack:()=>VectorKeyframeTrack,Vector4:()=>Vector4,Vector3:()=>Vector3,Vector2:()=>Vector2,VSMShadowMap:()=>VSMShadowMap,UnsignedShortType:()=>UnsignedShortType,UnsignedShort5551Type:()=>UnsignedShort5551Type,UnsignedShort4444Type:()=>UnsignedShort4444Type,UnsignedIntType:()=>UnsignedIntType,UnsignedInt5999Type:()=>UnsignedInt5999Type,UnsignedInt248Type:()=>UnsignedInt248Type,UnsignedInt101111Type:()=>UnsignedInt101111Type,UnsignedByteType:()=>UnsignedByteType,UniformsUtils:()=>UniformsUtils,UniformsLib:()=>UniformsLib,UniformsGroup:()=>UniformsGroup,Uniform:()=>Uniform,Uint8ClampedBufferAttribute:()=>Uint8ClampedBufferAttribute,Uint8BufferAttribute:()=>Uint8BufferAttribute,Uint32BufferAttribute:()=>Uint32BufferAttribute,Uint16BufferAttribute:()=>Uint16BufferAttribute,UVMapping:()=>UVMapping,TubeGeometry:()=>TubeGeometry,TrianglesDrawMode:()=>TrianglesDrawMode,TriangleStripDrawMode:()=>TriangleStripDrawMode,TriangleFanDrawMode:()=>TriangleFanDrawMode,Triangle:()=>Triangle,TorusKnotGeometry:()=>TorusKnotGeometry,TorusGeometry:()=>TorusGeometry,TimestampQuery:()=>TimestampQuery,Timer:()=>Timer,TextureUtils:()=>TextureUtils,TextureLoader:()=>TextureLoader,Texture:()=>Texture,TetrahedronGeometry:()=>TetrahedronGeometry,TangentSpaceNormalMap:()=>TangentSpaceNormalMap,TOUCH:()=>TOUCH,SubtractiveBlending:()=>SubtractiveBlending,SubtractEquation:()=>SubtractEquation,StringKeyframeTrack:()=>StringKeyframeTrack,StreamReadUsage:()=>StreamReadUsage,StreamDrawUsage:()=>StreamDrawUsage,StreamCopyUsage:()=>StreamCopyUsage,StereoCamera:()=>StereoCamera,StaticReadUsage:()=>StaticReadUsage,StaticDrawUsage:()=>StaticDrawUsage,StaticCopyUsage:()=>StaticCopyUsage,SrcColorFactor:()=>SrcColorFactor,SrcAlphaSaturateFactor:()=>SrcAlphaSaturateFactor,SrcAlphaFactor:()=>SrcAlphaFactor,SpriteMaterial:()=>SpriteMaterial,Sprite:()=>Sprite,SpotLightHelper:()=>SpotLightHelper,SpotLight:()=>SpotLight,SplineCurve:()=>SplineCurve,SphericalHarmonics3:()=>SphericalHarmonics3,Spherical:()=>Spherical,SphereGeometry:()=>SphereGeometry,Sphere:()=>Sphere,Source:()=>Source,SkinnedMesh:()=>SkinnedMesh,SkeletonHelper:()=>SkeletonHelper,Skeleton:()=>Skeleton,ShortType:()=>ShortType,ShapeUtils:()=>ShapeUtils,ShapePath:()=>ShapePath,ShapeGeometry:()=>ShapeGeometry,Shape:()=>Shape,ShadowMaterial:()=>ShadowMaterial,ShaderMaterial:()=>ShaderMaterial,ShaderLib:()=>ShaderLib,ShaderChunk:()=>ShaderChunk,Scene:()=>Scene,SRGBTransfer:()=>SRGBTransfer,SRGBColorSpace:()=>SRGBColorSpace,SIGNED_RG11_EAC_Format:()=>SIGNED_RG11_EAC_Format,SIGNED_RED_RGTC1_Format:()=>SIGNED_RED_RGTC1_Format,SIGNED_RED_GREEN_RGTC2_Format:()=>SIGNED_RED_GREEN_RGTC2_Format,SIGNED_R11_EAC_Format:()=>SIGNED_R11_EAC_Format,RingGeometry:()=>RingGeometry,ReverseSubtractEquation:()=>ReverseSubtractEquation,ReplaceStencilOp:()=>ReplaceStencilOp,RepeatWrapping:()=>RepeatWrapping,RenderTarget3D:()=>RenderTarget3D,RenderTarget:()=>RenderTarget,ReinhardToneMapping:()=>ReinhardToneMapping,RedIntegerFormat:()=>RedIntegerFormat,RedFormat:()=>RedFormat,RectAreaLight:()=>RectAreaLight,Raycaster:()=>Raycaster,Ray:()=>Ray,RawShaderMaterial:()=>RawShaderMaterial,RGIntegerFormat:()=>RGIntegerFormat,RGFormat:()=>RGFormat,RGDepthPacking:()=>RGDepthPacking,RGB_S3TC_DXT1_Format:()=>RGB_S3TC_DXT1_Format,RGB_PVRTC_4BPPV1_Format:()=>RGB_PVRTC_4BPPV1_Format,RGB_PVRTC_2BPPV1_Format:()=>RGB_PVRTC_2BPPV1_Format,RGB_ETC2_Format:()=>RGB_ETC2_Format,RGB_ETC1_Format:()=>RGB_ETC1_Format,RGB_BPTC_UNSIGNED_Format:()=>RGB_BPTC_UNSIGNED_Format,RGB_BPTC_SIGNED_Format:()=>RGB_BPTC_SIGNED_Format,RGBIntegerFormat:()=>RGBIntegerFormat,RGBFormat:()=>RGBFormat,RGBDepthPacking:()=>RGBDepthPacking,RGBA_S3TC_DXT5_Format:()=>RGBA_S3TC_DXT5_Format,RGBA_S3TC_DXT3_Format:()=>RGBA_S3TC_DXT3_Format,RGBA_S3TC_DXT1_Format:()=>RGBA_S3TC_DXT1_Format,RGBA_PVRTC_4BPPV1_Format:()=>RGBA_PVRTC_4BPPV1_Format,RGBA_PVRTC_2BPPV1_Format:()=>RGBA_PVRTC_2BPPV1_Format,RGBA_ETC2_EAC_Format:()=>RGBA_ETC2_EAC_Format,RGBA_BPTC_Format:()=>RGBA_BPTC_Format,RGBA_ASTC_8x8_Format:()=>RGBA_ASTC_8x8_Format,RGBA_ASTC_8x6_Format:()=>RGBA_ASTC_8x6_Format,RGBA_ASTC_8x5_Format:()=>RGBA_ASTC_8x5_Format,RGBA_ASTC_6x6_Format:()=>RGBA_ASTC_6x6_Format,RGBA_ASTC_6x5_Format:()=>RGBA_ASTC_6x5_Format,RGBA_ASTC_5x5_Format:()=>RGBA_ASTC_5x5_Format,RGBA_ASTC_5x4_Format:()=>RGBA_ASTC_5x4_Format,RGBA_ASTC_4x4_Format:()=>RGBA_ASTC_4x4_Format,RGBA_ASTC_12x12_Format:()=>RGBA_ASTC_12x12_Format,RGBA_ASTC_12x10_Format:()=>RGBA_ASTC_12x10_Format,RGBA_ASTC_10x8_Format:()=>RGBA_ASTC_10x8_Format,RGBA_ASTC_10x6_Format:()=>RGBA_ASTC_10x6_Format,RGBA_ASTC_10x5_Format:()=>RGBA_ASTC_10x5_Format,RGBA_ASTC_10x10_Format:()=>RGBA_ASTC_10x10_Format,RGBAIntegerFormat:()=>RGBAIntegerFormat,RGBAFormat:()=>RGBAFormat,RGBADepthPacking:()=>RGBADepthPacking,RG11_EAC_Format:()=>RG11_EAC_Format,REVISION:()=>REVISION,RED_RGTC1_Format:()=>RED_RGTC1_Format,RED_GREEN_RGTC2_Format:()=>RED_GREEN_RGTC2_Format,R11_EAC_Format:()=>R11_EAC_Format,QuaternionLinearInterpolant:()=>QuaternionLinearInterpolant,QuaternionKeyframeTrack:()=>QuaternionKeyframeTrack,Quaternion:()=>Quaternion,QuadraticBezierCurve3:()=>QuadraticBezierCurve3,QuadraticBezierCurve:()=>QuadraticBezierCurve,PropertyMixer:()=>PropertyMixer,PropertyBinding:()=>PropertyBinding,PositionalAudio:()=>PositionalAudio,PolyhedronGeometry:()=>PolyhedronGeometry,PolarGridHelper:()=>PolarGridHelper,PointsMaterial:()=>PointsMaterial,Points:()=>Points,PointLightHelper:()=>PointLightHelper,PointLight:()=>PointLight,PlaneHelper:()=>PlaneHelper,PlaneGeometry:()=>PlaneGeometry,Plane:()=>Plane,PerspectiveCamera:()=>PerspectiveCamera,Path:()=>Path,PMREMGenerator:()=>PMREMGenerator,PCFSoftShadowMap:()=>PCFSoftShadowMap,PCFShadowMap:()=>PCFShadowMap,OrthographicCamera:()=>OrthographicCamera,OneMinusSrcColorFactor:()=>OneMinusSrcColorFactor,OneMinusSrcAlphaFactor:()=>OneMinusSrcAlphaFactor,OneMinusDstColorFactor:()=>OneMinusDstColorFactor,OneMinusDstAlphaFactor:()=>OneMinusDstAlphaFactor,OneMinusConstantColorFactor:()=>OneMinusConstantColorFactor,OneMinusConstantAlphaFactor:()=>OneMinusConstantAlphaFactor,OneFactor:()=>OneFactor,OctahedronGeometry:()=>OctahedronGeometry,ObjectSpaceNormalMap:()=>ObjectSpaceNormalMap,ObjectLoader:()=>ObjectLoader,Object3D:()=>Object3D,NumberKeyframeTrack:()=>NumberKeyframeTrack,NotEqualStencilFunc:()=>NotEqualStencilFunc,NotEqualDepth:()=>NotEqualDepth,NotEqualCompare:()=>NotEqualCompare,NormalRGPacking:()=>NormalRGPacking,NormalGAPacking:()=>NormalGAPacking,NormalBlending:()=>NormalBlending,NormalAnimationBlendMode:()=>NormalAnimationBlendMode,NoToneMapping:()=>NoToneMapping,NoNormalPacking:()=>NoNormalPacking,NoColorSpace:()=>NoColorSpace,NoBlending:()=>NoBlending,NeverStencilFunc:()=>NeverStencilFunc,NeverDepth:()=>NeverDepth,NeverCompare:()=>NeverCompare,NeutralToneMapping:()=>NeutralToneMapping,NearestMipmapNearestFilter:()=>NearestMipmapNearestFilter,NearestMipmapLinearFilter:()=>NearestMipmapLinearFilter,NearestMipMapNearestFilter:()=>NearestMipMapNearestFilter,NearestMipMapLinearFilter:()=>NearestMipMapLinearFilter,NearestFilter:()=>NearestFilter,MultiplyOperation:()=>MultiplyOperation,MultiplyBlending:()=>MultiplyBlending,MixOperation:()=>MixOperation,MirroredRepeatWrapping:()=>MirroredRepeatWrapping,MinEquation:()=>MinEquation,MeshToonMaterial:()=>MeshToonMaterial,MeshStandardMaterial:()=>MeshStandardMaterial,MeshPhysicalMaterial:()=>MeshPhysicalMaterial,MeshPhongMaterial:()=>MeshPhongMaterial,MeshNormalMaterial:()=>MeshNormalMaterial,MeshMatcapMaterial:()=>MeshMatcapMaterial,MeshLambertMaterial:()=>MeshLambertMaterial,MeshDistanceMaterial:()=>MeshDistanceMaterial,MeshDepthMaterial:()=>MeshDepthMaterial,MeshBasicMaterial:()=>MeshBasicMaterial,Mesh:()=>Mesh,MaxEquation:()=>MaxEquation,Matrix4:()=>Matrix4,Matrix3:()=>Matrix3,Matrix2:()=>Matrix2,MathUtils:()=>MathUtils,MaterialLoader:()=>MaterialLoader,MaterialBlending:()=>MaterialBlending,Material:()=>Material,MOUSE:()=>MOUSE,LoopRepeat:()=>LoopRepeat,LoopPingPong:()=>LoopPingPong,LoopOnce:()=>LoopOnce,LoadingManager:()=>LoadingManager,LoaderUtils:()=>LoaderUtils,Loader:()=>Loader,LinearTransfer:()=>LinearTransfer,LinearToneMapping:()=>LinearToneMapping,LinearSRGBColorSpace:()=>LinearSRGBColorSpace,LinearMipmapNearestFilter:()=>LinearMipmapNearestFilter,LinearMipmapLinearFilter:()=>LinearMipmapLinearFilter,LinearMipMapNearestFilter:()=>LinearMipMapNearestFilter,LinearMipMapLinearFilter:()=>LinearMipMapLinearFilter,LinearInterpolant:()=>LinearInterpolant,LinearFilter:()=>LinearFilter,LineSegments:()=>LineSegments,LineLoop:()=>LineLoop,LineDashedMaterial:()=>LineDashedMaterial,LineCurve3:()=>LineCurve3,LineCurve:()=>LineCurve,LineBasicMaterial:()=>LineBasicMaterial,Line3:()=>Line3,Line:()=>Line,LightProbe:()=>LightProbe,Light:()=>Light,LessStencilFunc:()=>LessStencilFunc,LessEqualStencilFunc:()=>LessEqualStencilFunc,LessEqualDepth:()=>LessEqualDepth,LessEqualCompare:()=>LessEqualCompare,LessDepth:()=>LessDepth,LessCompare:()=>LessCompare,Layers:()=>Layers,LatheGeometry:()=>LatheGeometry,LOD:()=>LOD,KeyframeTrack:()=>KeyframeTrack,KeepStencilOp:()=>KeepStencilOp,InvertStencilOp:()=>InvertStencilOp,InterpolationSamplingType:()=>InterpolationSamplingType,InterpolationSamplingMode:()=>InterpolationSamplingMode,InterpolateSmooth:()=>InterpolateSmooth,InterpolateLinear:()=>InterpolateLinear,InterpolateDiscrete:()=>InterpolateDiscrete,InterpolateBezier:()=>InterpolateBezier,Interpolant:()=>Interpolant,InterleavedBufferAttribute:()=>InterleavedBufferAttribute,InterleavedBuffer:()=>InterleavedBuffer,IntType:()=>IntType,Int8BufferAttribute:()=>Int8BufferAttribute,Int32BufferAttribute:()=>Int32BufferAttribute,Int16BufferAttribute:()=>Int16BufferAttribute,InstancedMesh:()=>InstancedMesh,InstancedInterleavedBuffer:()=>InstancedInterleavedBuffer,InstancedBufferGeometry:()=>InstancedBufferGeometry,InstancedBufferAttribute:()=>InstancedBufferAttribute,IncrementWrapStencilOp:()=>IncrementWrapStencilOp,IncrementStencilOp:()=>IncrementStencilOp,ImageUtils:()=>ImageUtils,ImageLoader:()=>ImageLoader,ImageBitmapLoader:()=>ImageBitmapLoader,IcosahedronGeometry:()=>IcosahedronGeometry,HemisphereLightHelper:()=>HemisphereLightHelper,HemisphereLight:()=>HemisphereLight,HalfFloatType:()=>HalfFloatType,HTMLTexture:()=>HTMLTexture,Group:()=>Group,GridHelper:()=>GridHelper,GreaterStencilFunc:()=>GreaterStencilFunc,GreaterEqualStencilFunc:()=>GreaterEqualStencilFunc,GreaterEqualDepth:()=>GreaterEqualDepth,GreaterEqualCompare:()=>GreaterEqualCompare,GreaterDepth:()=>GreaterDepth,GreaterCompare:()=>GreaterCompare,GLSL3:()=>GLSL3,GLSL1:()=>GLSL1,GLBufferAttribute:()=>GLBufferAttribute,FrustumArray:()=>FrustumArray,Frustum:()=>Frustum,FrontSide:()=>FrontSide,FramebufferTexture:()=>FramebufferTexture,FogExp2:()=>FogExp2,Fog:()=>Fog,FloatType:()=>FloatType,Float32BufferAttribute:()=>Float32BufferAttribute,Float16BufferAttribute:()=>Float16BufferAttribute,FileLoader:()=>FileLoader,ExtrudeGeometry:()=>ExtrudeGeometry,ExternalTexture:()=>ExternalTexture,EventDispatcher:()=>EventDispatcher,Euler:()=>Euler,EquirectangularRefractionMapping:()=>EquirectangularRefractionMapping,EquirectangularReflectionMapping:()=>EquirectangularReflectionMapping,EqualStencilFunc:()=>EqualStencilFunc,EqualDepth:()=>EqualDepth,EqualCompare:()=>EqualCompare,EllipseCurve:()=>EllipseCurve,EdgesGeometry:()=>EdgesGeometry,DynamicReadUsage:()=>DynamicReadUsage,DynamicDrawUsage:()=>DynamicDrawUsage,DynamicCopyUsage:()=>DynamicCopyUsage,DstColorFactor:()=>DstColorFactor,DstAlphaFactor:()=>DstAlphaFactor,DoubleSide:()=>DoubleSide,DodecahedronGeometry:()=>DodecahedronGeometry,DiscreteInterpolant:()=>DiscreteInterpolant,DirectionalLightHelper:()=>DirectionalLightHelper,DirectionalLight:()=>DirectionalLight,DetachedBindMode:()=>DetachedBindMode,DepthTexture:()=>DepthTexture,DepthStencilFormat:()=>DepthStencilFormat,DepthFormat:()=>DepthFormat,DefaultLoadingManager:()=>DefaultLoadingManager,DecrementWrapStencilOp:()=>DecrementWrapStencilOp,DecrementStencilOp:()=>DecrementStencilOp,DataUtils:()=>DataUtils,DataTextureLoader:()=>DataTextureLoader,DataTexture:()=>DataTexture,DataArrayTexture:()=>DataArrayTexture,Data3DTexture:()=>Data3DTexture,Cylindrical:()=>Cylindrical,CylinderGeometry:()=>CylinderGeometry,CustomToneMapping:()=>CustomToneMapping,CustomBlending:()=>CustomBlending,CurvePath:()=>CurvePath,Curve:()=>Curve,CullFaceNone:()=>CullFaceNone,CullFaceFrontBack:()=>CullFaceFrontBack,CullFaceFront:()=>CullFaceFront,CullFaceBack:()=>CullFaceBack,CubicInterpolant:()=>CubicInterpolant,CubicBezierCurve3:()=>CubicBezierCurve3,CubicBezierCurve:()=>CubicBezierCurve,CubeUVReflectionMapping:()=>CubeUVReflectionMapping,CubeTextureLoader:()=>CubeTextureLoader,CubeTexture:()=>CubeTexture,CubeRefractionMapping:()=>CubeRefractionMapping,CubeReflectionMapping:()=>CubeReflectionMapping,CubeDepthTexture:()=>CubeDepthTexture,CubeCamera:()=>CubeCamera,Controls:()=>Controls,ConstantColorFactor:()=>ConstantColorFactor,ConstantAlphaFactor:()=>ConstantAlphaFactor,ConeGeometry:()=>ConeGeometry,CompressedTextureLoader:()=>CompressedTextureLoader,CompressedTexture:()=>CompressedTexture,CompressedCubeTexture:()=>CompressedCubeTexture,CompressedArrayTexture:()=>CompressedArrayTexture,Compatibility:()=>Compatibility,ColorManagement:()=>ColorManagement,ColorKeyframeTrack:()=>ColorKeyframeTrack,Color:()=>Color,Clock:()=>Clock,ClampToEdgeWrapping:()=>ClampToEdgeWrapping,CircleGeometry:()=>CircleGeometry,CineonToneMapping:()=>CineonToneMapping,CatmullRomCurve3:()=>CatmullRomCurve3,CapsuleGeometry:()=>CapsuleGeometry,CanvasTexture:()=>CanvasTexture,CameraHelper:()=>CameraHelper,Camera:()=>Camera,Cache:()=>Cache,ByteType:()=>ByteType,BufferGeometryLoader:()=>BufferGeometryLoader,BufferGeometry:()=>BufferGeometry,BufferAttribute:()=>BufferAttribute,BoxHelper:()=>BoxHelper,BoxGeometry:()=>BoxGeometry,Box3Helper:()=>Box3Helper,Box3:()=>Box3,Box2:()=>Box2,BooleanKeyframeTrack:()=>BooleanKeyframeTrack,Bone:()=>Bone,BezierInterpolant:()=>BezierInterpolant,BatchedMesh:()=>BatchedMesh,BasicShadowMap:()=>BasicShadowMap,BasicDepthPacking:()=>BasicDepthPacking,BackSide:()=>BackSide,AxesHelper:()=>AxesHelper,AudioLoader:()=>AudioLoader,AudioListener:()=>AudioListener,AudioContext:()=>AudioContext,AudioAnalyser:()=>AudioAnalyser,Audio:()=>Audio,AttachedBindMode:()=>AttachedBindMode,ArrowHelper:()=>ArrowHelper,ArrayCamera:()=>ArrayCamera,ArcCurve:()=>ArcCurve,AnimationUtils:()=>AnimationUtils,AnimationObjectGroup:()=>AnimationObjectGroup,AnimationMixer:()=>AnimationMixer,AnimationLoader:()=>AnimationLoader,AnimationClip:()=>AnimationClip,AnimationAction:()=>AnimationAction,AmbientLight:()=>AmbientLight,AlwaysStencilFunc:()=>AlwaysStencilFunc,AlwaysDepth:()=>AlwaysDepth,AlwaysCompare:()=>AlwaysCompare,AlphaFormat:()=>AlphaFormat,AgXToneMapping:()=>AgXToneMapping,AdditiveBlending:()=>AdditiveBlending,AdditiveAnimationBlendMode:()=>AdditiveAnimationBlendMode,AddOperation:()=>AddOperation,AddEquation:()=>AddEquation,ACESFilmicToneMapping:()=>ACESFilmicToneMapping});function WebGLAnimation(){let context=null,isAnimating=!1,animationLoop=null,requestId=null;function onAnimationFrame(time,frame){animationLoop(time,frame),requestId=context.requestAnimationFrame(onAnimationFrame)}return{start:function(){if(isAnimating===!0)return;if(animationLoop===null)return;if(context===null)return;requestId=context.requestAnimationFrame(onAnimationFrame),isAnimating=!0},stop:function(){if(context!==null)context.cancelAnimationFrame(requestId);isAnimating=!1},setAnimationLoop:function(callback){animationLoop=callback},setContext:function(value){context=value}}}function WebGLAttributes(gl){let buffers=new WeakMap;function createBuffer(attribute,bufferType){let{array,usage}=attribute,size=array.byteLength,buffer=gl.createBuffer();gl.bindBuffer(bufferType,buffer),gl.bufferData(bufferType,array,usage),attribute.onUploadCallback();let type;if(array instanceof Float32Array)type=gl.FLOAT;else if(typeof Float16Array<"u"&&array instanceof Float16Array)type=gl.HALF_FLOAT;else if(array instanceof Uint16Array)if(attribute.isFloat16BufferAttribute)type=gl.HALF_FLOAT;else type=gl.UNSIGNED_SHORT;else if(array instanceof Int16Array)type=gl.SHORT;else if(array instanceof Uint32Array)type=gl.UNSIGNED_INT;else if(array instanceof Int32Array)type=gl.INT;else if(array instanceof Int8Array)type=gl.BYTE;else if(array instanceof Uint8Array)type=gl.UNSIGNED_BYTE;else if(array instanceof Uint8ClampedArray)type=gl.UNSIGNED_BYTE;else throw Error("THREE.WebGLAttributes: Unsupported buffer data format: "+array);return{buffer,type,bytesPerElement:array.BYTES_PER_ELEMENT,version:attribute.version,size}}function updateBuffer(buffer,attribute,bufferType){let{array,updateRanges}=attribute;if(gl.bindBuffer(bufferType,buffer),updateRanges.length===0)gl.bufferSubData(bufferType,0,array);else{updateRanges.sort((a,b)=>a.start-b.start);let mergeIndex=0;for(let i=1;i<updateRanges.length;i++){let previousRange=updateRanges[mergeIndex],range=updateRanges[i];if(range.start<=previousRange.start+previousRange.count+1)previousRange.count=Math.max(previousRange.count,range.start+range.count-previousRange.start);else++mergeIndex,updateRanges[mergeIndex]=range}updateRanges.length=mergeIndex+1;for(let i=0,l=updateRanges.length;i<l;i++){let range=updateRanges[i];gl.bufferSubData(bufferType,range.start*array.BYTES_PER_ELEMENT,array,range.start,range.count)}attribute.clearUpdateRanges()}attribute.onUploadCallback()}function get(attribute){if(attribute.isInterleavedBufferAttribute)attribute=attribute.data;return buffers.get(attribute)}function remove(attribute){if(attribute.isInterleavedBufferAttribute)attribute=attribute.data;let data=buffers.get(attribute);if(data)gl.deleteBuffer(data.buffer),buffers.delete(attribute)}function update(attribute,bufferType){if(attribute.isInterleavedBufferAttribute)attribute=attribute.data;if(attribute.isGLBufferAttribute){let cached=buffers.get(attribute);if(!cached||cached.version<attribute.version)buffers.set(attribute,{buffer:attribute.buffer,type:attribute.type,bytesPerElement:attribute.elementSize,version:attribute.version});return}let data=buffers.get(attribute);if(data===void 0)buffers.set(attribute,createBuffer(attribute,bufferType));else if(data.version<attribute.version){if(data.size!==attribute.array.byteLength)throw Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");updateBuffer(data.buffer,attribute,bufferType),data.version=attribute.version}}return{get,remove,update}}var alphahash_fragment=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,displacementmap_pars_vertex=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment="gl_FragColor = linearToOutputTexel( gl_FragColor );",colorspace_pars_fragment=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,envmap_pars_fragment=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_vertex=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,envmap_physical_pars_fragment=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,lights_toon_fragment=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = inverseTransformDirection( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,normalmap_pars_fragment=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,vertex$h=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,fragment$h=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,vertex$g=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fragment$g=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,vertex$f=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fragment$f=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,vertex$e=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,fragment$e=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,vertex$d=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,fragment$d=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,vertex$c=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,fragment$c=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,vertex$b=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,fragment$b=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,vertex$a=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,fragment$a=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vertex$9=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,fragment$9=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vertex$8=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,fragment$8=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vertex$7=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,fragment$7=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,vertex$6=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,fragment$6=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vertex$5=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,fragment$5=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vertex$4=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,fragment$4=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vertex$3=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,fragment$3=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,vertex$2=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,fragment$2=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,vertex$1=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,fragment$1=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ShaderChunk={alphahash_fragment,alphahash_pars_fragment,alphamap_fragment,alphamap_pars_fragment,alphatest_fragment,alphatest_pars_fragment,aomap_fragment,aomap_pars_fragment,batching_pars_vertex,batching_vertex,begin_vertex,beginnormal_vertex,bsdfs,iridescence_fragment,bumpmap_pars_fragment,clipping_planes_fragment,clipping_planes_pars_fragment,clipping_planes_pars_vertex,clipping_planes_vertex,color_fragment,color_pars_fragment,color_pars_vertex,color_vertex,common,cube_uv_reflection_fragment,defaultnormal_vertex,displacementmap_pars_vertex,displacementmap_vertex,emissivemap_fragment,emissivemap_pars_fragment,colorspace_fragment,colorspace_pars_fragment,envmap_fragment,envmap_common_pars_fragment,envmap_pars_fragment,envmap_pars_vertex,envmap_physical_pars_fragment,envmap_vertex,fog_vertex,fog_pars_vertex,fog_fragment,fog_pars_fragment,gradientmap_pars_fragment,lightmap_pars_fragment,lights_lambert_fragment,lights_lambert_pars_fragment,lights_pars_begin,lights_toon_fragment,lights_toon_pars_fragment,lights_phong_fragment,lights_phong_pars_fragment,lights_physical_fragment,lights_physical_pars_fragment,lights_fragment_begin,lights_fragment_maps,lights_fragment_end,lightprobes_pars_fragment,logdepthbuf_fragment,logdepthbuf_pars_fragment,logdepthbuf_pars_vertex,logdepthbuf_vertex,map_fragment,map_pars_fragment,map_particle_fragment,map_particle_pars_fragment,metalnessmap_fragment,metalnessmap_pars_fragment,morphinstance_vertex,morphcolor_vertex,morphnormal_vertex,morphtarget_pars_vertex,morphtarget_vertex,normal_fragment_begin,normal_fragment_maps,normal_pars_fragment,normal_pars_vertex,normal_vertex,normalmap_pars_fragment,clearcoat_normal_fragment_begin,clearcoat_normal_fragment_maps,clearcoat_pars_fragment,iridescence_pars_fragment,opaque_fragment,packing,premultiplied_alpha_fragment,project_vertex,dithering_fragment,dithering_pars_fragment,roughnessmap_fragment,roughnessmap_pars_fragment,shadowmap_pars_fragment,shadowmap_pars_vertex,shadowmap_vertex,shadowmask_pars_fragment,skinbase_vertex,skinning_pars_vertex,skinning_vertex,skinnormal_vertex,specularmap_fragment,specularmap_pars_fragment,tonemapping_fragment,tonemapping_pars_fragment,transmission_fragment,transmission_pars_fragment,uv_pars_fragment,uv_pars_vertex,uv_vertex,worldpos_vertex,background_vert:vertex$h,background_frag:fragment$h,backgroundCube_vert:vertex$g,backgroundCube_frag:fragment$g,cube_vert:vertex$f,cube_frag:fragment$f,depth_vert:vertex$e,depth_frag:fragment$e,distance_vert:vertex$d,distance_frag:fragment$d,equirect_vert:vertex$c,equirect_frag:fragment$c,linedashed_vert:vertex$b,linedashed_frag:fragment$b,meshbasic_vert:vertex$a,meshbasic_frag:fragment$a,meshlambert_vert:vertex$9,meshlambert_frag:fragment$9,meshmatcap_vert:vertex$8,meshmatcap_frag:fragment$8,meshnormal_vert:vertex$7,meshnormal_frag:fragment$7,meshphong_vert:vertex$6,meshphong_frag:fragment$6,meshphysical_vert:vertex$5,meshphysical_frag:fragment$5,meshtoon_vert:vertex$4,meshtoon_frag:fragment$4,points_vert:vertex$3,points_frag:fragment$3,shadow_vert:vertex$2,shadow_frag:fragment$2,sprite_vert:vertex$1,sprite_frag:fragment$1},UniformsLib={common:{diffuse:{value:new Color(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Matrix3},alphaMap:{value:null},alphaMapTransform:{value:new Matrix3},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Matrix3}},envmap:{envMap:{value:null},envMapRotation:{value:new Matrix3},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:0.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Matrix3}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Matrix3}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Matrix3},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Matrix3},normalScale:{value:new Vector2(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Matrix3},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Matrix3}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Matrix3}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Matrix3}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:0.00025},fogNear:{value:1},fogFar:{value:2000},fogColor:{value:new Color(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new Vector3},probesMax:{value:new Vector3},probesResolution:{value:new Vector3}},points:{diffuse:{value:new Color(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Matrix3},alphaTest:{value:0},uvTransform:{value:new Matrix3}},sprite:{diffuse:{value:new Color(16777215)},opacity:{value:1},center:{value:new Vector2(0.5,0.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Matrix3},alphaMap:{value:null},alphaMapTransform:{value:new Matrix3},alphaTest:{value:0}}},ShaderLib={basic:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.specularmap,UniformsLib.envmap,UniformsLib.aomap,UniformsLib.lightmap,UniformsLib.fog]),vertexShader:ShaderChunk.meshbasic_vert,fragmentShader:ShaderChunk.meshbasic_frag},lambert:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.specularmap,UniformsLib.envmap,UniformsLib.aomap,UniformsLib.lightmap,UniformsLib.emissivemap,UniformsLib.bumpmap,UniformsLib.normalmap,UniformsLib.displacementmap,UniformsLib.fog,UniformsLib.lights,{emissive:{value:new Color(0)},envMapIntensity:{value:1}}]),vertexShader:ShaderChunk.meshlambert_vert,fragmentShader:ShaderChunk.meshlambert_frag},phong:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.specularmap,UniformsLib.envmap,UniformsLib.aomap,UniformsLib.lightmap,UniformsLib.emissivemap,UniformsLib.bumpmap,UniformsLib.normalmap,UniformsLib.displacementmap,UniformsLib.fog,UniformsLib.lights,{emissive:{value:new Color(0)},specular:{value:new Color(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ShaderChunk.meshphong_vert,fragmentShader:ShaderChunk.meshphong_frag},standard:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.envmap,UniformsLib.aomap,UniformsLib.lightmap,UniformsLib.emissivemap,UniformsLib.bumpmap,UniformsLib.normalmap,UniformsLib.displacementmap,UniformsLib.roughnessmap,UniformsLib.metalnessmap,UniformsLib.fog,UniformsLib.lights,{emissive:{value:new Color(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ShaderChunk.meshphysical_vert,fragmentShader:ShaderChunk.meshphysical_frag},toon:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.aomap,UniformsLib.lightmap,UniformsLib.emissivemap,UniformsLib.bumpmap,UniformsLib.normalmap,UniformsLib.displacementmap,UniformsLib.gradientmap,UniformsLib.fog,UniformsLib.lights,{emissive:{value:new Color(0)}}]),vertexShader:ShaderChunk.meshtoon_vert,fragmentShader:ShaderChunk.meshtoon_frag},matcap:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.bumpmap,UniformsLib.normalmap,UniformsLib.displacementmap,UniformsLib.fog,{matcap:{value:null}}]),vertexShader:ShaderChunk.meshmatcap_vert,fragmentShader:ShaderChunk.meshmatcap_frag},points:{uniforms:mergeUniforms([UniformsLib.points,UniformsLib.fog]),vertexShader:ShaderChunk.points_vert,fragmentShader:ShaderChunk.points_frag},dashed:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ShaderChunk.linedashed_vert,fragmentShader:ShaderChunk.linedashed_frag},depth:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.displacementmap]),vertexShader:ShaderChunk.depth_vert,fragmentShader:ShaderChunk.depth_frag},normal:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.bumpmap,UniformsLib.normalmap,UniformsLib.displacementmap,{opacity:{value:1}}]),vertexShader:ShaderChunk.meshnormal_vert,fragmentShader:ShaderChunk.meshnormal_frag},sprite:{uniforms:mergeUniforms([UniformsLib.sprite,UniformsLib.fog]),vertexShader:ShaderChunk.sprite_vert,fragmentShader:ShaderChunk.sprite_frag},background:{uniforms:{uvTransform:{value:new Matrix3},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ShaderChunk.background_vert,fragmentShader:ShaderChunk.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Matrix3}},vertexShader:ShaderChunk.backgroundCube_vert,fragmentShader:ShaderChunk.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ShaderChunk.cube_vert,fragmentShader:ShaderChunk.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ShaderChunk.equirect_vert,fragmentShader:ShaderChunk.equirect_frag},distance:{uniforms:mergeUniforms([UniformsLib.common,UniformsLib.displacementmap,{referencePosition:{value:new Vector3},nearDistance:{value:1},farDistance:{value:1000}}]),vertexShader:ShaderChunk.distance_vert,fragmentShader:ShaderChunk.distance_frag},shadow:{uniforms:mergeUniforms([UniformsLib.lights,UniformsLib.fog,{color:{value:new Color(0)},opacity:{value:1}}]),vertexShader:ShaderChunk.shadow_vert,fragmentShader:ShaderChunk.shadow_frag}};ShaderLib.physical={uniforms:mergeUniforms([ShaderLib.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Matrix3},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Matrix3},clearcoatNormalScale:{value:new Vector2(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Matrix3},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Matrix3},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Matrix3},sheen:{value:0},sheenColor:{value:new Color(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Matrix3},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Matrix3},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Matrix3},transmissionSamplerSize:{value:new Vector2},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Matrix3},attenuationDistance:{value:0},attenuationColor:{value:new Color(0)},specularColor:{value:new Color(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Matrix3},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Matrix3},anisotropyVector:{value:new Vector2},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Matrix3}}]),vertexShader:ShaderChunk.meshphysical_vert,fragmentShader:ShaderChunk.meshphysical_frag};var _rgb={r:0,b:0,g:0},_m1$1=new Matrix4,_m$1=new Matrix3;_m$1.set(-1,0,0,0,1,0,0,0,1);function WebGLBackground(renderer,environments,state,objects,alpha,premultipliedAlpha){let clearColor=new Color(0),clearAlpha=alpha===!0?0:1,planeMesh,boxMesh,currentBackground=null,currentBackgroundVersion=0,currentTonemapping=null;function getBackground(scene){let background=scene.isScene===!0?scene.background:null;if(background&&background.isTexture){let usePMREM=scene.backgroundBlurriness>0;background=environments.get(background,usePMREM)}return background}function render(scene){let forceClear=!1,background=getBackground(scene);if(background===null)setClear(clearColor,clearAlpha);else if(background&&background.isColor)setClear(background,1),forceClear=!0;let environmentBlendMode=renderer.xr.getEnvironmentBlendMode();if(environmentBlendMode==="additive")state.buffers.color.setClear(0,0,0,1,premultipliedAlpha);else if(environmentBlendMode==="alpha-blend")state.buffers.color.setClear(0,0,0,0,premultipliedAlpha);if(renderer.autoClear||forceClear)state.buffers.depth.setTest(!0),state.buffers.depth.setMask(!0),state.buffers.color.setMask(!0),renderer.clear(renderer.autoClearColor,renderer.autoClearDepth,renderer.autoClearStencil)}function addToRenderList(renderList,scene){let background=getBackground(scene);if(background&&(background.isCubeTexture||background.mapping===CubeUVReflectionMapping)){if(boxMesh===void 0)boxMesh=new Mesh(new BoxGeometry(1,1,1),new ShaderMaterial({name:"BackgroundCubeMaterial",uniforms:cloneUniforms(ShaderLib.backgroundCube.uniforms),vertexShader:ShaderLib.backgroundCube.vertexShader,fragmentShader:ShaderLib.backgroundCube.fragmentShader,side:BackSide,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),boxMesh.geometry.deleteAttribute("normal"),boxMesh.geometry.deleteAttribute("uv"),boxMesh.onBeforeRender=function(renderer2,scene2,camera){this.matrixWorld.copyPosition(camera.matrixWorld)},Object.defineProperty(boxMesh.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),objects.update(boxMesh);if(boxMesh.material.uniforms.envMap.value=background,boxMesh.material.uniforms.backgroundBlurriness.value=scene.backgroundBlurriness,boxMesh.material.uniforms.backgroundIntensity.value=scene.backgroundIntensity,boxMesh.material.uniforms.backgroundRotation.value.setFromMatrix4(_m1$1.makeRotationFromEuler(scene.backgroundRotation)).transpose(),background.isCubeTexture&&background.isRenderTargetTexture===!1)boxMesh.material.uniforms.backgroundRotation.value.premultiply(_m$1);if(boxMesh.material.toneMapped=ColorManagement.getTransfer(background.colorSpace)!==SRGBTransfer,currentBackground!==background||currentBackgroundVersion!==background.version||currentTonemapping!==renderer.toneMapping)boxMesh.material.needsUpdate=!0,currentBackground=background,currentBackgroundVersion=background.version,currentTonemapping=renderer.toneMapping;boxMesh.layers.enableAll(),renderList.unshift(boxMesh,boxMesh.geometry,boxMesh.material,0,0,null)}else if(background&&background.isTexture){if(planeMesh===void 0)planeMesh=new Mesh(new PlaneGeometry(2,2),new ShaderMaterial({name:"BackgroundMaterial",uniforms:cloneUniforms(ShaderLib.background.uniforms),vertexShader:ShaderLib.background.vertexShader,fragmentShader:ShaderLib.background.fragmentShader,side:FrontSide,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),planeMesh.geometry.deleteAttribute("normal"),Object.defineProperty(planeMesh.material,"map",{get:function(){return this.uniforms.t2D.value}}),objects.update(planeMesh);if(planeMesh.material.uniforms.t2D.value=background,planeMesh.material.uniforms.backgroundIntensity.value=scene.backgroundIntensity,planeMesh.material.toneMapped=ColorManagement.getTransfer(background.colorSpace)!==SRGBTransfer,background.matrixAutoUpdate===!0)background.updateMatrix();if(planeMesh.material.uniforms.uvTransform.value.copy(background.matrix),currentBackground!==background||currentBackgroundVersion!==background.version||currentTonemapping!==renderer.toneMapping)planeMesh.material.needsUpdate=!0,currentBackground=background,currentBackgroundVersion=background.version,currentTonemapping=renderer.toneMapping;planeMesh.layers.enableAll(),renderList.unshift(planeMesh,planeMesh.geometry,planeMesh.material,0,0,null)}}function setClear(color,alpha2){color.getRGB(_rgb,getUnlitUniformColorSpace(renderer)),state.buffers.color.setClear(_rgb.r,_rgb.g,_rgb.b,alpha2,premultipliedAlpha)}function dispose(){if(boxMesh!==void 0)boxMesh.geometry.dispose(),boxMesh.material.dispose(),boxMesh=void 0;if(planeMesh!==void 0)planeMesh.geometry.dispose(),planeMesh.material.dispose(),planeMesh=void 0}return{getClearColor:function(){return clearColor},setClearColor:function(color,alpha2=1){clearColor.set(color),clearAlpha=alpha2,setClear(clearColor,clearAlpha)},getClearAlpha:function(){return clearAlpha},setClearAlpha:function(alpha2){clearAlpha=alpha2,setClear(clearColor,clearAlpha)},render,addToRenderList,dispose}}function WebGLBindingStates(gl,attributes){let maxVertexAttributes=gl.getParameter(gl.MAX_VERTEX_ATTRIBS),bindingStates={},defaultState=createBindingState(null),currentState=defaultState,forceUpdate=!1;function setup(object,material,program,geometry,index){let updateBuffers=!1,state=getBindingState(object,geometry,program,material);if(currentState!==state)currentState=state,bindVertexArrayObject(currentState.object);if(updateBuffers=needsUpdate(object,geometry,program,index),updateBuffers)saveCache(object,geometry,program,index);if(index!==null)attributes.update(index,gl.ELEMENT_ARRAY_BUFFER);if(updateBuffers||forceUpdate){if(forceUpdate=!1,setupVertexAttributes(object,material,program,geometry),index!==null)gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,attributes.get(index).buffer)}}function createVertexArrayObject(){return gl.createVertexArray()}function bindVertexArrayObject(vao){return gl.bindVertexArray(vao)}function deleteVertexArrayObject(vao){return gl.deleteVertexArray(vao)}function getBindingState(object,geometry,program,material){let wireframe=material.wireframe===!0,objectMap=bindingStates[geometry.id];if(objectMap===void 0)objectMap={},bindingStates[geometry.id]=objectMap;let objectId=object.isInstancedMesh===!0?object.id:0,programMap=objectMap[objectId];if(programMap===void 0)programMap={},objectMap[objectId]=programMap;let stateMap=programMap[program.id];if(stateMap===void 0)stateMap={},programMap[program.id]=stateMap;let state=stateMap[wireframe];if(state===void 0)state=createBindingState(createVertexArrayObject()),stateMap[wireframe]=state;return state}function createBindingState(vao){let newAttributes=[],enabledAttributes=[],attributeDivisors=[];for(let i=0;i<maxVertexAttributes;i++)newAttributes[i]=0,enabledAttributes[i]=0,attributeDivisors[i]=0;return{geometry:null,program:null,wireframe:!1,newAttributes,enabledAttributes,attributeDivisors,object:vao,attributes:{},index:null}}function needsUpdate(object,geometry,program,index){let cachedAttributes=currentState.attributes,geometryAttributes=geometry.attributes,attributesNum=0,programAttributes=program.getAttributes();for(let name in programAttributes)if(programAttributes[name].location>=0){let cachedAttribute=cachedAttributes[name],geometryAttribute=geometryAttributes[name];if(geometryAttribute===void 0){if(name==="instanceMatrix"&&object.instanceMatrix)geometryAttribute=object.instanceMatrix;if(name==="instanceColor"&&object.instanceColor)geometryAttribute=object.instanceColor}if(cachedAttribute===void 0)return!0;if(cachedAttribute.attribute!==geometryAttribute)return!0;if(geometryAttribute&&cachedAttribute.data!==geometryAttribute.data)return!0;attributesNum++}if(currentState.attributesNum!==attributesNum)return!0;if(currentState.index!==index)return!0;return!1}function saveCache(object,geometry,program,index){let cache={},attributes2=geometry.attributes,attributesNum=0,programAttributes=program.getAttributes();for(let name in programAttributes)if(programAttributes[name].location>=0){let attribute=attributes2[name];if(attribute===void 0){if(name==="instanceMatrix"&&object.instanceMatrix)attribute=object.instanceMatrix;if(name==="instanceColor"&&object.instanceColor)attribute=object.instanceColor}let data={};if(data.attribute=attribute,attribute&&attribute.data)data.data=attribute.data;cache[name]=data,attributesNum++}currentState.attributes=cache,currentState.attributesNum=attributesNum,currentState.index=index}function initAttributes(){let newAttributes=currentState.newAttributes;for(let i=0,il=newAttributes.length;i<il;i++)newAttributes[i]=0}function enableAttribute(attribute){enableAttributeAndDivisor(attribute,0)}function enableAttributeAndDivisor(attribute,meshPerAttribute){let{newAttributes,enabledAttributes,attributeDivisors}=currentState;if(newAttributes[attribute]=1,enabledAttributes[attribute]===0)gl.enableVertexAttribArray(attribute),enabledAttributes[attribute]=1;if(attributeDivisors[attribute]!==meshPerAttribute)gl.vertexAttribDivisor(attribute,meshPerAttribute),attributeDivisors[attribute]=meshPerAttribute}function disableUnusedAttributes(){let{newAttributes,enabledAttributes}=currentState;for(let i=0,il=enabledAttributes.length;i<il;i++)if(enabledAttributes[i]!==newAttributes[i])gl.disableVertexAttribArray(i),enabledAttributes[i]=0}function vertexAttribPointer(index,size,type,normalized,stride,offset,integer){if(integer===!0)gl.vertexAttribIPointer(index,size,type,stride,offset);else gl.vertexAttribPointer(index,size,type,normalized,stride,offset)}function setupVertexAttributes(object,material,program,geometry){initAttributes();let geometryAttributes=geometry.attributes,programAttributes=program.getAttributes(),materialDefaultAttributeValues=material.defaultAttributeValues;for(let name in programAttributes){let programAttribute=programAttributes[name];if(programAttribute.location>=0){let geometryAttribute=geometryAttributes[name];if(geometryAttribute===void 0){if(name==="instanceMatrix"&&object.instanceMatrix)geometryAttribute=object.instanceMatrix;if(name==="instanceColor"&&object.instanceColor)geometryAttribute=object.instanceColor}if(geometryAttribute!==void 0){let{normalized,itemSize:size}=geometryAttribute,attribute=attributes.get(geometryAttribute);if(attribute===void 0)continue;let{buffer,type,bytesPerElement}=attribute,integer=type===gl.INT||type===gl.UNSIGNED_INT||geometryAttribute.gpuType===IntType;if(geometryAttribute.isInterleavedBufferAttribute){let data=geometryAttribute.data,stride=data.stride,offset=geometryAttribute.offset;if(data.isInstancedInterleavedBuffer){for(let i=0;i<programAttribute.locationSize;i++)enableAttributeAndDivisor(programAttribute.location+i,data.meshPerAttribute);if(object.isInstancedMesh!==!0&&geometry._maxInstanceCount===void 0)geometry._maxInstanceCount=data.meshPerAttribute*data.count}else for(let i=0;i<programAttribute.locationSize;i++)enableAttribute(programAttribute.location+i);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);for(let i=0;i<programAttribute.locationSize;i++)vertexAttribPointer(programAttribute.location+i,size/programAttribute.locationSize,type,normalized,stride*bytesPerElement,(offset+size/programAttribute.locationSize*i)*bytesPerElement,integer)}else{if(geometryAttribute.isInstancedBufferAttribute){for(let i=0;i<programAttribute.locationSize;i++)enableAttributeAndDivisor(programAttribute.location+i,geometryAttribute.meshPerAttribute);if(object.isInstancedMesh!==!0&&geometry._maxInstanceCount===void 0)geometry._maxInstanceCount=geometryAttribute.meshPerAttribute*geometryAttribute.count}else for(let i=0;i<programAttribute.locationSize;i++)enableAttribute(programAttribute.location+i);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);for(let i=0;i<programAttribute.locationSize;i++)vertexAttribPointer(programAttribute.location+i,size/programAttribute.locationSize,type,normalized,size*bytesPerElement,size/programAttribute.locationSize*i*bytesPerElement,integer)}}else if(materialDefaultAttributeValues!==void 0){let value=materialDefaultAttributeValues[name];if(value!==void 0)switch(value.length){case 2:gl.vertexAttrib2fv(programAttribute.location,value);break;case 3:gl.vertexAttrib3fv(programAttribute.location,value);break;case 4:gl.vertexAttrib4fv(programAttribute.location,value);break;default:gl.vertexAttrib1fv(programAttribute.location,value)}}}}disableUnusedAttributes()}function dispose(){reset();for(let geometryId in bindingStates){let objectMap=bindingStates[geometryId];for(let objectId in objectMap){let programMap=objectMap[objectId];for(let programId in programMap){let stateMap=programMap[programId];for(let wireframe in stateMap)deleteVertexArrayObject(stateMap[wireframe].object),delete stateMap[wireframe];delete programMap[programId]}}delete bindingStates[geometryId]}}function releaseStatesOfGeometry(geometry){if(bindingStates[geometry.id]===void 0)return;let objectMap=bindingStates[geometry.id];for(let objectId in objectMap){let programMap=objectMap[objectId];for(let programId in programMap){let stateMap=programMap[programId];for(let wireframe in stateMap)deleteVertexArrayObject(stateMap[wireframe].object),delete stateMap[wireframe];delete programMap[programId]}}delete bindingStates[geometry.id]}function releaseStatesOfProgram(program){for(let geometryId in bindingStates){let objectMap=bindingStates[geometryId];for(let objectId in objectMap){let programMap=objectMap[objectId];if(programMap[program.id]===void 0)continue;let stateMap=programMap[program.id];for(let wireframe in stateMap)deleteVertexArrayObject(stateMap[wireframe].object),delete stateMap[wireframe];delete programMap[program.id]}}}function releaseStatesOfObject(object){for(let geometryId in bindingStates){let objectMap=bindingStates[geometryId],objectId=object.isInstancedMesh===!0?object.id:0,programMap=objectMap[objectId];if(programMap===void 0)continue;for(let programId in programMap){let stateMap=programMap[programId];for(let wireframe in stateMap)deleteVertexArrayObject(stateMap[wireframe].object),delete stateMap[wireframe];delete programMap[programId]}if(delete objectMap[objectId],Object.keys(objectMap).length===0)delete bindingStates[geometryId]}}function reset(){if(resetDefaultState(),forceUpdate=!0,currentState===defaultState)return;currentState=defaultState,bindVertexArrayObject(currentState.object)}function resetDefaultState(){defaultState.geometry=null,defaultState.program=null,defaultState.wireframe=!1}return{setup,reset,resetDefaultState,dispose,releaseStatesOfGeometry,releaseStatesOfObject,releaseStatesOfProgram,initAttributes,enableAttribute,disableUnusedAttributes}}function WebGLBufferRenderer(gl,extensions,info){let mode;function setMode(value){mode=value}function render(start,count){gl.drawArrays(mode,start,count),info.update(count,mode,1)}function renderInstances(start,count,primcount){if(primcount===0)return;gl.drawArraysInstanced(mode,start,count,primcount),info.update(count,mode,primcount)}function renderMultiDraw(starts,counts,drawCount){if(drawCount===0)return;extensions.get("WEBGL_multi_draw").multiDrawArraysWEBGL(mode,starts,0,counts,0,drawCount);let elementCount=0;for(let i=0;i<drawCount;i++)elementCount+=counts[i];info.update(elementCount,mode,1)}this.setMode=setMode,this.render=render,this.renderInstances=renderInstances,this.renderMultiDraw=renderMultiDraw}function WebGLCapabilities(gl,extensions,parameters,utils){let maxAnisotropy;function getMaxAnisotropy(){if(maxAnisotropy!==void 0)return maxAnisotropy;if(extensions.has("EXT_texture_filter_anisotropic")===!0){let extension=extensions.get("EXT_texture_filter_anisotropic");maxAnisotropy=gl.getParameter(extension.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else maxAnisotropy=0;return maxAnisotropy}function textureFormatReadable(textureFormat){if(textureFormat!==RGBAFormat&&utils.convert(textureFormat)!==gl.getParameter(gl.IMPLEMENTATION_COLOR_READ_FORMAT))return!1;return!0}function textureTypeReadable(textureType){let halfFloatSupportedByExt=textureType===HalfFloatType&&(extensions.has("EXT_color_buffer_half_float")||extensions.has("EXT_color_buffer_float"));if(textureType!==UnsignedByteType&&utils.convert(textureType)!==gl.getParameter(gl.IMPLEMENTATION_COLOR_READ_TYPE)&&textureType!==FloatType&&!halfFloatSupportedByExt)return!1;return!0}function getMaxPrecision(precision2){if(precision2==="highp"){if(gl.getShaderPrecisionFormat(gl.VERTEX_SHADER,gl.HIGH_FLOAT).precision>0&&gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER,gl.HIGH_FLOAT).precision>0)return"highp";precision2="mediump"}if(precision2==="mediump"){if(gl.getShaderPrecisionFormat(gl.VERTEX_SHADER,gl.MEDIUM_FLOAT).precision>0&&gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER,gl.MEDIUM_FLOAT).precision>0)return"mediump"}return"lowp"}let precision=parameters.precision!==void 0?parameters.precision:"highp",maxPrecision=getMaxPrecision(precision);if(maxPrecision!==precision)warn("WebGLRenderer:",precision,"not supported, using",maxPrecision,"instead."),precision=maxPrecision;let logarithmicDepthBuffer=parameters.logarithmicDepthBuffer===!0,reversedDepthBuffer=parameters.reversedDepthBuffer===!0&&extensions.has("EXT_clip_control");if(parameters.reversedDepthBuffer===!0&&reversedDepthBuffer===!1)warn("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");let maxTextures=gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS),maxVertexTextures=gl.getParameter(gl.MAX_VERTEX_TEXTURE_IMAGE_UNITS),maxTextureSize=gl.getParameter(gl.MAX_TEXTURE_SIZE),maxCubemapSize=gl.getParameter(gl.MAX_CUBE_MAP_TEXTURE_SIZE),maxAttributes=gl.getParameter(gl.MAX_VERTEX_ATTRIBS),maxVertexUniforms=gl.getParameter(gl.MAX_VERTEX_UNIFORM_VECTORS),maxVaryings=gl.getParameter(gl.MAX_VARYING_VECTORS),maxFragmentUniforms=gl.getParameter(gl.MAX_FRAGMENT_UNIFORM_VECTORS),maxSamples=gl.getParameter(gl.MAX_SAMPLES),samples=gl.getParameter(gl.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy,getMaxPrecision,textureFormatReadable,textureTypeReadable,precision,logarithmicDepthBuffer,reversedDepthBuffer,maxTextures,maxVertexTextures,maxTextureSize,maxCubemapSize,maxAttributes,maxVertexUniforms,maxVaryings,maxFragmentUniforms,maxSamples,samples}}function WebGLClipping(properties){let scope=this,globalState=null,numGlobalPlanes=0,localClippingEnabled=!1,renderingShadows=!1,plane=new Plane,viewNormalMatrix=new Matrix3,uniform={value:null,needsUpdate:!1};this.uniform=uniform,this.numPlanes=0,this.numIntersection=0,this.init=function(planes,enableLocalClipping){let enabled=planes.length!==0||enableLocalClipping||numGlobalPlanes!==0||localClippingEnabled;return localClippingEnabled=enableLocalClipping,numGlobalPlanes=planes.length,enabled},this.beginShadows=function(){renderingShadows=!0,projectPlanes(null)},this.endShadows=function(){renderingShadows=!1},this.setGlobalState=function(planes,camera){globalState=projectPlanes(planes,camera,0)},this.setState=function(material,camera,useCache){let{clippingPlanes:planes,clipIntersection,clipShadows}=material,materialProperties=properties.get(material);if(!localClippingEnabled||planes===null||planes.length===0||renderingShadows&&!clipShadows)if(renderingShadows)projectPlanes(null);else resetGlobalState();else{let nGlobal=renderingShadows?0:numGlobalPlanes,lGlobal=nGlobal*4,dstArray=materialProperties.clippingState||null;uniform.value=dstArray,dstArray=projectPlanes(planes,camera,lGlobal,useCache);for(let i=0;i!==lGlobal;++i)dstArray[i]=globalState[i];materialProperties.clippingState=dstArray,this.numIntersection=clipIntersection?this.numPlanes:0,this.numPlanes+=nGlobal}};function resetGlobalState(){if(uniform.value!==globalState)uniform.value=globalState,uniform.needsUpdate=numGlobalPlanes>0;scope.numPlanes=numGlobalPlanes,scope.numIntersection=0}function projectPlanes(planes,camera,dstOffset,skipTransform){let nPlanes=planes!==null?planes.length:0,dstArray=null;if(nPlanes!==0){if(dstArray=uniform.value,skipTransform!==!0||dstArray===null){let flatSize=dstOffset+nPlanes*4,viewMatrix=camera.matrixWorldInverse;if(viewNormalMatrix.getNormalMatrix(viewMatrix),dstArray===null||dstArray.length<flatSize)dstArray=new Float32Array(flatSize);for(let i=0,i4=dstOffset;i!==nPlanes;++i,i4+=4)plane.copy(planes[i]).applyMatrix4(viewMatrix,viewNormalMatrix),plane.normal.toArray(dstArray,i4),dstArray[i4+3]=plane.constant}uniform.value=dstArray,uniform.needsUpdate=!0}return scope.numPlanes=nPlanes,scope.numIntersection=0,dstArray}}var LOD_MIN=4,EXTRA_LOD_SIGMA=[0.125,0.215,0.35,0.446,0.526,0.582],MAX_SAMPLES=20,GGX_SAMPLES=256,_flatCamera=new OrthographicCamera,_clearColor=new Color,_oldTarget=null,_oldActiveCubeFace=0,_oldActiveMipmapLevel=0,_oldXrEnabled=!1,_origin=new Vector3;class PMREMGenerator{constructor(renderer){this._renderer=renderer,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(scene,sigma=0,near=0.1,far=100,options={}){let{size=256,position=_origin}=options;_oldTarget=this._renderer.getRenderTarget(),_oldActiveCubeFace=this._renderer.getActiveCubeFace(),_oldActiveMipmapLevel=this._renderer.getActiveMipmapLevel(),_oldXrEnabled=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(size);let cubeUVRenderTarget=this._allocateTargets();if(cubeUVRenderTarget.depthBuffer=!0,this._sceneToCubeUV(scene,near,far,cubeUVRenderTarget,position),sigma>0)this._blur(cubeUVRenderTarget,0,0,sigma);return this._applyPMREM(cubeUVRenderTarget),this._cleanup(cubeUVRenderTarget),cubeUVRenderTarget}fromEquirectangular(equirectangular,renderTarget=null){return this._fromTexture(equirectangular,renderTarget)}fromCubemap(cubemap,renderTarget=null){return this._fromTexture(cubemap,renderTarget)}compileCubemapShader(){if(this._cubemapMaterial===null)this._cubemapMaterial=_getCubemapMaterial(),this._compileMaterial(this._cubemapMaterial)}compileEquirectangularShader(){if(this._equirectMaterial===null)this._equirectMaterial=_getEquirectMaterial(),this._compileMaterial(this._equirectMaterial)}dispose(){if(this._dispose(),this._cubemapMaterial!==null)this._cubemapMaterial.dispose();if(this._equirectMaterial!==null)this._equirectMaterial.dispose();if(this._backgroundBox!==null)this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose()}_setSize(cubeSize){this._lodMax=Math.floor(Math.log2(cubeSize)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){if(this._blurMaterial!==null)this._blurMaterial.dispose();if(this._ggxMaterial!==null)this._ggxMaterial.dispose();if(this._pingPongRenderTarget!==null)this._pingPongRenderTarget.dispose();for(let i=0;i<this._lodMeshes.length;i++)this._lodMeshes[i].geometry.dispose()}_cleanup(outputTarget){this._renderer.setRenderTarget(_oldTarget,_oldActiveCubeFace,_oldActiveMipmapLevel),this._renderer.xr.enabled=_oldXrEnabled,outputTarget.scissorTest=!1,_setViewport(outputTarget,0,0,outputTarget.width,outputTarget.height)}_fromTexture(texture,renderTarget){if(texture.mapping===CubeReflectionMapping||texture.mapping===CubeRefractionMapping)this._setSize(texture.image.length===0?16:texture.image[0].width||texture.image[0].image.width);else this._setSize(texture.image.width/4);_oldTarget=this._renderer.getRenderTarget(),_oldActiveCubeFace=this._renderer.getActiveCubeFace(),_oldActiveMipmapLevel=this._renderer.getActiveMipmapLevel(),_oldXrEnabled=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let cubeUVRenderTarget=renderTarget||this._allocateTargets();return this._textureToCubeUV(texture,cubeUVRenderTarget),this._applyPMREM(cubeUVRenderTarget),this._cleanup(cubeUVRenderTarget),cubeUVRenderTarget}_allocateTargets(){let width=3*Math.max(this._cubeSize,112),height=4*this._cubeSize,params={magFilter:LinearFilter,minFilter:LinearFilter,generateMipmaps:!1,type:HalfFloatType,format:RGBAFormat,colorSpace:LinearSRGBColorSpace,depthBuffer:!1},cubeUVRenderTarget=_createRenderTarget(width,height,params);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==width||this._pingPongRenderTarget.height!==height){if(this._pingPongRenderTarget!==null)this._dispose();this._pingPongRenderTarget=_createRenderTarget(width,height,params);let{_lodMax}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=_createPlanes(_lodMax)),this._blurMaterial=_getBlurShader(_lodMax,width,height),this._ggxMaterial=_getGGXShader(_lodMax,width,height)}return cubeUVRenderTarget}_compileMaterial(material){let mesh=new Mesh(new BufferGeometry,material);this._renderer.compile(mesh,_flatCamera)}_sceneToCubeUV(scene,near,far,cubeUVRenderTarget,position){let cubeCamera=new PerspectiveCamera(90,1,near,far),upSign=[1,-1,1,1,1,1],forwardSign=[1,1,1,-1,-1,-1],renderer=this._renderer,originalAutoClear=renderer.autoClear,toneMapping=renderer.toneMapping;if(renderer.getClearColor(_clearColor),renderer.toneMapping=NoToneMapping,renderer.autoClear=!1,renderer.state.buffers.depth.getReversed())renderer.setRenderTarget(cubeUVRenderTarget),renderer.clearDepth(),renderer.setRenderTarget(null);if(this._backgroundBox===null)this._backgroundBox=new Mesh(new BoxGeometry,new MeshBasicMaterial({name:"PMREM.Background",side:BackSide,depthWrite:!1,depthTest:!1}));let backgroundBox=this._backgroundBox,backgroundMaterial=backgroundBox.material,useSolidColor=!1,background=scene.background;if(background){if(background.isColor)backgroundMaterial.color.copy(background),scene.background=null,useSolidColor=!0}else backgroundMaterial.color.copy(_clearColor),useSolidColor=!0;for(let i=0;i<6;i++){let col=i%3;if(col===0)cubeCamera.up.set(0,upSign[i],0),cubeCamera.position.set(position.x,position.y,position.z),cubeCamera.lookAt(position.x+forwardSign[i],position.y,position.z);else if(col===1)cubeCamera.up.set(0,0,upSign[i]),cubeCamera.position.set(position.x,position.y,position.z),cubeCamera.lookAt(position.x,position.y+forwardSign[i],position.z);else cubeCamera.up.set(0,upSign[i],0),cubeCamera.position.set(position.x,position.y,position.z),cubeCamera.lookAt(position.x,position.y,position.z+forwardSign[i]);let size=this._cubeSize;if(_setViewport(cubeUVRenderTarget,col*size,i>2?size:0,size,size),renderer.setRenderTarget(cubeUVRenderTarget),useSolidColor)renderer.render(backgroundBox,cubeCamera);renderer.render(scene,cubeCamera)}renderer.toneMapping=toneMapping,renderer.autoClear=originalAutoClear,scene.background=background}_textureToCubeUV(texture,cubeUVRenderTarget){let renderer=this._renderer,isCubeTexture=texture.mapping===CubeReflectionMapping||texture.mapping===CubeRefractionMapping;if(isCubeTexture){if(this._cubemapMaterial===null)this._cubemapMaterial=_getCubemapMaterial();this._cubemapMaterial.uniforms.flipEnvMap.value=texture.isRenderTargetTexture===!1?-1:1}else if(this._equirectMaterial===null)this._equirectMaterial=_getEquirectMaterial();let material=isCubeTexture?this._cubemapMaterial:this._equirectMaterial,mesh=this._lodMeshes[0];mesh.material=material;let uniforms=material.uniforms;uniforms.envMap.value=texture;let size=this._cubeSize;_setViewport(cubeUVRenderTarget,0,0,3*size,2*size),renderer.setRenderTarget(cubeUVRenderTarget),renderer.render(mesh,_flatCamera)}_applyPMREM(cubeUVRenderTarget){let renderer=this._renderer,autoClear=renderer.autoClear;renderer.autoClear=!1;let n=this._lodMeshes.length;for(let i=1;i<n;i++)this._applyGGXFilter(cubeUVRenderTarget,i-1,i);renderer.autoClear=autoClear}_applyGGXFilter(cubeUVRenderTarget,lodIn,lodOut){let renderer=this._renderer,pingPongRenderTarget=this._pingPongRenderTarget,ggxMaterial=this._ggxMaterial,ggxMesh=this._lodMeshes[lodOut];ggxMesh.material=ggxMaterial;let ggxUniforms=ggxMaterial.uniforms,targetRoughness=lodOut/(this._lodMeshes.length-1),sourceRoughness=lodIn/(this._lodMeshes.length-1),incrementalRoughness=Math.sqrt(targetRoughness*targetRoughness-sourceRoughness*sourceRoughness),blurStrength=0+targetRoughness*1.25,adjustedRoughness=incrementalRoughness*blurStrength,{_lodMax}=this,outputSize=this._sizeLods[lodOut],x=3*outputSize*(lodOut>_lodMax-LOD_MIN?lodOut-_lodMax+LOD_MIN:0),y=4*(this._cubeSize-outputSize);ggxUniforms.envMap.value=cubeUVRenderTarget.texture,ggxUniforms.roughness.value=adjustedRoughness,ggxUniforms.mipInt.value=_lodMax-lodIn,_setViewport(pingPongRenderTarget,x,y,3*outputSize,2*outputSize),renderer.setRenderTarget(pingPongRenderTarget),renderer.render(ggxMesh,_flatCamera),ggxUniforms.envMap.value=pingPongRenderTarget.texture,ggxUniforms.roughness.value=0,ggxUniforms.mipInt.value=_lodMax-lodOut,_setViewport(cubeUVRenderTarget,x,y,3*outputSize,2*outputSize),renderer.setRenderTarget(cubeUVRenderTarget),renderer.render(ggxMesh,_flatCamera)}_blur(cubeUVRenderTarget,lodIn,lodOut,sigma,poleAxis){let pingPongRenderTarget=this._pingPongRenderTarget;this._halfBlur(cubeUVRenderTarget,pingPongRenderTarget,lodIn,lodOut,sigma,"latitudinal",poleAxis),this._halfBlur(pingPongRenderTarget,cubeUVRenderTarget,lodOut,lodOut,sigma,"longitudinal",poleAxis)}_halfBlur(targetIn,targetOut,lodIn,lodOut,sigmaRadians,direction,poleAxis){let renderer=this._renderer,blurMaterial=this._blurMaterial;if(direction!=="latitudinal"&&direction!=="longitudinal")error("blur direction must be either latitudinal or longitudinal!");let STANDARD_DEVIATIONS=3,blurMesh=this._lodMeshes[lodOut];blurMesh.material=blurMaterial;let blurUniforms=blurMaterial.uniforms,pixels=this._sizeLods[lodIn]-1,radiansPerPixel=isFinite(sigmaRadians)?Math.PI/(2*pixels):2*Math.PI/(2*MAX_SAMPLES-1),sigmaPixels=sigmaRadians/radiansPerPixel,samples=isFinite(sigmaRadians)?1+Math.floor(STANDARD_DEVIATIONS*sigmaPixels):MAX_SAMPLES;if(samples>MAX_SAMPLES)warn(`sigmaRadians, ${sigmaRadians}, is too large and will clip, as it requested ${samples} samples when the maximum is set to ${MAX_SAMPLES}`);let weights=[],sum=0;for(let i=0;i<MAX_SAMPLES;++i){let x2=i/sigmaPixels,weight=Math.exp(-x2*x2/2);if(weights.push(weight),i===0)sum+=weight;else if(i<samples)sum+=2*weight}for(let i=0;i<weights.length;i++)weights[i]=weights[i]/sum;if(blurUniforms.envMap.value=targetIn.texture,blurUniforms.samples.value=samples,blurUniforms.weights.value=weights,blurUniforms.latitudinal.value=direction==="latitudinal",poleAxis)blurUniforms.poleAxis.value=poleAxis;let{_lodMax}=this;blurUniforms.dTheta.value=radiansPerPixel,blurUniforms.mipInt.value=_lodMax-lodIn;let outputSize=this._sizeLods[lodOut],x=3*outputSize*(lodOut>_lodMax-LOD_MIN?lodOut-_lodMax+LOD_MIN:0),y=4*(this._cubeSize-outputSize);_setViewport(targetOut,x,y,3*outputSize,2*outputSize),renderer.setRenderTarget(targetOut),renderer.render(blurMesh,_flatCamera)}}function _createPlanes(lodMax){let sizeLods=[],sigmas=[],lodMeshes=[],lod=lodMax,totalLods=lodMax-LOD_MIN+1+EXTRA_LOD_SIGMA.length;for(let i=0;i<totalLods;i++){let sizeLod=Math.pow(2,lod);sizeLods.push(sizeLod);let sigma=1/sizeLod;if(i>lodMax-LOD_MIN)sigma=EXTRA_LOD_SIGMA[i-lodMax+LOD_MIN-1];else if(i===0)sigma=0;sigmas.push(sigma);let texelSize=1/(sizeLod-2),min=-texelSize,max=1+texelSize,uv1=[min,min,max,min,max,max,min,min,max,max,min,max],cubeFaces=6,vertices=6,positionSize=3,uvSize=2,faceIndexSize=1,position=new Float32Array(positionSize*vertices*cubeFaces),uv=new Float32Array(uvSize*vertices*cubeFaces),faceIndex=new Float32Array(faceIndexSize*vertices*cubeFaces);for(let face=0;face<cubeFaces;face++){let x=face%3*2/3-1,y=face>2?0:-1,coordinates=[x,y,0,x+0.6666666666666666,y,0,x+0.6666666666666666,y+1,0,x,y,0,x+0.6666666666666666,y+1,0,x,y+1,0];position.set(coordinates,positionSize*vertices*face),uv.set(uv1,uvSize*vertices*face);let fill=[face,face,face,face,face,face];faceIndex.set(fill,faceIndexSize*vertices*face)}let planes=new BufferGeometry;if(planes.setAttribute("position",new BufferAttribute(position,positionSize)),planes.setAttribute("uv",new BufferAttribute(uv,uvSize)),planes.setAttribute("faceIndex",new BufferAttribute(faceIndex,faceIndexSize)),lodMeshes.push(new Mesh(planes,null)),lod>LOD_MIN)lod--}return{lodMeshes,sizeLods,sigmas}}function _createRenderTarget(width,height,params){let cubeUVRenderTarget=new WebGLRenderTarget(width,height,params);return cubeUVRenderTarget.texture.mapping=CubeUVReflectionMapping,cubeUVRenderTarget.texture.name="PMREM.cubeUv",cubeUVRenderTarget.scissorTest=!0,cubeUVRenderTarget}function _setViewport(target,x,y,width,height){target.viewport.set(x,y,width,height),target.scissor.set(x,y,width,height)}function _getGGXShader(lodMax,width,height){return new ShaderMaterial({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES,CUBEUV_TEXEL_WIDTH:1/width,CUBEUV_TEXEL_HEIGHT:1/height,CUBEUV_MAX_MIP:`${lodMax}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:_getCommonVertexShader(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:NoBlending,depthTest:!1,depthWrite:!1})}function _getBlurShader(lodMax,width,height){let weights=new Float32Array(MAX_SAMPLES),poleAxis=new Vector3(0,1,0);return new ShaderMaterial({name:"SphericalGaussianBlur",defines:{n:MAX_SAMPLES,CUBEUV_TEXEL_WIDTH:1/width,CUBEUV_TEXEL_HEIGHT:1/height,CUBEUV_MAX_MIP:`${lodMax}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:weights},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:poleAxis}},vertexShader:_getCommonVertexShader(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:NoBlending,depthTest:!1,depthWrite:!1})}function _getEquirectMaterial(){return new ShaderMaterial({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:_getCommonVertexShader(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:NoBlending,depthTest:!1,depthWrite:!1})}function _getCubemapMaterial(){return new ShaderMaterial({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:_getCommonVertexShader(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:NoBlending,depthTest:!1,depthWrite:!1})}function _getCommonVertexShader(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class WebGLCubeRenderTarget extends WebGLRenderTarget{constructor(size=1,options={}){super(size,size,options);this.isWebGLCubeRenderTarget=!0;let image={width:size,height:size,depth:1},images=[image,image,image,image,image,image];this.texture=new CubeTexture(images),this._setTextureOptions(options),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(renderer,texture){this.texture.type=texture.type,this.texture.colorSpace=texture.colorSpace,this.texture.generateMipmaps=texture.generateMipmaps,this.texture.minFilter=texture.minFilter,this.texture.magFilter=texture.magFilter;let shader={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},geometry=new BoxGeometry(5,5,5),material=new ShaderMaterial({name:"CubemapFromEquirect",uniforms:cloneUniforms(shader.uniforms),vertexShader:shader.vertexShader,fragmentShader:shader.fragmentShader,side:BackSide,blending:NoBlending});material.uniforms.tEquirect.value=texture;let mesh=new Mesh(geometry,material),currentMinFilter=texture.minFilter;if(texture.minFilter===LinearMipmapLinearFilter)texture.minFilter=LinearFilter;return new CubeCamera(1,10,this).update(renderer,mesh),texture.minFilter=currentMinFilter,mesh.geometry.dispose(),mesh.material.dispose(),this}clear(renderer,color=!0,depth=!0,stencil=!0){let currentRenderTarget=renderer.getRenderTarget();for(let i=0;i<6;i++)renderer.setRenderTarget(this,i),renderer.clear(color,depth,stencil);renderer.setRenderTarget(currentRenderTarget)}}function WebGLEnvironments(renderer){let cubeMaps=new WeakMap,pmremMaps=new WeakMap,pmremGenerator=null;function get(texture,usePMREM=!1){if(texture===null||texture===void 0)return null;if(usePMREM)return getPMREM(texture);return getCube(texture)}function getCube(texture){if(texture&&texture.isTexture){let mapping=texture.mapping;if(mapping===EquirectangularReflectionMapping||mapping===EquirectangularRefractionMapping)if(cubeMaps.has(texture)){let cubemap=cubeMaps.get(texture).texture;return mapTextureMapping(cubemap,texture.mapping)}else{let image=texture.image;if(image&&image.height>0){let renderTarget=new WebGLCubeRenderTarget(image.height);return renderTarget.fromEquirectangularTexture(renderer,texture),cubeMaps.set(texture,renderTarget),texture.addEventListener("dispose",onCubemapDispose),mapTextureMapping(renderTarget.texture,texture.mapping)}else return null}}return texture}function getPMREM(texture){if(texture&&texture.isTexture){let mapping=texture.mapping,isEquirectMap=mapping===EquirectangularReflectionMapping||mapping===EquirectangularRefractionMapping,isCubeMap=mapping===CubeReflectionMapping||mapping===CubeRefractionMapping;if(isEquirectMap||isCubeMap){let renderTarget=pmremMaps.get(texture),currentPMREMVersion=renderTarget!==void 0?renderTarget.texture.pmremVersion:0;if(texture.isRenderTargetTexture&&texture.pmremVersion!==currentPMREMVersion){if(pmremGenerator===null)pmremGenerator=new PMREMGenerator(renderer);return renderTarget=isEquirectMap?pmremGenerator.fromEquirectangular(texture,renderTarget):pmremGenerator.fromCubemap(texture,renderTarget),renderTarget.texture.pmremVersion=texture.pmremVersion,pmremMaps.set(texture,renderTarget),renderTarget.texture}else if(renderTarget!==void 0)return renderTarget.texture;else{let image=texture.image;if(isEquirectMap&&image&&image.height>0||isCubeMap&&image&&isCubeTextureComplete(image)){if(pmremGenerator===null)pmremGenerator=new PMREMGenerator(renderer);return renderTarget=isEquirectMap?pmremGenerator.fromEquirectangular(texture):pmremGenerator.fromCubemap(texture),renderTarget.texture.pmremVersion=texture.pmremVersion,pmremMaps.set(texture,renderTarget),texture.addEventListener("dispose",onPMREMDispose),renderTarget.texture}else return null}}}return texture}function mapTextureMapping(texture,mapping){if(mapping===EquirectangularReflectionMapping)texture.mapping=CubeReflectionMapping;else if(mapping===EquirectangularRefractionMapping)texture.mapping=CubeRefractionMapping;return texture}function isCubeTextureComplete(image){let count=0,length=6;for(let i=0;i<length;i++)if(image[i]!==void 0)count++;return count===length}function onCubemapDispose(event){let texture=event.target;texture.removeEventListener("dispose",onCubemapDispose);let cubemap=cubeMaps.get(texture);if(cubemap!==void 0)cubeMaps.delete(texture),cubemap.dispose()}function onPMREMDispose(event){let texture=event.target;texture.removeEventListener("dispose",onPMREMDispose);let pmrem=pmremMaps.get(texture);if(pmrem!==void 0)pmremMaps.delete(texture),pmrem.dispose()}function dispose(){if(cubeMaps=new WeakMap,pmremMaps=new WeakMap,pmremGenerator!==null)pmremGenerator.dispose(),pmremGenerator=null}return{get,dispose}}function WebGLExtensions(gl){let extensions={};function getExtension(name){if(extensions[name]!==void 0)return extensions[name];let extension=gl.getExtension(name);return extensions[name]=extension,extension}return{has:function(name){return getExtension(name)!==null},init:function(){getExtension("EXT_color_buffer_float"),getExtension("WEBGL_clip_cull_distance"),getExtension("OES_texture_float_linear"),getExtension("EXT_color_buffer_half_float"),getExtension("WEBGL_multisampled_render_to_texture"),getExtension("WEBGL_render_shared_exponent")},get:function(name){let extension=getExtension(name);if(extension===null)warnOnce("WebGLRenderer: "+name+" extension not supported.");return extension}}}function WebGLGeometries(gl,attributes,info,bindingStates){let geometries={},wireframeAttributes=new WeakMap;function onGeometryDispose(event){let geometry=event.target;if(geometry.index!==null)attributes.remove(geometry.index);for(let name in geometry.attributes)attributes.remove(geometry.attributes[name]);geometry.removeEventListener("dispose",onGeometryDispose),delete geometries[geometry.id];let attribute=wireframeAttributes.get(geometry);if(attribute)attributes.remove(attribute),wireframeAttributes.delete(geometry);if(bindingStates.releaseStatesOfGeometry(geometry),geometry.isInstancedBufferGeometry===!0)delete geometry._maxInstanceCount;info.memory.geometries--}function get(object,geometry){if(geometries[geometry.id]===!0)return geometry;return geometry.addEventListener("dispose",onGeometryDispose),geometries[geometry.id]=!0,info.memory.geometries++,geometry}function update(geometry){let geometryAttributes=geometry.attributes;for(let name in geometryAttributes)attributes.update(geometryAttributes[name],gl.ARRAY_BUFFER)}function updateWireframeAttribute(geometry){let indices=[],geometryIndex=geometry.index,geometryPosition=geometry.attributes.position,version=0;if(geometryPosition===void 0)return;if(geometryIndex!==null){let array=geometryIndex.array;version=geometryIndex.version;for(let i=0,l=array.length;i<l;i+=3){let a=array[i+0],b=array[i+1],c=array[i+2];indices.push(a,b,b,c,c,a)}}else{let array=geometryPosition.array;version=geometryPosition.version;for(let i=0,l=array.length/3-1;i<l;i+=3){let a=i+0,b=i+1,c=i+2;indices.push(a,b,b,c,c,a)}}let attribute=new(geometryPosition.count>=65535?Uint32BufferAttribute:Uint16BufferAttribute)(indices,1);attribute.version=version;let previousAttribute=wireframeAttributes.get(geometry);if(previousAttribute)attributes.remove(previousAttribute);wireframeAttributes.set(geometry,attribute)}function getWireframeAttribute(geometry){let currentAttribute=wireframeAttributes.get(geometry);if(currentAttribute){let geometryIndex=geometry.index;if(geometryIndex!==null){if(currentAttribute.version<geometryIndex.version)updateWireframeAttribute(geometry)}}else updateWireframeAttribute(geometry);return wireframeAttributes.get(geometry)}return{get,update,getWireframeAttribute}}function WebGLIndexedBufferRenderer(gl,extensions,info){let mode;function setMode(value){mode=value}let type,bytesPerElement;function setIndex(value){type=value.type,bytesPerElement=value.bytesPerElement}function render(start,count){gl.drawElements(mode,count,type,start*bytesPerElement),info.update(count,mode,1)}function renderInstances(start,count,primcount){if(primcount===0)return;gl.drawElementsInstanced(mode,count,type,start*bytesPerElement,primcount),info.update(count,mode,primcount)}function renderMultiDraw(starts,counts,drawCount){if(drawCount===0)return;extensions.get("WEBGL_multi_draw").multiDrawElementsWEBGL(mode,counts,0,type,starts,0,drawCount);let elementCount=0;for(let i=0;i<drawCount;i++)elementCount+=counts[i];info.update(elementCount,mode,1)}this.setMode=setMode,this.setIndex=setIndex,this.render=render,this.renderInstances=renderInstances,this.renderMultiDraw=renderMultiDraw}function WebGLInfo(gl){let memory={geometries:0,textures:0},render={frame:0,calls:0,triangles:0,points:0,lines:0};function update(count,mode,instanceCount){switch(render.calls++,mode){case gl.TRIANGLES:render.triangles+=instanceCount*(count/3);break;case gl.LINES:render.lines+=instanceCount*(count/2);break;case gl.LINE_STRIP:render.lines+=instanceCount*(count-1);break;case gl.LINE_LOOP:render.lines+=instanceCount*count;break;case gl.POINTS:render.points+=instanceCount*count;break;default:error("WebGLInfo: Unknown draw mode:",mode);break}}function reset(){render.calls=0,render.triangles=0,render.points=0,render.lines=0}return{memory,render,programs:null,autoReset:!0,reset,update}}function WebGLMorphtargets(gl,capabilities,textures){let morphTextures=new WeakMap,morph=new Vector4;function update(object,geometry,program){let objectInfluences=object.morphTargetInfluences,morphAttribute=geometry.morphAttributes.position||geometry.morphAttributes.normal||geometry.morphAttributes.color,morphTargetsCount=morphAttribute!==void 0?morphAttribute.length:0,entry=morphTextures.get(geometry);if(entry===void 0||entry.count!==morphTargetsCount){let disposeTexture=function(){texture.dispose(),morphTextures.delete(geometry),geometry.removeEventListener("dispose",disposeTexture)};if(entry!==void 0)entry.texture.dispose();let hasMorphPosition=geometry.morphAttributes.position!==void 0,hasMorphNormals=geometry.morphAttributes.normal!==void 0,hasMorphColors=geometry.morphAttributes.color!==void 0,morphTargets=geometry.morphAttributes.position||[],morphNormals=geometry.morphAttributes.normal||[],morphColors=geometry.morphAttributes.color||[],vertexDataCount=0;if(hasMorphPosition===!0)vertexDataCount=1;if(hasMorphNormals===!0)vertexDataCount=2;if(hasMorphColors===!0)vertexDataCount=3;let width=geometry.attributes.position.count*vertexDataCount,height=1;if(width>capabilities.maxTextureSize)height=Math.ceil(width/capabilities.maxTextureSize),width=capabilities.maxTextureSize;let buffer=new Float32Array(width*height*4*morphTargetsCount),texture=new DataArrayTexture(buffer,width,height,morphTargetsCount);texture.type=FloatType,texture.needsUpdate=!0;let vertexDataStride=vertexDataCount*4;for(let i=0;i<morphTargetsCount;i++){let morphTarget=morphTargets[i],morphNormal=morphNormals[i],morphColor=morphColors[i],offset=width*height*4*i;for(let j=0;j<morphTarget.count;j++){let stride=j*vertexDataStride;if(hasMorphPosition===!0)morph.fromBufferAttribute(morphTarget,j),buffer[offset+stride+0]=morph.x,buffer[offset+stride+1]=morph.y,buffer[offset+stride+2]=morph.z,buffer[offset+stride+3]=0;if(hasMorphNormals===!0)morph.fromBufferAttribute(morphNormal,j),buffer[offset+stride+4]=morph.x,buffer[offset+stride+5]=morph.y,buffer[offset+stride+6]=morph.z,buffer[offset+stride+7]=0;if(hasMorphColors===!0)morph.fromBufferAttribute(morphColor,j),buffer[offset+stride+8]=morph.x,buffer[offset+stride+9]=morph.y,buffer[offset+stride+10]=morph.z,buffer[offset+stride+11]=morphColor.itemSize===4?morph.w:1}}entry={count:morphTargetsCount,texture,size:new Vector2(width,height)},morphTextures.set(geometry,entry),geometry.addEventListener("dispose",disposeTexture)}if(object.isInstancedMesh===!0&&object.morphTexture!==null)program.getUniforms().setValue(gl,"morphTexture",object.morphTexture,textures);else{let morphInfluencesSum=0;for(let i=0;i<objectInfluences.length;i++)morphInfluencesSum+=objectInfluences[i];let morphBaseInfluence=geometry.morphTargetsRelative?1:1-morphInfluencesSum;program.getUniforms().setValue(gl,"morphTargetBaseInfluence",morphBaseInfluence),program.getUniforms().setValue(gl,"morphTargetInfluences",objectInfluences)}program.getUniforms().setValue(gl,"morphTargetsTexture",entry.texture,textures),program.getUniforms().setValue(gl,"morphTargetsTextureSize",entry.size)}return{update}}function WebGLObjects(gl,geometries,attributes,bindingStates,info){let updateMap=new WeakMap;function update(object){let frame=info.render.frame,geometry=object.geometry,buffergeometry=geometries.get(object,geometry);if(updateMap.get(buffergeometry)!==frame)geometries.update(buffergeometry),updateMap.set(buffergeometry,frame);if(object.isInstancedMesh){if(object.hasEventListener("dispose",onInstancedMeshDispose)===!1)object.addEventListener("dispose",onInstancedMeshDispose);if(updateMap.get(object)!==frame){if(attributes.update(object.instanceMatrix,gl.ARRAY_BUFFER),object.instanceColor!==null)attributes.update(object.instanceColor,gl.ARRAY_BUFFER);updateMap.set(object,frame)}}if(object.isSkinnedMesh){let skeleton=object.skeleton;if(updateMap.get(skeleton)!==frame)skeleton.update(),updateMap.set(skeleton,frame)}return buffergeometry}function dispose(){updateMap=new WeakMap}function onInstancedMeshDispose(event){let instancedMesh=event.target;if(instancedMesh.removeEventListener("dispose",onInstancedMeshDispose),bindingStates.releaseStatesOfObject(instancedMesh),attributes.remove(instancedMesh.instanceMatrix),instancedMesh.instanceColor!==null)attributes.remove(instancedMesh.instanceColor)}return{update,dispose}}var toneMappingMap={[LinearToneMapping]:"LINEAR_TONE_MAPPING",[ReinhardToneMapping]:"REINHARD_TONE_MAPPING",[CineonToneMapping]:"CINEON_TONE_MAPPING",[ACESFilmicToneMapping]:"ACES_FILMIC_TONE_MAPPING",[AgXToneMapping]:"AGX_TONE_MAPPING",[NeutralToneMapping]:"NEUTRAL_TONE_MAPPING",[CustomToneMapping]:"CUSTOM_TONE_MAPPING"};function WebGLOutput(type,width,height,depth,stencil){let targetA=new WebGLRenderTarget(width,height,{type,depthBuffer:depth,stencilBuffer:stencil,depthTexture:depth?new DepthTexture(width,height):void 0}),targetB=new WebGLRenderTarget(width,height,{type:HalfFloatType,depthBuffer:!1,stencilBuffer:!1}),geometry=new BufferGeometry;geometry.setAttribute("position",new Float32BufferAttribute([-1,3,0,-1,-1,0,3,-1,0],3)),geometry.setAttribute("uv",new Float32BufferAttribute([0,2,0,0,2,0],2));let material=new RawShaderMaterial({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),mesh=new Mesh(geometry,material),camera=new OrthographicCamera(-1,1,1,-1,0,1),_outputColorSpace=null,_outputToneMapping=null,_isCompositing=!1,_savedToneMapping,_savedRenderTarget=null,_effects=[],_hasRenderPass=!1;this.setSize=function(width2,height2){targetA.setSize(width2,height2),targetB.setSize(width2,height2);for(let i=0;i<_effects.length;i++){let effect=_effects[i];if(effect.setSize)effect.setSize(width2,height2)}},this.setEffects=function(effects){_effects=effects,_hasRenderPass=_effects.length>0&&_effects[0].isRenderPass===!0;let{width:width2,height:height2}=targetA;for(let i=0;i<_effects.length;i++){let effect=_effects[i];if(effect.setSize)effect.setSize(width2,height2)}},this.begin=function(renderer,renderTarget){if(_isCompositing)return!1;if(renderer.toneMapping===NoToneMapping&&_effects.length===0)return!1;if(_savedRenderTarget=renderTarget,renderTarget!==null){let{width:width2,height:height2}=renderTarget;if(targetA.width!==width2||targetA.height!==height2)this.setSize(width2,height2)}if(_hasRenderPass===!1)renderer.setRenderTarget(targetA);return _savedToneMapping=renderer.toneMapping,renderer.toneMapping=NoToneMapping,!0},this.hasRenderPass=function(){return _hasRenderPass},this.end=function(renderer,deltaTime){renderer.toneMapping=_savedToneMapping,_isCompositing=!0;let readBuffer=targetA,writeBuffer=targetB;for(let i=0;i<_effects.length;i++){let effect=_effects[i];if(effect.enabled===!1)continue;if(effect.render(renderer,writeBuffer,readBuffer,deltaTime),effect.needsSwap!==!1){let temp=readBuffer;readBuffer=writeBuffer,writeBuffer=temp}}if(_outputColorSpace!==renderer.outputColorSpace||_outputToneMapping!==renderer.toneMapping){if(_outputColorSpace=renderer.outputColorSpace,_outputToneMapping=renderer.toneMapping,material.defines={},ColorManagement.getTransfer(_outputColorSpace)===SRGBTransfer)material.defines.SRGB_TRANSFER="";let toneMapping=toneMappingMap[_outputToneMapping];if(toneMapping)material.defines[toneMapping]="";material.needsUpdate=!0}material.uniforms.tDiffuse.value=readBuffer.texture,renderer.setRenderTarget(_savedRenderTarget),renderer.render(mesh,camera),_savedRenderTarget=null,_isCompositing=!1},this.isCompositing=function(){return _isCompositing},this.dispose=function(){if(targetA.depthTexture)targetA.depthTexture.dispose();targetA.dispose(),targetB.dispose(),geometry.dispose(),material.dispose()}}var emptyTexture=new Texture,emptyShadowTexture=new DepthTexture(1,1),emptyArrayTexture=new DataArrayTexture,empty3dTexture=new Data3DTexture,emptyCubeTexture=new CubeTexture,arrayCacheF32=[],arrayCacheI32=[],mat4array=new Float32Array(16),mat3array=new Float32Array(9),mat2array=new Float32Array(4);function flatten(array,nBlocks,blockSize){let firstElem=array[0];if(firstElem<=0||firstElem>0)return array;let n=nBlocks*blockSize,r=arrayCacheF32[n];if(r===void 0)r=new Float32Array(n),arrayCacheF32[n]=r;if(nBlocks!==0){firstElem.toArray(r,0);for(let i=1,offset=0;i!==nBlocks;++i)offset+=blockSize,array[i].toArray(r,offset)}return r}function arraysEqual(a,b){if(a.length!==b.length)return!1;for(let i=0,l=a.length;i<l;i++)if(a[i]!==b[i])return!1;return!0}function copyArray(a,b){for(let i=0,l=b.length;i<l;i++)a[i]=b[i]}function allocTexUnits(textures,n){let r=arrayCacheI32[n];if(r===void 0)r=new Int32Array(n),arrayCacheI32[n]=r;for(let i=0;i!==n;++i)r[i]=textures.allocateTextureUnit();return r}function setValueV1f(gl,v){let cache=this.cache;if(cache[0]===v)return;gl.uniform1f(this.addr,v),cache[0]=v}function setValueV2f(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y)gl.uniform2f(this.addr,v.x,v.y),cache[0]=v.x,cache[1]=v.y}else{if(arraysEqual(cache,v))return;gl.uniform2fv(this.addr,v),copyArray(cache,v)}}function setValueV3f(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y||cache[2]!==v.z)gl.uniform3f(this.addr,v.x,v.y,v.z),cache[0]=v.x,cache[1]=v.y,cache[2]=v.z}else if(v.r!==void 0){if(cache[0]!==v.r||cache[1]!==v.g||cache[2]!==v.b)gl.uniform3f(this.addr,v.r,v.g,v.b),cache[0]=v.r,cache[1]=v.g,cache[2]=v.b}else{if(arraysEqual(cache,v))return;gl.uniform3fv(this.addr,v),copyArray(cache,v)}}function setValueV4f(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y||cache[2]!==v.z||cache[3]!==v.w)gl.uniform4f(this.addr,v.x,v.y,v.z,v.w),cache[0]=v.x,cache[1]=v.y,cache[2]=v.z,cache[3]=v.w}else{if(arraysEqual(cache,v))return;gl.uniform4fv(this.addr,v),copyArray(cache,v)}}function setValueM2(gl,v){let cache=this.cache,elements=v.elements;if(elements===void 0){if(arraysEqual(cache,v))return;gl.uniformMatrix2fv(this.addr,!1,v),copyArray(cache,v)}else{if(arraysEqual(cache,elements))return;mat2array.set(elements),gl.uniformMatrix2fv(this.addr,!1,mat2array),copyArray(cache,elements)}}function setValueM3(gl,v){let cache=this.cache,elements=v.elements;if(elements===void 0){if(arraysEqual(cache,v))return;gl.uniformMatrix3fv(this.addr,!1,v),copyArray(cache,v)}else{if(arraysEqual(cache,elements))return;mat3array.set(elements),gl.uniformMatrix3fv(this.addr,!1,mat3array),copyArray(cache,elements)}}function setValueM4(gl,v){let cache=this.cache,elements=v.elements;if(elements===void 0){if(arraysEqual(cache,v))return;gl.uniformMatrix4fv(this.addr,!1,v),copyArray(cache,v)}else{if(arraysEqual(cache,elements))return;mat4array.set(elements),gl.uniformMatrix4fv(this.addr,!1,mat4array),copyArray(cache,elements)}}function setValueV1i(gl,v){let cache=this.cache;if(cache[0]===v)return;gl.uniform1i(this.addr,v),cache[0]=v}function setValueV2i(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y)gl.uniform2i(this.addr,v.x,v.y),cache[0]=v.x,cache[1]=v.y}else{if(arraysEqual(cache,v))return;gl.uniform2iv(this.addr,v),copyArray(cache,v)}}function setValueV3i(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y||cache[2]!==v.z)gl.uniform3i(this.addr,v.x,v.y,v.z),cache[0]=v.x,cache[1]=v.y,cache[2]=v.z}else{if(arraysEqual(cache,v))return;gl.uniform3iv(this.addr,v),copyArray(cache,v)}}function setValueV4i(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y||cache[2]!==v.z||cache[3]!==v.w)gl.uniform4i(this.addr,v.x,v.y,v.z,v.w),cache[0]=v.x,cache[1]=v.y,cache[2]=v.z,cache[3]=v.w}else{if(arraysEqual(cache,v))return;gl.uniform4iv(this.addr,v),copyArray(cache,v)}}function setValueV1ui(gl,v){let cache=this.cache;if(cache[0]===v)return;gl.uniform1ui(this.addr,v),cache[0]=v}function setValueV2ui(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y)gl.uniform2ui(this.addr,v.x,v.y),cache[0]=v.x,cache[1]=v.y}else{if(arraysEqual(cache,v))return;gl.uniform2uiv(this.addr,v),copyArray(cache,v)}}function setValueV3ui(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y||cache[2]!==v.z)gl.uniform3ui(this.addr,v.x,v.y,v.z),cache[0]=v.x,cache[1]=v.y,cache[2]=v.z}else{if(arraysEqual(cache,v))return;gl.uniform3uiv(this.addr,v),copyArray(cache,v)}}function setValueV4ui(gl,v){let cache=this.cache;if(v.x!==void 0){if(cache[0]!==v.x||cache[1]!==v.y||cache[2]!==v.z||cache[3]!==v.w)gl.uniform4ui(this.addr,v.x,v.y,v.z,v.w),cache[0]=v.x,cache[1]=v.y,cache[2]=v.z,cache[3]=v.w}else{if(arraysEqual(cache,v))return;gl.uniform4uiv(this.addr,v),copyArray(cache,v)}}function setValueT1(gl,v,textures){let cache=this.cache,unit=textures.allocateTextureUnit();if(cache[0]!==unit)gl.uniform1i(this.addr,unit),cache[0]=unit;let emptyTexture2D;if(this.type===gl.SAMPLER_2D_SHADOW)emptyShadowTexture.compareFunction=textures.isReversedDepthBuffer()?GreaterEqualCompare:LessEqualCompare,emptyTexture2D=emptyShadowTexture;else emptyTexture2D=emptyTexture;textures.setTexture2D(v||emptyTexture2D,unit)}function setValueT3D1(gl,v,textures){let cache=this.cache,unit=textures.allocateTextureUnit();if(cache[0]!==unit)gl.uniform1i(this.addr,unit),cache[0]=unit;textures.setTexture3D(v||empty3dTexture,unit)}function setValueT6(gl,v,textures){let cache=this.cache,unit=textures.allocateTextureUnit();if(cache[0]!==unit)gl.uniform1i(this.addr,unit),cache[0]=unit;textures.setTextureCube(v||emptyCubeTexture,unit)}function setValueT2DArray1(gl,v,textures){let cache=this.cache,unit=textures.allocateTextureUnit();if(cache[0]!==unit)gl.uniform1i(this.addr,unit),cache[0]=unit;textures.setTexture2DArray(v||emptyArrayTexture,unit)}function getSingularSetter(type){switch(type){case 5126:return setValueV1f;case 35664:return setValueV2f;case 35665:return setValueV3f;case 35666:return setValueV4f;case 35674:return setValueM2;case 35675:return setValueM3;case 35676:return setValueM4;case 5124:case 35670:return setValueV1i;case 35667:case 35671:return setValueV2i;case 35668:case 35672:return setValueV3i;case 35669:case 35673:return setValueV4i;case 5125:return setValueV1ui;case 36294:return setValueV2ui;case 36295:return setValueV3ui;case 36296:return setValueV4ui;case 35678:case 36198:case 36298:case 36306:case 35682:return setValueT1;case 35679:case 36299:case 36307:return setValueT3D1;case 35680:case 36300:case 36308:case 36293:return setValueT6;case 36289:case 36303:case 36311:case 36292:return setValueT2DArray1}}function setValueV1fArray(gl,v){gl.uniform1fv(this.addr,v)}function setValueV2fArray(gl,v){let data=flatten(v,this.size,2);gl.uniform2fv(this.addr,data)}function setValueV3fArray(gl,v){let data=flatten(v,this.size,3);gl.uniform3fv(this.addr,data)}function setValueV4fArray(gl,v){let data=flatten(v,this.size,4);gl.uniform4fv(this.addr,data)}function setValueM2Array(gl,v){let data=flatten(v,this.size,4);gl.uniformMatrix2fv(this.addr,!1,data)}function setValueM3Array(gl,v){let data=flatten(v,this.size,9);gl.uniformMatrix3fv(this.addr,!1,data)}function setValueM4Array(gl,v){let data=flatten(v,this.size,16);gl.uniformMatrix4fv(this.addr,!1,data)}function setValueV1iArray(gl,v){gl.uniform1iv(this.addr,v)}function setValueV2iArray(gl,v){gl.uniform2iv(this.addr,v)}function setValueV3iArray(gl,v){gl.uniform3iv(this.addr,v)}function setValueV4iArray(gl,v){gl.uniform4iv(this.addr,v)}function setValueV1uiArray(gl,v){gl.uniform1uiv(this.addr,v)}function setValueV2uiArray(gl,v){gl.uniform2uiv(this.addr,v)}function setValueV3uiArray(gl,v){gl.uniform3uiv(this.addr,v)}function setValueV4uiArray(gl,v){gl.uniform4uiv(this.addr,v)}function setValueT1Array(gl,v,textures){let cache=this.cache,n=v.length,units=allocTexUnits(textures,n);if(!arraysEqual(cache,units))gl.uniform1iv(this.addr,units),copyArray(cache,units);let emptyTexture2D;if(this.type===gl.SAMPLER_2D_SHADOW)emptyTexture2D=emptyShadowTexture;else emptyTexture2D=emptyTexture;for(let i=0;i!==n;++i)textures.setTexture2D(v[i]||emptyTexture2D,units[i])}function setValueT3DArray(gl,v,textures){let cache=this.cache,n=v.length,units=allocTexUnits(textures,n);if(!arraysEqual(cache,units))gl.uniform1iv(this.addr,units),copyArray(cache,units);for(let i=0;i!==n;++i)textures.setTexture3D(v[i]||empty3dTexture,units[i])}function setValueT6Array(gl,v,textures){let cache=this.cache,n=v.length,units=allocTexUnits(textures,n);if(!arraysEqual(cache,units))gl.uniform1iv(this.addr,units),copyArray(cache,units);for(let i=0;i!==n;++i)textures.setTextureCube(v[i]||emptyCubeTexture,units[i])}function setValueT2DArrayArray(gl,v,textures){let cache=this.cache,n=v.length,units=allocTexUnits(textures,n);if(!arraysEqual(cache,units))gl.uniform1iv(this.addr,units),copyArray(cache,units);for(let i=0;i!==n;++i)textures.setTexture2DArray(v[i]||emptyArrayTexture,units[i])}function getPureArraySetter(type){switch(type){case 5126:return setValueV1fArray;case 35664:return setValueV2fArray;case 35665:return setValueV3fArray;case 35666:return setValueV4fArray;case 35674:return setValueM2Array;case 35675:return setValueM3Array;case 35676:return setValueM4Array;case 5124:case 35670:return setValueV1iArray;case 35667:case 35671:return setValueV2iArray;case 35668:case 35672:return setValueV3iArray;case 35669:case 35673:return setValueV4iArray;case 5125:return setValueV1uiArray;case 36294:return setValueV2uiArray;case 36295:return setValueV3uiArray;case 36296:return setValueV4uiArray;case 35678:case 36198:case 36298:case 36306:case 35682:return setValueT1Array;case 35679:case 36299:case 36307:return setValueT3DArray;case 35680:case 36300:case 36308:case 36293:return setValueT6Array;case 36289:case 36303:case 36311:case 36292:return setValueT2DArrayArray}}class SingleUniform{constructor(id,activeInfo,addr){this.id=id,this.addr=addr,this.cache=[],this.type=activeInfo.type,this.setValue=getSingularSetter(activeInfo.type)}}class PureArrayUniform{constructor(id,activeInfo,addr){this.id=id,this.addr=addr,this.cache=[],this.type=activeInfo.type,this.size=activeInfo.size,this.setValue=getPureArraySetter(activeInfo.type)}}class StructuredUniform{constructor(id){this.id=id,this.seq=[],this.map={}}setValue(gl,value,textures){let seq=this.seq;for(let i=0,n=seq.length;i!==n;++i){let u=seq[i];u.setValue(gl,value[u.id],textures)}}}var RePathPart=/(\w+)(\])?(\[|\.)?/g;function addUniform(container,uniformObject){container.seq.push(uniformObject),container.map[uniformObject.id]=uniformObject}function parseUniform(activeInfo,addr,container){let path=activeInfo.name,pathLength=path.length;RePathPart.lastIndex=0;while(!0){let match=RePathPart.exec(path),matchEnd=RePathPart.lastIndex,id=match[1],idIsIndex=match[2]==="]",subscript=match[3];if(idIsIndex)id=id|0;if(subscript===void 0||subscript==="["&&matchEnd+2===pathLength){addUniform(container,subscript===void 0?new SingleUniform(id,activeInfo,addr):new PureArrayUniform(id,activeInfo,addr));break}else{let next=container.map[id];if(next===void 0)next=new StructuredUniform(id),addUniform(container,next);container=next}}}class WebGLUniforms{constructor(gl,program){this.seq=[],this.map={};let n=gl.getProgramParameter(program,gl.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){let info=gl.getActiveUniform(program,i),addr=gl.getUniformLocation(program,info.name);parseUniform(info,addr,this)}let shadowSamplers=[],otherUniforms=[];for(let u of this.seq)if(u.type===gl.SAMPLER_2D_SHADOW||u.type===gl.SAMPLER_CUBE_SHADOW||u.type===gl.SAMPLER_2D_ARRAY_SHADOW)shadowSamplers.push(u);else otherUniforms.push(u);if(shadowSamplers.length>0)this.seq=shadowSamplers.concat(otherUniforms)}setValue(gl,name,value,textures){let u=this.map[name];if(u!==void 0)u.setValue(gl,value,textures)}setOptional(gl,object,name){let v=object[name];if(v!==void 0)this.setValue(gl,name,v)}static upload(gl,seq,values,textures){for(let i=0,n=seq.length;i!==n;++i){let u=seq[i],v=values[u.id];if(v.needsUpdate!==!1)u.setValue(gl,v.value,textures)}}static seqWithValue(seq,values){let r=[];for(let i=0,n=seq.length;i!==n;++i){let u=seq[i];if(u.id in values)r.push(u)}return r}}function WebGLShader(gl,type,string){let shader=gl.createShader(type);return gl.shaderSource(shader,string),gl.compileShader(shader),shader}var COMPLETION_STATUS_KHR=37297,programIdCount=0;function handleSource(string,errorLine){let lines=string.split(`
`),lines2=[],from=Math.max(errorLine-6,0),to=Math.min(errorLine+6,lines.length);for(let i=from;i<to;i++){let line=i+1;lines2.push(`${line===errorLine?">":" "} ${line}: ${lines[i]}`)}return lines2.join(`
`)}var _m0=new Matrix3;function getEncodingComponents(colorSpace){ColorManagement._getMatrix(_m0,ColorManagement.workingColorSpace,colorSpace);let encodingMatrix=`mat3( ${_m0.elements.map((v)=>v.toFixed(4))} )`;switch(ColorManagement.getTransfer(colorSpace)){case LinearTransfer:return[encodingMatrix,"LinearTransferOETF"];case SRGBTransfer:return[encodingMatrix,"sRGBTransferOETF"];default:return warn("WebGLProgram: Unsupported color space: ",colorSpace),[encodingMatrix,"LinearTransferOETF"]}}function getShaderErrors(gl,shader,type){let status=gl.getShaderParameter(shader,gl.COMPILE_STATUS),errors=(gl.getShaderInfoLog(shader)||"").trim();if(status&&errors==="")return"";let errorMatches=/ERROR: 0:(\d+)/.exec(errors);if(errorMatches){let errorLine=parseInt(errorMatches[1]);return type.toUpperCase()+`

`+errors+`

`+handleSource(gl.getShaderSource(shader),errorLine)}else return errors}function getTexelEncodingFunction(functionName,colorSpace){let components=getEncodingComponents(colorSpace);return[`vec4 ${functionName}( vec4 value ) {`,`	return ${components[1]}( vec4( value.rgb * ${components[0]}, value.a ) );`,"}"].join(`
`)}var toneMappingFunctions={[LinearToneMapping]:"Linear",[ReinhardToneMapping]:"Reinhard",[CineonToneMapping]:"Cineon",[ACESFilmicToneMapping]:"ACESFilmic",[AgXToneMapping]:"AgX",[NeutralToneMapping]:"Neutral",[CustomToneMapping]:"Custom"};function getToneMappingFunction(functionName,toneMapping){let toneMappingName=toneMappingFunctions[toneMapping];if(toneMappingName===void 0)return warn("WebGLProgram: Unsupported toneMapping:",toneMapping),"vec3 "+functionName+"( vec3 color ) { return LinearToneMapping( color ); }";return"vec3 "+functionName+"( vec3 color ) { return "+toneMappingName+"ToneMapping( color ); }"}var _v0=new Vector3;function getLuminanceFunction(){ColorManagement.getLuminanceCoefficients(_v0);let r=_v0.x.toFixed(4),g=_v0.y.toFixed(4),b=_v0.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${g}, ${b} );`,"\treturn dot( weights, rgb );","}"].join(`
`)}function generateVertexExtensions(parameters){return[parameters.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",parameters.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(filterEmptyLine).join(`
`)}function generateDefines(defines){let chunks=[];for(let name in defines){let value=defines[name];if(value===!1)continue;chunks.push("#define "+name+" "+value)}return chunks.join(`
`)}function fetchAttributeLocations(gl,program){let attributes={},n=gl.getProgramParameter(program,gl.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){let info=gl.getActiveAttrib(program,i),name=info.name,locationSize=1;if(info.type===gl.FLOAT_MAT2)locationSize=2;if(info.type===gl.FLOAT_MAT3)locationSize=3;if(info.type===gl.FLOAT_MAT4)locationSize=4;attributes[name]={type:info.type,location:gl.getAttribLocation(program,name),locationSize}}return attributes}function filterEmptyLine(string){return string!==""}function replaceLightNums(string,parameters){let numSpotLightCoords=parameters.numSpotLightShadows+parameters.numSpotLightMaps-parameters.numSpotLightShadowsWithMaps;return string.replace(/NUM_DIR_LIGHTS/g,parameters.numDirLights).replace(/NUM_SPOT_LIGHTS/g,parameters.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,parameters.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,numSpotLightCoords).replace(/NUM_RECT_AREA_LIGHTS/g,parameters.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,parameters.numPointLights).replace(/NUM_HEMI_LIGHTS/g,parameters.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,parameters.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,parameters.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,parameters.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,parameters.numPointLightShadows)}function replaceClippingPlaneNums(string,parameters){return string.replace(/NUM_CLIPPING_PLANES/g,parameters.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,parameters.numClippingPlanes-parameters.numClipIntersection)}var includePattern=/^[ \t]*#include +<([\w\d./]+)>/gm;function resolveIncludes(string){return string.replace(includePattern,includeReplacer)}var shaderChunkMap=new Map;function includeReplacer(match,include){let string=ShaderChunk[include];if(string===void 0){let newInclude=shaderChunkMap.get(include);if(newInclude!==void 0)string=ShaderChunk[newInclude],warn('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',include,newInclude);else throw Error("Can not resolve #include <"+include+">")}return resolveIncludes(string)}var unrollLoopPattern=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function unrollLoops(string){return string.replace(unrollLoopPattern,loopReplacer)}function loopReplacer(match,start,end,snippet){let string="";for(let i=parseInt(start);i<parseInt(end);i++)string+=snippet.replace(/\[\s*i\s*\]/g,"[ "+i+" ]").replace(/UNROLLED_LOOP_INDEX/g,i);return string}function generatePrecision(parameters){let precisionstring=`precision ${parameters.precision} float;
	precision ${parameters.precision} int;
	precision ${parameters.precision} sampler2D;
	precision ${parameters.precision} samplerCube;
	precision ${parameters.precision} sampler3D;
	precision ${parameters.precision} sampler2DArray;
	precision ${parameters.precision} sampler2DShadow;
	precision ${parameters.precision} samplerCubeShadow;
	precision ${parameters.precision} sampler2DArrayShadow;
	precision ${parameters.precision} isampler2D;
	precision ${parameters.precision} isampler3D;
	precision ${parameters.precision} isamplerCube;
	precision ${parameters.precision} isampler2DArray;
	precision ${parameters.precision} usampler2D;
	precision ${parameters.precision} usampler3D;
	precision ${parameters.precision} usamplerCube;
	precision ${parameters.precision} usampler2DArray;
	`;if(parameters.precision==="highp")precisionstring+=`
#define HIGH_PRECISION`;else if(parameters.precision==="mediump")precisionstring+=`
#define MEDIUM_PRECISION`;else if(parameters.precision==="lowp")precisionstring+=`
#define LOW_PRECISION`;return precisionstring}var shadowMapTypeDefines={[PCFShadowMap]:"SHADOWMAP_TYPE_PCF",[VSMShadowMap]:"SHADOWMAP_TYPE_VSM"};function generateShadowMapTypeDefine(parameters){return shadowMapTypeDefines[parameters.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}var envMapTypeDefines={[CubeReflectionMapping]:"ENVMAP_TYPE_CUBE",[CubeRefractionMapping]:"ENVMAP_TYPE_CUBE",[CubeUVReflectionMapping]:"ENVMAP_TYPE_CUBE_UV"};function generateEnvMapTypeDefine(parameters){if(parameters.envMap===!1)return"ENVMAP_TYPE_CUBE";return envMapTypeDefines[parameters.envMapMode]||"ENVMAP_TYPE_CUBE"}var envMapModeDefines={[CubeRefractionMapping]:"ENVMAP_MODE_REFRACTION"};function generateEnvMapModeDefine(parameters){if(parameters.envMap===!1)return"ENVMAP_MODE_REFLECTION";return envMapModeDefines[parameters.envMapMode]||"ENVMAP_MODE_REFLECTION"}var envMapBlendingDefines={[MultiplyOperation]:"ENVMAP_BLENDING_MULTIPLY",[MixOperation]:"ENVMAP_BLENDING_MIX",[AddOperation]:"ENVMAP_BLENDING_ADD"};function generateEnvMapBlendingDefine(parameters){if(parameters.envMap===!1)return"ENVMAP_BLENDING_NONE";return envMapBlendingDefines[parameters.combine]||"ENVMAP_BLENDING_NONE"}function generateCubeUVSize(parameters){let imageHeight=parameters.envMapCubeUVHeight;if(imageHeight===null)return null;let maxMip=Math.log2(imageHeight)-2,texelHeight=1/imageHeight;return{texelWidth:1/(3*Math.max(Math.pow(2,maxMip),112)),texelHeight,maxMip}}function WebGLProgram(renderer,cacheKey,parameters,bindingStates){let gl=renderer.getContext(),defines=parameters.defines,vertexShader=parameters.vertexShader,fragmentShader=parameters.fragmentShader,shadowMapTypeDefine=generateShadowMapTypeDefine(parameters),envMapTypeDefine=generateEnvMapTypeDefine(parameters),envMapModeDefine=generateEnvMapModeDefine(parameters),envMapBlendingDefine=generateEnvMapBlendingDefine(parameters),envMapCubeUVSize=generateCubeUVSize(parameters),customVertexExtensions=generateVertexExtensions(parameters),customDefines=generateDefines(defines),program=gl.createProgram(),prefixVertex,prefixFragment,versionString=parameters.glslVersion?"#version "+parameters.glslVersion+`
`:"";if(parameters.isRawShaderMaterial){if(prefixVertex=["#define SHADER_TYPE "+parameters.shaderType,"#define SHADER_NAME "+parameters.shaderName,customDefines].filter(filterEmptyLine).join(`
`),prefixVertex.length>0)prefixVertex+=`
`;if(prefixFragment=["#define SHADER_TYPE "+parameters.shaderType,"#define SHADER_NAME "+parameters.shaderName,customDefines].filter(filterEmptyLine).join(`
`),prefixFragment.length>0)prefixFragment+=`
`}else prefixVertex=[generatePrecision(parameters),"#define SHADER_TYPE "+parameters.shaderType,"#define SHADER_NAME "+parameters.shaderName,customDefines,parameters.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",parameters.batching?"#define USE_BATCHING":"",parameters.batchingColor?"#define USE_BATCHING_COLOR":"",parameters.instancing?"#define USE_INSTANCING":"",parameters.instancingColor?"#define USE_INSTANCING_COLOR":"",parameters.instancingMorph?"#define USE_INSTANCING_MORPH":"",parameters.useFog&&parameters.fog?"#define USE_FOG":"",parameters.useFog&&parameters.fogExp2?"#define FOG_EXP2":"",parameters.map?"#define USE_MAP":"",parameters.envMap?"#define USE_ENVMAP":"",parameters.envMap?"#define "+envMapModeDefine:"",parameters.lightMap?"#define USE_LIGHTMAP":"",parameters.aoMap?"#define USE_AOMAP":"",parameters.bumpMap?"#define USE_BUMPMAP":"",parameters.normalMap?"#define USE_NORMALMAP":"",parameters.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",parameters.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",parameters.displacementMap?"#define USE_DISPLACEMENTMAP":"",parameters.emissiveMap?"#define USE_EMISSIVEMAP":"",parameters.anisotropy?"#define USE_ANISOTROPY":"",parameters.anisotropyMap?"#define USE_ANISOTROPYMAP":"",parameters.clearcoatMap?"#define USE_CLEARCOATMAP":"",parameters.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",parameters.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",parameters.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",parameters.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",parameters.specularMap?"#define USE_SPECULARMAP":"",parameters.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",parameters.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",parameters.roughnessMap?"#define USE_ROUGHNESSMAP":"",parameters.metalnessMap?"#define USE_METALNESSMAP":"",parameters.alphaMap?"#define USE_ALPHAMAP":"",parameters.alphaHash?"#define USE_ALPHAHASH":"",parameters.transmission?"#define USE_TRANSMISSION":"",parameters.transmissionMap?"#define USE_TRANSMISSIONMAP":"",parameters.thicknessMap?"#define USE_THICKNESSMAP":"",parameters.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",parameters.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",parameters.mapUv?"#define MAP_UV "+parameters.mapUv:"",parameters.alphaMapUv?"#define ALPHAMAP_UV "+parameters.alphaMapUv:"",parameters.lightMapUv?"#define LIGHTMAP_UV "+parameters.lightMapUv:"",parameters.aoMapUv?"#define AOMAP_UV "+parameters.aoMapUv:"",parameters.emissiveMapUv?"#define EMISSIVEMAP_UV "+parameters.emissiveMapUv:"",parameters.bumpMapUv?"#define BUMPMAP_UV "+parameters.bumpMapUv:"",parameters.normalMapUv?"#define NORMALMAP_UV "+parameters.normalMapUv:"",parameters.displacementMapUv?"#define DISPLACEMENTMAP_UV "+parameters.displacementMapUv:"",parameters.metalnessMapUv?"#define METALNESSMAP_UV "+parameters.metalnessMapUv:"",parameters.roughnessMapUv?"#define ROUGHNESSMAP_UV "+parameters.roughnessMapUv:"",parameters.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+parameters.anisotropyMapUv:"",parameters.clearcoatMapUv?"#define CLEARCOATMAP_UV "+parameters.clearcoatMapUv:"",parameters.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+parameters.clearcoatNormalMapUv:"",parameters.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+parameters.clearcoatRoughnessMapUv:"",parameters.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+parameters.iridescenceMapUv:"",parameters.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+parameters.iridescenceThicknessMapUv:"",parameters.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+parameters.sheenColorMapUv:"",parameters.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+parameters.sheenRoughnessMapUv:"",parameters.specularMapUv?"#define SPECULARMAP_UV "+parameters.specularMapUv:"",parameters.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+parameters.specularColorMapUv:"",parameters.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+parameters.specularIntensityMapUv:"",parameters.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+parameters.transmissionMapUv:"",parameters.thicknessMapUv?"#define THICKNESSMAP_UV "+parameters.thicknessMapUv:"",parameters.vertexTangents&&parameters.flatShading===!1?"#define USE_TANGENT":"",parameters.vertexNormals?"#define HAS_NORMAL":"",parameters.vertexColors?"#define USE_COLOR":"",parameters.vertexAlphas?"#define USE_COLOR_ALPHA":"",parameters.vertexUv1s?"#define USE_UV1":"",parameters.vertexUv2s?"#define USE_UV2":"",parameters.vertexUv3s?"#define USE_UV3":"",parameters.pointsUvs?"#define USE_POINTS_UV":"",parameters.flatShading?"#define FLAT_SHADED":"",parameters.skinning?"#define USE_SKINNING":"",parameters.morphTargets?"#define USE_MORPHTARGETS":"",parameters.morphNormals&&parameters.flatShading===!1?"#define USE_MORPHNORMALS":"",parameters.morphColors?"#define USE_MORPHCOLORS":"",parameters.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+parameters.morphTextureStride:"",parameters.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+parameters.morphTargetsCount:"",parameters.doubleSided?"#define DOUBLE_SIDED":"",parameters.flipSided?"#define FLIP_SIDED":"",parameters.shadowMapEnabled?"#define USE_SHADOWMAP":"",parameters.shadowMapEnabled?"#define "+shadowMapTypeDefine:"",parameters.sizeAttenuation?"#define USE_SIZEATTENUATION":"",parameters.numLightProbes>0?"#define USE_LIGHT_PROBES":"",parameters.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",parameters.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","\tattribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","\tattribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","\tuniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","\tattribute vec2 uv1;","#endif","#ifdef USE_UV2","\tattribute vec2 uv2;","#endif","#ifdef USE_UV3","\tattribute vec2 uv3;","#endif","#ifdef USE_TANGENT","\tattribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","\tattribute vec4 color;","#elif defined( USE_COLOR )","\tattribute vec3 color;","#endif","#ifdef USE_SKINNING","\tattribute vec4 skinIndex;","\tattribute vec4 skinWeight;","#endif",`
`].filter(filterEmptyLine).join(`
`),prefixFragment=[generatePrecision(parameters),"#define SHADER_TYPE "+parameters.shaderType,"#define SHADER_NAME "+parameters.shaderName,customDefines,parameters.useFog&&parameters.fog?"#define USE_FOG":"",parameters.useFog&&parameters.fogExp2?"#define FOG_EXP2":"",parameters.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",parameters.map?"#define USE_MAP":"",parameters.matcap?"#define USE_MATCAP":"",parameters.envMap?"#define USE_ENVMAP":"",parameters.envMap?"#define "+envMapTypeDefine:"",parameters.envMap?"#define "+envMapModeDefine:"",parameters.envMap?"#define "+envMapBlendingDefine:"",envMapCubeUVSize?"#define CUBEUV_TEXEL_WIDTH "+envMapCubeUVSize.texelWidth:"",envMapCubeUVSize?"#define CUBEUV_TEXEL_HEIGHT "+envMapCubeUVSize.texelHeight:"",envMapCubeUVSize?"#define CUBEUV_MAX_MIP "+envMapCubeUVSize.maxMip+".0":"",parameters.lightMap?"#define USE_LIGHTMAP":"",parameters.aoMap?"#define USE_AOMAP":"",parameters.bumpMap?"#define USE_BUMPMAP":"",parameters.normalMap?"#define USE_NORMALMAP":"",parameters.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",parameters.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",parameters.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",parameters.emissiveMap?"#define USE_EMISSIVEMAP":"",parameters.anisotropy?"#define USE_ANISOTROPY":"",parameters.anisotropyMap?"#define USE_ANISOTROPYMAP":"",parameters.clearcoat?"#define USE_CLEARCOAT":"",parameters.clearcoatMap?"#define USE_CLEARCOATMAP":"",parameters.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",parameters.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",parameters.dispersion?"#define USE_DISPERSION":"",parameters.iridescence?"#define USE_IRIDESCENCE":"",parameters.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",parameters.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",parameters.specularMap?"#define USE_SPECULARMAP":"",parameters.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",parameters.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",parameters.roughnessMap?"#define USE_ROUGHNESSMAP":"",parameters.metalnessMap?"#define USE_METALNESSMAP":"",parameters.alphaMap?"#define USE_ALPHAMAP":"",parameters.alphaTest?"#define USE_ALPHATEST":"",parameters.alphaHash?"#define USE_ALPHAHASH":"",parameters.sheen?"#define USE_SHEEN":"",parameters.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",parameters.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",parameters.transmission?"#define USE_TRANSMISSION":"",parameters.transmissionMap?"#define USE_TRANSMISSIONMAP":"",parameters.thicknessMap?"#define USE_THICKNESSMAP":"",parameters.vertexTangents&&parameters.flatShading===!1?"#define USE_TANGENT":"",parameters.vertexColors||parameters.instancingColor?"#define USE_COLOR":"",parameters.vertexAlphas||parameters.batchingColor?"#define USE_COLOR_ALPHA":"",parameters.vertexUv1s?"#define USE_UV1":"",parameters.vertexUv2s?"#define USE_UV2":"",parameters.vertexUv3s?"#define USE_UV3":"",parameters.pointsUvs?"#define USE_POINTS_UV":"",parameters.gradientMap?"#define USE_GRADIENTMAP":"",parameters.flatShading?"#define FLAT_SHADED":"",parameters.doubleSided?"#define DOUBLE_SIDED":"",parameters.flipSided?"#define FLIP_SIDED":"",parameters.shadowMapEnabled?"#define USE_SHADOWMAP":"",parameters.shadowMapEnabled?"#define "+shadowMapTypeDefine:"",parameters.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",parameters.numLightProbes>0?"#define USE_LIGHT_PROBES":"",parameters.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",parameters.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",parameters.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",parameters.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",parameters.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",parameters.toneMapping!==NoToneMapping?"#define TONE_MAPPING":"",parameters.toneMapping!==NoToneMapping?ShaderChunk.tonemapping_pars_fragment:"",parameters.toneMapping!==NoToneMapping?getToneMappingFunction("toneMapping",parameters.toneMapping):"",parameters.dithering?"#define DITHERING":"",parameters.opaque?"#define OPAQUE":"",ShaderChunk.colorspace_pars_fragment,getTexelEncodingFunction("linearToOutputTexel",parameters.outputColorSpace),getLuminanceFunction(),parameters.useDepthPacking?"#define DEPTH_PACKING "+parameters.depthPacking:"",`
`].filter(filterEmptyLine).join(`
`);if(vertexShader=resolveIncludes(vertexShader),vertexShader=replaceLightNums(vertexShader,parameters),vertexShader=replaceClippingPlaneNums(vertexShader,parameters),fragmentShader=resolveIncludes(fragmentShader),fragmentShader=replaceLightNums(fragmentShader,parameters),fragmentShader=replaceClippingPlaneNums(fragmentShader,parameters),vertexShader=unrollLoops(vertexShader),fragmentShader=unrollLoops(fragmentShader),parameters.isRawShaderMaterial!==!0)versionString=`#version 300 es
`,prefixVertex=[customVertexExtensions,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+prefixVertex,prefixFragment=["#define varying in",parameters.glslVersion===GLSL3?"":"layout(location = 0) out highp vec4 pc_fragColor;",parameters.glslVersion===GLSL3?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+prefixFragment;let vertexGlsl=versionString+prefixVertex+vertexShader,fragmentGlsl=versionString+prefixFragment+fragmentShader,glVertexShader=WebGLShader(gl,gl.VERTEX_SHADER,vertexGlsl),glFragmentShader=WebGLShader(gl,gl.FRAGMENT_SHADER,fragmentGlsl);if(gl.attachShader(program,glVertexShader),gl.attachShader(program,glFragmentShader),parameters.index0AttributeName!==void 0)gl.bindAttribLocation(program,0,parameters.index0AttributeName);else if(parameters.morphTargets===!0)gl.bindAttribLocation(program,0,"position");gl.linkProgram(program);function onFirstUse(self2){if(renderer.debug.checkShaderErrors){let programInfoLog=gl.getProgramInfoLog(program)||"",vertexShaderInfoLog=gl.getShaderInfoLog(glVertexShader)||"",fragmentShaderInfoLog=gl.getShaderInfoLog(glFragmentShader)||"",programLog=programInfoLog.trim(),vertexLog=vertexShaderInfoLog.trim(),fragmentLog=fragmentShaderInfoLog.trim(),runnable=!0,haveDiagnostics=!0;if(gl.getProgramParameter(program,gl.LINK_STATUS)===!1)if(runnable=!1,typeof renderer.debug.onShaderError==="function")renderer.debug.onShaderError(gl,program,glVertexShader,glFragmentShader);else{let vertexErrors=getShaderErrors(gl,glVertexShader,"vertex"),fragmentErrors=getShaderErrors(gl,glFragmentShader,"fragment");error("THREE.WebGLProgram: Shader Error "+gl.getError()+" - VALIDATE_STATUS "+gl.getProgramParameter(program,gl.VALIDATE_STATUS)+`

Material Name: `+self2.name+`
Material Type: `+self2.type+`

Program Info Log: `+programLog+`
`+vertexErrors+`
`+fragmentErrors)}else if(programLog!=="")warn("WebGLProgram: Program Info Log:",programLog);else if(vertexLog===""||fragmentLog==="")haveDiagnostics=!1;if(haveDiagnostics)self2.diagnostics={runnable,programLog,vertexShader:{log:vertexLog,prefix:prefixVertex},fragmentShader:{log:fragmentLog,prefix:prefixFragment}}}gl.deleteShader(glVertexShader),gl.deleteShader(glFragmentShader),cachedUniforms=new WebGLUniforms(gl,program),cachedAttributes=fetchAttributeLocations(gl,program)}let cachedUniforms;this.getUniforms=function(){if(cachedUniforms===void 0)onFirstUse(this);return cachedUniforms};let cachedAttributes;this.getAttributes=function(){if(cachedAttributes===void 0)onFirstUse(this);return cachedAttributes};let programReady=parameters.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){if(programReady===!1)programReady=gl.getProgramParameter(program,COMPLETION_STATUS_KHR);return programReady},this.destroy=function(){bindingStates.releaseStatesOfProgram(this),gl.deleteProgram(program),this.program=void 0},this.type=parameters.shaderType,this.name=parameters.shaderName,this.id=programIdCount++,this.cacheKey=cacheKey,this.usedTimes=1,this.program=program,this.vertexShader=glVertexShader,this.fragmentShader=glFragmentShader,this}var _id=0;class WebGLShaderCache{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(material){let{vertexShader,fragmentShader}=material,vertexShaderStage=this._getShaderStage(vertexShader),fragmentShaderStage=this._getShaderStage(fragmentShader),materialShaders=this._getShaderCacheForMaterial(material);if(materialShaders.has(vertexShaderStage)===!1)materialShaders.add(vertexShaderStage),vertexShaderStage.usedTimes++;if(materialShaders.has(fragmentShaderStage)===!1)materialShaders.add(fragmentShaderStage),fragmentShaderStage.usedTimes++;return this}remove(material){let materialShaders=this.materialCache.get(material);for(let shaderStage of materialShaders)if(shaderStage.usedTimes--,shaderStage.usedTimes===0)this.shaderCache.delete(shaderStage.code);return this.materialCache.delete(material),this}getVertexShaderID(material){return this._getShaderStage(material.vertexShader).id}getFragmentShaderID(material){return this._getShaderStage(material.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(material){let cache=this.materialCache,set=cache.get(material);if(set===void 0)set=new Set,cache.set(material,set);return set}_getShaderStage(code){let cache=this.shaderCache,stage=cache.get(code);if(stage===void 0)stage=new WebGLShaderStage(code),cache.set(code,stage);return stage}}class WebGLShaderStage{constructor(code){this.id=_id++,this.code=code,this.usedTimes=0}}function isPackedRGFormat(format){return format===RGFormat||format===RG11_EAC_Format||format===RED_GREEN_RGTC2_Format}function WebGLPrograms(renderer,environments,extensions,capabilities,bindingStates,clipping){let _programLayers=new Layers,_customShaders=new WebGLShaderCache,_activeChannels=new Set,programs=[],programsMap=new Map,logarithmicDepthBuffer=capabilities.logarithmicDepthBuffer,precision=capabilities.precision,shaderIDs={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function getChannel(value){if(_activeChannels.add(value),value===0)return"uv";return`uv${value}`}function getParameters(material,lights,shadows,scene,object,lightProbeGrids){let fog=scene.fog,geometry=object.geometry,environment=material.isMeshStandardMaterial||material.isMeshLambertMaterial||material.isMeshPhongMaterial?scene.environment:null,usePMREM=material.isMeshStandardMaterial||material.isMeshLambertMaterial&&!material.envMap||material.isMeshPhongMaterial&&!material.envMap,envMap=environments.get(material.envMap||environment,usePMREM),envMapCubeUVHeight=!!envMap&&envMap.mapping===CubeUVReflectionMapping?envMap.image.height:null,shaderID=shaderIDs[material.type];if(material.precision!==null){if(precision=capabilities.getMaxPrecision(material.precision),precision!==material.precision)warn("WebGLProgram.getParameters:",material.precision,"not supported, using",precision,"instead.")}let morphAttribute=geometry.morphAttributes.position||geometry.morphAttributes.normal||geometry.morphAttributes.color,morphTargetsCount=morphAttribute!==void 0?morphAttribute.length:0,morphTextureStride=0;if(geometry.morphAttributes.position!==void 0)morphTextureStride=1;if(geometry.morphAttributes.normal!==void 0)morphTextureStride=2;if(geometry.morphAttributes.color!==void 0)morphTextureStride=3;let vertexShader,fragmentShader,customVertexShaderID,customFragmentShaderID;if(shaderID){let shader=ShaderLib[shaderID];vertexShader=shader.vertexShader,fragmentShader=shader.fragmentShader}else vertexShader=material.vertexShader,fragmentShader=material.fragmentShader,_customShaders.update(material),customVertexShaderID=_customShaders.getVertexShaderID(material),customFragmentShaderID=_customShaders.getFragmentShaderID(material);let currentRenderTarget=renderer.getRenderTarget(),reversedDepthBuffer=renderer.state.buffers.depth.getReversed(),IS_INSTANCEDMESH=object.isInstancedMesh===!0,IS_BATCHEDMESH=object.isBatchedMesh===!0,HAS_MAP=!!material.map,HAS_MATCAP=!!material.matcap,HAS_ENVMAP=!!envMap,HAS_AOMAP=!!material.aoMap,HAS_LIGHTMAP=!!material.lightMap,HAS_BUMPMAP=!!material.bumpMap,HAS_NORMALMAP=!!material.normalMap,HAS_DISPLACEMENTMAP=!!material.displacementMap,HAS_EMISSIVEMAP=!!material.emissiveMap,HAS_METALNESSMAP=!!material.metalnessMap,HAS_ROUGHNESSMAP=!!material.roughnessMap,HAS_ANISOTROPY=material.anisotropy>0,HAS_CLEARCOAT=material.clearcoat>0,HAS_DISPERSION=material.dispersion>0,HAS_IRIDESCENCE=material.iridescence>0,HAS_SHEEN=material.sheen>0,HAS_TRANSMISSION=material.transmission>0,HAS_ANISOTROPYMAP=HAS_ANISOTROPY&&!!material.anisotropyMap,HAS_CLEARCOATMAP=HAS_CLEARCOAT&&!!material.clearcoatMap,HAS_CLEARCOAT_NORMALMAP=HAS_CLEARCOAT&&!!material.clearcoatNormalMap,HAS_CLEARCOAT_ROUGHNESSMAP=HAS_CLEARCOAT&&!!material.clearcoatRoughnessMap,HAS_IRIDESCENCEMAP=HAS_IRIDESCENCE&&!!material.iridescenceMap,HAS_IRIDESCENCE_THICKNESSMAP=HAS_IRIDESCENCE&&!!material.iridescenceThicknessMap,HAS_SHEEN_COLORMAP=HAS_SHEEN&&!!material.sheenColorMap,HAS_SHEEN_ROUGHNESSMAP=HAS_SHEEN&&!!material.sheenRoughnessMap,HAS_SPECULARMAP=!!material.specularMap,HAS_SPECULAR_COLORMAP=!!material.specularColorMap,HAS_SPECULAR_INTENSITYMAP=!!material.specularIntensityMap,HAS_TRANSMISSIONMAP=HAS_TRANSMISSION&&!!material.transmissionMap,HAS_THICKNESSMAP=HAS_TRANSMISSION&&!!material.thicknessMap,HAS_GRADIENTMAP=!!material.gradientMap,HAS_ALPHAMAP=!!material.alphaMap,HAS_ALPHATEST=material.alphaTest>0,HAS_ALPHAHASH=!!material.alphaHash,HAS_EXTENSIONS=!!material.extensions,toneMapping=NoToneMapping;if(material.toneMapped){if(currentRenderTarget===null||currentRenderTarget.isXRRenderTarget===!0)toneMapping=renderer.toneMapping}let parameters={shaderID,shaderType:material.type,shaderName:material.name,vertexShader,fragmentShader,defines:material.defines,customVertexShaderID,customFragmentShaderID,isRawShaderMaterial:material.isRawShaderMaterial===!0,glslVersion:material.glslVersion,precision,batching:IS_BATCHEDMESH,batchingColor:IS_BATCHEDMESH&&object._colorsTexture!==null,instancing:IS_INSTANCEDMESH,instancingColor:IS_INSTANCEDMESH&&object.instanceColor!==null,instancingMorph:IS_INSTANCEDMESH&&object.morphTexture!==null,outputColorSpace:currentRenderTarget===null?renderer.outputColorSpace:currentRenderTarget.isXRRenderTarget===!0?currentRenderTarget.texture.colorSpace:ColorManagement.workingColorSpace,alphaToCoverage:!!material.alphaToCoverage,map:HAS_MAP,matcap:HAS_MATCAP,envMap:HAS_ENVMAP,envMapMode:HAS_ENVMAP&&envMap.mapping,envMapCubeUVHeight,aoMap:HAS_AOMAP,lightMap:HAS_LIGHTMAP,bumpMap:HAS_BUMPMAP,normalMap:HAS_NORMALMAP,displacementMap:HAS_DISPLACEMENTMAP,emissiveMap:HAS_EMISSIVEMAP,normalMapObjectSpace:HAS_NORMALMAP&&material.normalMapType===ObjectSpaceNormalMap,normalMapTangentSpace:HAS_NORMALMAP&&material.normalMapType===TangentSpaceNormalMap,packedNormalMap:HAS_NORMALMAP&&material.normalMapType===TangentSpaceNormalMap&&isPackedRGFormat(material.normalMap.format),metalnessMap:HAS_METALNESSMAP,roughnessMap:HAS_ROUGHNESSMAP,anisotropy:HAS_ANISOTROPY,anisotropyMap:HAS_ANISOTROPYMAP,clearcoat:HAS_CLEARCOAT,clearcoatMap:HAS_CLEARCOATMAP,clearcoatNormalMap:HAS_CLEARCOAT_NORMALMAP,clearcoatRoughnessMap:HAS_CLEARCOAT_ROUGHNESSMAP,dispersion:HAS_DISPERSION,iridescence:HAS_IRIDESCENCE,iridescenceMap:HAS_IRIDESCENCEMAP,iridescenceThicknessMap:HAS_IRIDESCENCE_THICKNESSMAP,sheen:HAS_SHEEN,sheenColorMap:HAS_SHEEN_COLORMAP,sheenRoughnessMap:HAS_SHEEN_ROUGHNESSMAP,specularMap:HAS_SPECULARMAP,specularColorMap:HAS_SPECULAR_COLORMAP,specularIntensityMap:HAS_SPECULAR_INTENSITYMAP,transmission:HAS_TRANSMISSION,transmissionMap:HAS_TRANSMISSIONMAP,thicknessMap:HAS_THICKNESSMAP,gradientMap:HAS_GRADIENTMAP,opaque:material.transparent===!1&&material.blending===NormalBlending&&material.alphaToCoverage===!1,alphaMap:HAS_ALPHAMAP,alphaTest:HAS_ALPHATEST,alphaHash:HAS_ALPHAHASH,combine:material.combine,mapUv:HAS_MAP&&getChannel(material.map.channel),aoMapUv:HAS_AOMAP&&getChannel(material.aoMap.channel),lightMapUv:HAS_LIGHTMAP&&getChannel(material.lightMap.channel),bumpMapUv:HAS_BUMPMAP&&getChannel(material.bumpMap.channel),normalMapUv:HAS_NORMALMAP&&getChannel(material.normalMap.channel),displacementMapUv:HAS_DISPLACEMENTMAP&&getChannel(material.displacementMap.channel),emissiveMapUv:HAS_EMISSIVEMAP&&getChannel(material.emissiveMap.channel),metalnessMapUv:HAS_METALNESSMAP&&getChannel(material.metalnessMap.channel),roughnessMapUv:HAS_ROUGHNESSMAP&&getChannel(material.roughnessMap.channel),anisotropyMapUv:HAS_ANISOTROPYMAP&&getChannel(material.anisotropyMap.channel),clearcoatMapUv:HAS_CLEARCOATMAP&&getChannel(material.clearcoatMap.channel),clearcoatNormalMapUv:HAS_CLEARCOAT_NORMALMAP&&getChannel(material.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:HAS_CLEARCOAT_ROUGHNESSMAP&&getChannel(material.clearcoatRoughnessMap.channel),iridescenceMapUv:HAS_IRIDESCENCEMAP&&getChannel(material.iridescenceMap.channel),iridescenceThicknessMapUv:HAS_IRIDESCENCE_THICKNESSMAP&&getChannel(material.iridescenceThicknessMap.channel),sheenColorMapUv:HAS_SHEEN_COLORMAP&&getChannel(material.sheenColorMap.channel),sheenRoughnessMapUv:HAS_SHEEN_ROUGHNESSMAP&&getChannel(material.sheenRoughnessMap.channel),specularMapUv:HAS_SPECULARMAP&&getChannel(material.specularMap.channel),specularColorMapUv:HAS_SPECULAR_COLORMAP&&getChannel(material.specularColorMap.channel),specularIntensityMapUv:HAS_SPECULAR_INTENSITYMAP&&getChannel(material.specularIntensityMap.channel),transmissionMapUv:HAS_TRANSMISSIONMAP&&getChannel(material.transmissionMap.channel),thicknessMapUv:HAS_THICKNESSMAP&&getChannel(material.thicknessMap.channel),alphaMapUv:HAS_ALPHAMAP&&getChannel(material.alphaMap.channel),vertexTangents:!!geometry.attributes.tangent&&(HAS_NORMALMAP||HAS_ANISOTROPY),vertexNormals:!!geometry.attributes.normal,vertexColors:material.vertexColors,vertexAlphas:material.vertexColors===!0&&!!geometry.attributes.color&&geometry.attributes.color.itemSize===4,pointsUvs:object.isPoints===!0&&!!geometry.attributes.uv&&(HAS_MAP||HAS_ALPHAMAP),fog:!!fog,useFog:material.fog===!0,fogExp2:!!fog&&fog.isFogExp2,flatShading:material.wireframe===!1&&(material.flatShading===!0||geometry.attributes.normal===void 0&&HAS_NORMALMAP===!1&&(material.isMeshLambertMaterial||material.isMeshPhongMaterial||material.isMeshStandardMaterial||material.isMeshPhysicalMaterial)),sizeAttenuation:material.sizeAttenuation===!0,logarithmicDepthBuffer,reversedDepthBuffer,skinning:object.isSkinnedMesh===!0,morphTargets:geometry.morphAttributes.position!==void 0,morphNormals:geometry.morphAttributes.normal!==void 0,morphColors:geometry.morphAttributes.color!==void 0,morphTargetsCount,morphTextureStride,numDirLights:lights.directional.length,numPointLights:lights.point.length,numSpotLights:lights.spot.length,numSpotLightMaps:lights.spotLightMap.length,numRectAreaLights:lights.rectArea.length,numHemiLights:lights.hemi.length,numDirLightShadows:lights.directionalShadowMap.length,numPointLightShadows:lights.pointShadowMap.length,numSpotLightShadows:lights.spotShadowMap.length,numSpotLightShadowsWithMaps:lights.numSpotLightShadowsWithMaps,numLightProbes:lights.numLightProbes,numLightProbeGrids:lightProbeGrids.length,numClippingPlanes:clipping.numPlanes,numClipIntersection:clipping.numIntersection,dithering:material.dithering,shadowMapEnabled:renderer.shadowMap.enabled&&shadows.length>0,shadowMapType:renderer.shadowMap.type,toneMapping,decodeVideoTexture:HAS_MAP&&material.map.isVideoTexture===!0&&ColorManagement.getTransfer(material.map.colorSpace)===SRGBTransfer,decodeVideoTextureEmissive:HAS_EMISSIVEMAP&&material.emissiveMap.isVideoTexture===!0&&ColorManagement.getTransfer(material.emissiveMap.colorSpace)===SRGBTransfer,premultipliedAlpha:material.premultipliedAlpha,doubleSided:material.side===DoubleSide,flipSided:material.side===BackSide,useDepthPacking:material.depthPacking>=0,depthPacking:material.depthPacking||0,index0AttributeName:material.index0AttributeName,extensionClipCullDistance:HAS_EXTENSIONS&&material.extensions.clipCullDistance===!0&&extensions.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(HAS_EXTENSIONS&&material.extensions.multiDraw===!0||IS_BATCHEDMESH)&&extensions.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:extensions.has("KHR_parallel_shader_compile"),customProgramCacheKey:material.customProgramCacheKey()};return parameters.vertexUv1s=_activeChannels.has(1),parameters.vertexUv2s=_activeChannels.has(2),parameters.vertexUv3s=_activeChannels.has(3),_activeChannels.clear(),parameters}function getProgramCacheKey(parameters){let array=[];if(parameters.shaderID)array.push(parameters.shaderID);else array.push(parameters.customVertexShaderID),array.push(parameters.customFragmentShaderID);if(parameters.defines!==void 0)for(let name in parameters.defines)array.push(name),array.push(parameters.defines[name]);if(parameters.isRawShaderMaterial===!1)getProgramCacheKeyParameters(array,parameters),getProgramCacheKeyBooleans(array,parameters),array.push(renderer.outputColorSpace);return array.push(parameters.customProgramCacheKey),array.join()}function getProgramCacheKeyParameters(array,parameters){array.push(parameters.precision),array.push(parameters.outputColorSpace),array.push(parameters.envMapMode),array.push(parameters.envMapCubeUVHeight),array.push(parameters.mapUv),array.push(parameters.alphaMapUv),array.push(parameters.lightMapUv),array.push(parameters.aoMapUv),array.push(parameters.bumpMapUv),array.push(parameters.normalMapUv),array.push(parameters.displacementMapUv),array.push(parameters.emissiveMapUv),array.push(parameters.metalnessMapUv),array.push(parameters.roughnessMapUv),array.push(parameters.anisotropyMapUv),array.push(parameters.clearcoatMapUv),array.push(parameters.clearcoatNormalMapUv),array.push(parameters.clearcoatRoughnessMapUv),array.push(parameters.iridescenceMapUv),array.push(parameters.iridescenceThicknessMapUv),array.push(parameters.sheenColorMapUv),array.push(parameters.sheenRoughnessMapUv),array.push(parameters.specularMapUv),array.push(parameters.specularColorMapUv),array.push(parameters.specularIntensityMapUv),array.push(parameters.transmissionMapUv),array.push(parameters.thicknessMapUv),array.push(parameters.combine),array.push(parameters.fogExp2),array.push(parameters.sizeAttenuation),array.push(parameters.morphTargetsCount),array.push(parameters.morphAttributeCount),array.push(parameters.numDirLights),array.push(parameters.numPointLights),array.push(parameters.numSpotLights),array.push(parameters.numSpotLightMaps),array.push(parameters.numHemiLights),array.push(parameters.numRectAreaLights),array.push(parameters.numDirLightShadows),array.push(parameters.numPointLightShadows),array.push(parameters.numSpotLightShadows),array.push(parameters.numSpotLightShadowsWithMaps),array.push(parameters.numLightProbes),array.push(parameters.shadowMapType),array.push(parameters.toneMapping),array.push(parameters.numClippingPlanes),array.push(parameters.numClipIntersection),array.push(parameters.depthPacking)}function getProgramCacheKeyBooleans(array,parameters){if(_programLayers.disableAll(),parameters.instancing)_programLayers.enable(0);if(parameters.instancingColor)_programLayers.enable(1);if(parameters.instancingMorph)_programLayers.enable(2);if(parameters.matcap)_programLayers.enable(3);if(parameters.envMap)_programLayers.enable(4);if(parameters.normalMapObjectSpace)_programLayers.enable(5);if(parameters.normalMapTangentSpace)_programLayers.enable(6);if(parameters.clearcoat)_programLayers.enable(7);if(parameters.iridescence)_programLayers.enable(8);if(parameters.alphaTest)_programLayers.enable(9);if(parameters.vertexColors)_programLayers.enable(10);if(parameters.vertexAlphas)_programLayers.enable(11);if(parameters.vertexUv1s)_programLayers.enable(12);if(parameters.vertexUv2s)_programLayers.enable(13);if(parameters.vertexUv3s)_programLayers.enable(14);if(parameters.vertexTangents)_programLayers.enable(15);if(parameters.anisotropy)_programLayers.enable(16);if(parameters.alphaHash)_programLayers.enable(17);if(parameters.batching)_programLayers.enable(18);if(parameters.dispersion)_programLayers.enable(19);if(parameters.batchingColor)_programLayers.enable(20);if(parameters.gradientMap)_programLayers.enable(21);if(parameters.packedNormalMap)_programLayers.enable(22);if(parameters.vertexNormals)_programLayers.enable(23);if(array.push(_programLayers.mask),_programLayers.disableAll(),parameters.fog)_programLayers.enable(0);if(parameters.useFog)_programLayers.enable(1);if(parameters.flatShading)_programLayers.enable(2);if(parameters.logarithmicDepthBuffer)_programLayers.enable(3);if(parameters.reversedDepthBuffer)_programLayers.enable(4);if(parameters.skinning)_programLayers.enable(5);if(parameters.morphTargets)_programLayers.enable(6);if(parameters.morphNormals)_programLayers.enable(7);if(parameters.morphColors)_programLayers.enable(8);if(parameters.premultipliedAlpha)_programLayers.enable(9);if(parameters.shadowMapEnabled)_programLayers.enable(10);if(parameters.doubleSided)_programLayers.enable(11);if(parameters.flipSided)_programLayers.enable(12);if(parameters.useDepthPacking)_programLayers.enable(13);if(parameters.dithering)_programLayers.enable(14);if(parameters.transmission)_programLayers.enable(15);if(parameters.sheen)_programLayers.enable(16);if(parameters.opaque)_programLayers.enable(17);if(parameters.pointsUvs)_programLayers.enable(18);if(parameters.decodeVideoTexture)_programLayers.enable(19);if(parameters.decodeVideoTextureEmissive)_programLayers.enable(20);if(parameters.alphaToCoverage)_programLayers.enable(21);if(parameters.numLightProbeGrids>0)_programLayers.enable(22);array.push(_programLayers.mask)}function getUniforms(material){let shaderID=shaderIDs[material.type],uniforms;if(shaderID){let shader=ShaderLib[shaderID];uniforms=UniformsUtils.clone(shader.uniforms)}else uniforms=material.uniforms;return uniforms}function acquireProgram(parameters,cacheKey){let program=programsMap.get(cacheKey);if(program!==void 0)++program.usedTimes;else program=new WebGLProgram(renderer,cacheKey,parameters,bindingStates),programs.push(program),programsMap.set(cacheKey,program);return program}function releaseProgram(program){if(--program.usedTimes===0){let i=programs.indexOf(program);programs[i]=programs[programs.length-1],programs.pop(),programsMap.delete(program.cacheKey),program.destroy()}}function releaseShaderCache(material){_customShaders.remove(material)}function dispose(){_customShaders.dispose()}return{getParameters,getProgramCacheKey,getUniforms,acquireProgram,releaseProgram,releaseShaderCache,programs,dispose}}function WebGLProperties(){let properties=new WeakMap;function has(object){return properties.has(object)}function get(object){let map=properties.get(object);if(map===void 0)map={},properties.set(object,map);return map}function remove(object){properties.delete(object)}function update(object,key,value){properties.get(object)[key]=value}function dispose(){properties=new WeakMap}return{has,get,remove,update,dispose}}function painterSortStable(a,b){if(a.groupOrder!==b.groupOrder)return a.groupOrder-b.groupOrder;else if(a.renderOrder!==b.renderOrder)return a.renderOrder-b.renderOrder;else if(a.material.id!==b.material.id)return a.material.id-b.material.id;else if(a.materialVariant!==b.materialVariant)return a.materialVariant-b.materialVariant;else if(a.z!==b.z)return a.z-b.z;else return a.id-b.id}function reversePainterSortStable(a,b){if(a.groupOrder!==b.groupOrder)return a.groupOrder-b.groupOrder;else if(a.renderOrder!==b.renderOrder)return a.renderOrder-b.renderOrder;else if(a.z!==b.z)return b.z-a.z;else return a.id-b.id}function WebGLRenderList(){let renderItems=[],renderItemsIndex=0,opaque=[],transmissive=[],transparent=[];function init(){renderItemsIndex=0,opaque.length=0,transmissive.length=0,transparent.length=0}function materialVariant(object){let variant=0;if(object.isInstancedMesh)variant+=2;if(object.isSkinnedMesh)variant+=1;return variant}function getNextRenderItem(object,geometry,material,groupOrder,z,group){let renderItem=renderItems[renderItemsIndex];if(renderItem===void 0)renderItem={id:object.id,object,geometry,material,materialVariant:materialVariant(object),groupOrder,renderOrder:object.renderOrder,z,group},renderItems[renderItemsIndex]=renderItem;else renderItem.id=object.id,renderItem.object=object,renderItem.geometry=geometry,renderItem.material=material,renderItem.materialVariant=materialVariant(object),renderItem.groupOrder=groupOrder,renderItem.renderOrder=object.renderOrder,renderItem.z=z,renderItem.group=group;return renderItemsIndex++,renderItem}function push(object,geometry,material,groupOrder,z,group){let renderItem=getNextRenderItem(object,geometry,material,groupOrder,z,group);if(material.transmission>0)transmissive.push(renderItem);else if(material.transparent===!0)transparent.push(renderItem);else opaque.push(renderItem)}function unshift(object,geometry,material,groupOrder,z,group){let renderItem=getNextRenderItem(object,geometry,material,groupOrder,z,group);if(material.transmission>0)transmissive.unshift(renderItem);else if(material.transparent===!0)transparent.unshift(renderItem);else opaque.unshift(renderItem)}function sort(customOpaqueSort,customTransparentSort){if(opaque.length>1)opaque.sort(customOpaqueSort||painterSortStable);if(transmissive.length>1)transmissive.sort(customTransparentSort||reversePainterSortStable);if(transparent.length>1)transparent.sort(customTransparentSort||reversePainterSortStable)}function finish(){for(let i=renderItemsIndex,il=renderItems.length;i<il;i++){let renderItem=renderItems[i];if(renderItem.id===null)break;renderItem.id=null,renderItem.object=null,renderItem.geometry=null,renderItem.material=null,renderItem.group=null}}return{opaque,transmissive,transparent,init,push,unshift,finish,sort}}function WebGLRenderLists(){let lists=new WeakMap;function get(scene,renderCallDepth){let listArray=lists.get(scene),list;if(listArray===void 0)list=new WebGLRenderList,lists.set(scene,[list]);else if(renderCallDepth>=listArray.length)list=new WebGLRenderList,listArray.push(list);else list=listArray[renderCallDepth];return list}function dispose(){lists=new WeakMap}return{get,dispose}}function UniformsCache(){let lights={};return{get:function(light){if(lights[light.id]!==void 0)return lights[light.id];let uniforms;switch(light.type){case"DirectionalLight":uniforms={direction:new Vector3,color:new Color};break;case"SpotLight":uniforms={position:new Vector3,direction:new Vector3,color:new Color,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":uniforms={position:new Vector3,color:new Color,distance:0,decay:0};break;case"HemisphereLight":uniforms={direction:new Vector3,skyColor:new Color,groundColor:new Color};break;case"RectAreaLight":uniforms={color:new Color,position:new Vector3,halfWidth:new Vector3,halfHeight:new Vector3};break}return lights[light.id]=uniforms,uniforms}}}function ShadowUniformsCache(){let lights={};return{get:function(light){if(lights[light.id]!==void 0)return lights[light.id];let uniforms;switch(light.type){case"DirectionalLight":uniforms={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Vector2};break;case"SpotLight":uniforms={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Vector2};break;case"PointLight":uniforms={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Vector2,shadowCameraNear:1,shadowCameraFar:1000};break}return lights[light.id]=uniforms,uniforms}}}var nextVersion=0;function shadowCastingAndTexturingLightsFirst(lightA,lightB){return(lightB.castShadow?2:0)-(lightA.castShadow?2:0)+(lightB.map?1:0)-(lightA.map?1:0)}function WebGLLights(extensions){let cache=new UniformsCache,shadowCache=ShadowUniformsCache(),state={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let i=0;i<9;i++)state.probe.push(new Vector3);let vector3=new Vector3,matrix4=new Matrix4,matrix42=new Matrix4;function setup(lights){let r=0,g=0,b=0;for(let i=0;i<9;i++)state.probe[i].set(0,0,0);let directionalLength=0,pointLength=0,spotLength=0,rectAreaLength=0,hemiLength=0,numDirectionalShadows=0,numPointShadows=0,numSpotShadows=0,numSpotMaps=0,numSpotShadowsWithMaps=0,numLightProbes=0;lights.sort(shadowCastingAndTexturingLightsFirst);for(let i=0,l=lights.length;i<l;i++){let light=lights[i],color=light.color,intensity=light.intensity,distance=light.distance,shadowMap=null;if(light.shadow&&light.shadow.map)if(light.shadow.map.texture.format===RGFormat)shadowMap=light.shadow.map.texture;else shadowMap=light.shadow.map.depthTexture||light.shadow.map.texture;if(light.isAmbientLight)r+=color.r*intensity,g+=color.g*intensity,b+=color.b*intensity;else if(light.isLightProbe){for(let j=0;j<9;j++)state.probe[j].addScaledVector(light.sh.coefficients[j],intensity);numLightProbes++}else if(light.isDirectionalLight){let uniforms=cache.get(light);if(uniforms.color.copy(light.color).multiplyScalar(light.intensity),light.castShadow){let shadow=light.shadow,shadowUniforms=shadowCache.get(light);shadowUniforms.shadowIntensity=shadow.intensity,shadowUniforms.shadowBias=shadow.bias,shadowUniforms.shadowNormalBias=shadow.normalBias,shadowUniforms.shadowRadius=shadow.radius,shadowUniforms.shadowMapSize=shadow.mapSize,state.directionalShadow[directionalLength]=shadowUniforms,state.directionalShadowMap[directionalLength]=shadowMap,state.directionalShadowMatrix[directionalLength]=light.shadow.matrix,numDirectionalShadows++}state.directional[directionalLength]=uniforms,directionalLength++}else if(light.isSpotLight){let uniforms=cache.get(light);uniforms.position.setFromMatrixPosition(light.matrixWorld),uniforms.color.copy(color).multiplyScalar(intensity),uniforms.distance=distance,uniforms.coneCos=Math.cos(light.angle),uniforms.penumbraCos=Math.cos(light.angle*(1-light.penumbra)),uniforms.decay=light.decay,state.spot[spotLength]=uniforms;let shadow=light.shadow;if(light.map){if(state.spotLightMap[numSpotMaps]=light.map,numSpotMaps++,shadow.updateMatrices(light),light.castShadow)numSpotShadowsWithMaps++}if(state.spotLightMatrix[spotLength]=shadow.matrix,light.castShadow){let shadowUniforms=shadowCache.get(light);shadowUniforms.shadowIntensity=shadow.intensity,shadowUniforms.shadowBias=shadow.bias,shadowUniforms.shadowNormalBias=shadow.normalBias,shadowUniforms.shadowRadius=shadow.radius,shadowUniforms.shadowMapSize=shadow.mapSize,state.spotShadow[spotLength]=shadowUniforms,state.spotShadowMap[spotLength]=shadowMap,numSpotShadows++}spotLength++}else if(light.isRectAreaLight){let uniforms=cache.get(light);uniforms.color.copy(color).multiplyScalar(intensity),uniforms.halfWidth.set(light.width*0.5,0,0),uniforms.halfHeight.set(0,light.height*0.5,0),state.rectArea[rectAreaLength]=uniforms,rectAreaLength++}else if(light.isPointLight){let uniforms=cache.get(light);if(uniforms.color.copy(light.color).multiplyScalar(light.intensity),uniforms.distance=light.distance,uniforms.decay=light.decay,light.castShadow){let shadow=light.shadow,shadowUniforms=shadowCache.get(light);shadowUniforms.shadowIntensity=shadow.intensity,shadowUniforms.shadowBias=shadow.bias,shadowUniforms.shadowNormalBias=shadow.normalBias,shadowUniforms.shadowRadius=shadow.radius,shadowUniforms.shadowMapSize=shadow.mapSize,shadowUniforms.shadowCameraNear=shadow.camera.near,shadowUniforms.shadowCameraFar=shadow.camera.far,state.pointShadow[pointLength]=shadowUniforms,state.pointShadowMap[pointLength]=shadowMap,state.pointShadowMatrix[pointLength]=light.shadow.matrix,numPointShadows++}state.point[pointLength]=uniforms,pointLength++}else if(light.isHemisphereLight){let uniforms=cache.get(light);uniforms.skyColor.copy(light.color).multiplyScalar(intensity),uniforms.groundColor.copy(light.groundColor).multiplyScalar(intensity),state.hemi[hemiLength]=uniforms,hemiLength++}}if(rectAreaLength>0)if(extensions.has("OES_texture_float_linear")===!0)state.rectAreaLTC1=UniformsLib.LTC_FLOAT_1,state.rectAreaLTC2=UniformsLib.LTC_FLOAT_2;else state.rectAreaLTC1=UniformsLib.LTC_HALF_1,state.rectAreaLTC2=UniformsLib.LTC_HALF_2;state.ambient[0]=r,state.ambient[1]=g,state.ambient[2]=b;let hash=state.hash;if(hash.directionalLength!==directionalLength||hash.pointLength!==pointLength||hash.spotLength!==spotLength||hash.rectAreaLength!==rectAreaLength||hash.hemiLength!==hemiLength||hash.numDirectionalShadows!==numDirectionalShadows||hash.numPointShadows!==numPointShadows||hash.numSpotShadows!==numSpotShadows||hash.numSpotMaps!==numSpotMaps||hash.numLightProbes!==numLightProbes)state.directional.length=directionalLength,state.spot.length=spotLength,state.rectArea.length=rectAreaLength,state.point.length=pointLength,state.hemi.length=hemiLength,state.directionalShadow.length=numDirectionalShadows,state.directionalShadowMap.length=numDirectionalShadows,state.pointShadow.length=numPointShadows,state.pointShadowMap.length=numPointShadows,state.spotShadow.length=numSpotShadows,state.spotShadowMap.length=numSpotShadows,state.directionalShadowMatrix.length=numDirectionalShadows,state.pointShadowMatrix.length=numPointShadows,state.spotLightMatrix.length=numSpotShadows+numSpotMaps-numSpotShadowsWithMaps,state.spotLightMap.length=numSpotMaps,state.numSpotLightShadowsWithMaps=numSpotShadowsWithMaps,state.numLightProbes=numLightProbes,hash.directionalLength=directionalLength,hash.pointLength=pointLength,hash.spotLength=spotLength,hash.rectAreaLength=rectAreaLength,hash.hemiLength=hemiLength,hash.numDirectionalShadows=numDirectionalShadows,hash.numPointShadows=numPointShadows,hash.numSpotShadows=numSpotShadows,hash.numSpotMaps=numSpotMaps,hash.numLightProbes=numLightProbes,state.version=nextVersion++}function setupView(lights,camera){let directionalLength=0,pointLength=0,spotLength=0,rectAreaLength=0,hemiLength=0,viewMatrix=camera.matrixWorldInverse;for(let i=0,l=lights.length;i<l;i++){let light=lights[i];if(light.isDirectionalLight){let uniforms=state.directional[directionalLength];uniforms.direction.setFromMatrixPosition(light.matrixWorld),vector3.setFromMatrixPosition(light.target.matrixWorld),uniforms.direction.sub(vector3),uniforms.direction.transformDirection(viewMatrix),directionalLength++}else if(light.isSpotLight){let uniforms=state.spot[spotLength];uniforms.position.setFromMatrixPosition(light.matrixWorld),uniforms.position.applyMatrix4(viewMatrix),uniforms.direction.setFromMatrixPosition(light.matrixWorld),vector3.setFromMatrixPosition(light.target.matrixWorld),uniforms.direction.sub(vector3),uniforms.direction.transformDirection(viewMatrix),spotLength++}else if(light.isRectAreaLight){let uniforms=state.rectArea[rectAreaLength];uniforms.position.setFromMatrixPosition(light.matrixWorld),uniforms.position.applyMatrix4(viewMatrix),matrix42.identity(),matrix4.copy(light.matrixWorld),matrix4.premultiply(viewMatrix),matrix42.extractRotation(matrix4),uniforms.halfWidth.set(light.width*0.5,0,0),uniforms.halfHeight.set(0,light.height*0.5,0),uniforms.halfWidth.applyMatrix4(matrix42),uniforms.halfHeight.applyMatrix4(matrix42),rectAreaLength++}else if(light.isPointLight){let uniforms=state.point[pointLength];uniforms.position.setFromMatrixPosition(light.matrixWorld),uniforms.position.applyMatrix4(viewMatrix),pointLength++}else if(light.isHemisphereLight){let uniforms=state.hemi[hemiLength];uniforms.direction.setFromMatrixPosition(light.matrixWorld),uniforms.direction.transformDirection(viewMatrix),hemiLength++}}}return{setup,setupView,state}}function WebGLRenderState(extensions){let lights=new WebGLLights(extensions),lightsArray=[],shadowsArray=[],lightProbeGridArray=[];function init(camera){state.camera=camera,lightsArray.length=0,shadowsArray.length=0,lightProbeGridArray.length=0}function pushLight(light){lightsArray.push(light)}function pushShadow(shadowLight){shadowsArray.push(shadowLight)}function pushLightProbeGrid(volume){lightProbeGridArray.push(volume)}function setupLights(){lights.setup(lightsArray)}function setupLightsView(camera){lights.setupView(lightsArray,camera)}let state={lightsArray,shadowsArray,lightProbeGridArray,camera:null,lights,transmissionRenderTarget:{},textureUnits:0};return{init,state,setupLights,setupLightsView,pushLight,pushShadow,pushLightProbeGrid}}function WebGLRenderStates(extensions){let renderStates=new WeakMap;function get(scene,renderCallDepth=0){let renderStateArray=renderStates.get(scene),renderState;if(renderStateArray===void 0)renderState=new WebGLRenderState(extensions),renderStates.set(scene,[renderState]);else if(renderCallDepth>=renderStateArray.length)renderState=new WebGLRenderState(extensions),renderStateArray.push(renderState);else renderState=renderStateArray[renderCallDepth];return renderState}function dispose(){renderStates=new WeakMap}return{get,dispose}}var vertex=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,fragment=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,_cubeDirections=[new Vector3(1,0,0),new Vector3(-1,0,0),new Vector3(0,1,0),new Vector3(0,-1,0),new Vector3(0,0,1),new Vector3(0,0,-1)],_cubeUps=[new Vector3(0,-1,0),new Vector3(0,-1,0),new Vector3(0,0,1),new Vector3(0,0,-1),new Vector3(0,-1,0),new Vector3(0,-1,0)],_projScreenMatrix=new Matrix4,_lightPositionWorld=new Vector3,_lookTarget=new Vector3;function WebGLShadowMap(renderer,objects,capabilities){let _frustum=new Frustum,_shadowMapSize=new Vector2,_viewportSize=new Vector2,_viewport=new Vector4,_depthMaterial=new MeshDepthMaterial,_distanceMaterial=new MeshDistanceMaterial,_materialCache={},_maxTextureSize=capabilities.maxTextureSize,shadowSide={[FrontSide]:BackSide,[BackSide]:FrontSide,[DoubleSide]:DoubleSide},shadowMaterialVertical=new ShaderMaterial({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Vector2},radius:{value:4}},vertexShader:vertex,fragmentShader:fragment}),shadowMaterialHorizontal=shadowMaterialVertical.clone();shadowMaterialHorizontal.defines.HORIZONTAL_PASS=1;let fullScreenTri=new BufferGeometry;fullScreenTri.setAttribute("position",new BufferAttribute(new Float32Array([-1,-1,0.5,3,-1,0.5,-1,3,0.5]),3));let fullScreenMesh=new Mesh(fullScreenTri,shadowMaterialVertical),scope=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=PCFShadowMap;let _previousType=this.type;this.render=function(lights,scene,camera){if(scope.enabled===!1)return;if(scope.autoUpdate===!1&&scope.needsUpdate===!1)return;if(lights.length===0)return;if(this.type===PCFSoftShadowMap)warn("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=PCFShadowMap;let currentRenderTarget=renderer.getRenderTarget(),activeCubeFace=renderer.getActiveCubeFace(),activeMipmapLevel=renderer.getActiveMipmapLevel(),_state=renderer.state;if(_state.setBlending(NoBlending),_state.buffers.depth.getReversed()===!0)_state.buffers.color.setClear(0,0,0,0);else _state.buffers.color.setClear(1,1,1,1);_state.buffers.depth.setTest(!0),_state.setScissorTest(!1);let typeChanged=_previousType!==this.type;if(typeChanged)scene.traverse(function(object){if(object.material)if(Array.isArray(object.material))object.material.forEach((mat)=>mat.needsUpdate=!0);else object.material.needsUpdate=!0});for(let i=0,il=lights.length;i<il;i++){let light=lights[i],shadow=light.shadow;if(shadow===void 0){warn("WebGLShadowMap:",light,"has no shadow.");continue}if(shadow.autoUpdate===!1&&shadow.needsUpdate===!1)continue;_shadowMapSize.copy(shadow.mapSize);let shadowFrameExtents=shadow.getFrameExtents();if(_shadowMapSize.multiply(shadowFrameExtents),_viewportSize.copy(shadow.mapSize),_shadowMapSize.x>_maxTextureSize||_shadowMapSize.y>_maxTextureSize){if(_shadowMapSize.x>_maxTextureSize)_viewportSize.x=Math.floor(_maxTextureSize/shadowFrameExtents.x),_shadowMapSize.x=_viewportSize.x*shadowFrameExtents.x,shadow.mapSize.x=_viewportSize.x;if(_shadowMapSize.y>_maxTextureSize)_viewportSize.y=Math.floor(_maxTextureSize/shadowFrameExtents.y),_shadowMapSize.y=_viewportSize.y*shadowFrameExtents.y,shadow.mapSize.y=_viewportSize.y}let reversedDepthBuffer=renderer.state.buffers.depth.getReversed();if(shadow.camera._reversedDepth=reversedDepthBuffer,shadow.map===null||typeChanged===!0){if(shadow.map!==null){if(shadow.map.depthTexture!==null)shadow.map.depthTexture.dispose(),shadow.map.depthTexture=null;shadow.map.dispose()}if(this.type===VSMShadowMap){if(light.isPointLight){warn("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}shadow.map=new WebGLRenderTarget(_shadowMapSize.x,_shadowMapSize.y,{format:RGFormat,type:HalfFloatType,minFilter:LinearFilter,magFilter:LinearFilter,generateMipmaps:!1}),shadow.map.texture.name=light.name+".shadowMap",shadow.map.depthTexture=new DepthTexture(_shadowMapSize.x,_shadowMapSize.y,FloatType),shadow.map.depthTexture.name=light.name+".shadowMapDepth",shadow.map.depthTexture.format=DepthFormat,shadow.map.depthTexture.compareFunction=null,shadow.map.depthTexture.minFilter=NearestFilter,shadow.map.depthTexture.magFilter=NearestFilter}else{if(light.isPointLight)shadow.map=new WebGLCubeRenderTarget(_shadowMapSize.x),shadow.map.depthTexture=new CubeDepthTexture(_shadowMapSize.x,UnsignedIntType);else shadow.map=new WebGLRenderTarget(_shadowMapSize.x,_shadowMapSize.y),shadow.map.depthTexture=new DepthTexture(_shadowMapSize.x,_shadowMapSize.y,UnsignedIntType);if(shadow.map.depthTexture.name=light.name+".shadowMap",shadow.map.depthTexture.format=DepthFormat,this.type===PCFShadowMap)shadow.map.depthTexture.compareFunction=reversedDepthBuffer?GreaterEqualCompare:LessEqualCompare,shadow.map.depthTexture.minFilter=LinearFilter,shadow.map.depthTexture.magFilter=LinearFilter;else shadow.map.depthTexture.compareFunction=null,shadow.map.depthTexture.minFilter=NearestFilter,shadow.map.depthTexture.magFilter=NearestFilter}shadow.camera.updateProjectionMatrix()}let faceCount=shadow.map.isWebGLCubeRenderTarget?6:1;for(let face=0;face<faceCount;face++){if(shadow.map.isWebGLCubeRenderTarget)renderer.setRenderTarget(shadow.map,face),renderer.clear();else{if(face===0)renderer.setRenderTarget(shadow.map),renderer.clear();let viewport=shadow.getViewport(face);_viewport.set(_viewportSize.x*viewport.x,_viewportSize.y*viewport.y,_viewportSize.x*viewport.z,_viewportSize.y*viewport.w),_state.viewport(_viewport)}if(light.isPointLight){let{camera:camera2,matrix:shadowMatrix}=shadow,far=light.distance||camera2.far;if(far!==camera2.far)camera2.far=far,camera2.updateProjectionMatrix();_lightPositionWorld.setFromMatrixPosition(light.matrixWorld),camera2.position.copy(_lightPositionWorld),_lookTarget.copy(camera2.position),_lookTarget.add(_cubeDirections[face]),camera2.up.copy(_cubeUps[face]),camera2.lookAt(_lookTarget),camera2.updateMatrixWorld(),shadowMatrix.makeTranslation(-_lightPositionWorld.x,-_lightPositionWorld.y,-_lightPositionWorld.z),_projScreenMatrix.multiplyMatrices(camera2.projectionMatrix,camera2.matrixWorldInverse),shadow._frustum.setFromProjectionMatrix(_projScreenMatrix,camera2.coordinateSystem,camera2.reversedDepth)}else shadow.updateMatrices(light);_frustum=shadow.getFrustum(),renderObject(scene,camera,shadow.camera,light,this.type)}if(shadow.isPointLightShadow!==!0&&this.type===VSMShadowMap)VSMPass(shadow,camera);shadow.needsUpdate=!1}_previousType=this.type,scope.needsUpdate=!1,renderer.setRenderTarget(currentRenderTarget,activeCubeFace,activeMipmapLevel)};function VSMPass(shadow,camera){let geometry=objects.update(fullScreenMesh);if(shadowMaterialVertical.defines.VSM_SAMPLES!==shadow.blurSamples)shadowMaterialVertical.defines.VSM_SAMPLES=shadow.blurSamples,shadowMaterialHorizontal.defines.VSM_SAMPLES=shadow.blurSamples,shadowMaterialVertical.needsUpdate=!0,shadowMaterialHorizontal.needsUpdate=!0;if(shadow.mapPass===null)shadow.mapPass=new WebGLRenderTarget(_shadowMapSize.x,_shadowMapSize.y,{format:RGFormat,type:HalfFloatType});shadowMaterialVertical.uniforms.shadow_pass.value=shadow.map.depthTexture,shadowMaterialVertical.uniforms.resolution.value=shadow.mapSize,shadowMaterialVertical.uniforms.radius.value=shadow.radius,renderer.setRenderTarget(shadow.mapPass),renderer.clear(),renderer.renderBufferDirect(camera,null,geometry,shadowMaterialVertical,fullScreenMesh,null),shadowMaterialHorizontal.uniforms.shadow_pass.value=shadow.mapPass.texture,shadowMaterialHorizontal.uniforms.resolution.value=shadow.mapSize,shadowMaterialHorizontal.uniforms.radius.value=shadow.radius,renderer.setRenderTarget(shadow.map),renderer.clear(),renderer.renderBufferDirect(camera,null,geometry,shadowMaterialHorizontal,fullScreenMesh,null)}function getDepthMaterial(object,material,light,type){let result=null,customMaterial=light.isPointLight===!0?object.customDistanceMaterial:object.customDepthMaterial;if(customMaterial!==void 0)result=customMaterial;else if(result=light.isPointLight===!0?_distanceMaterial:_depthMaterial,renderer.localClippingEnabled&&material.clipShadows===!0&&Array.isArray(material.clippingPlanes)&&material.clippingPlanes.length!==0||material.displacementMap&&material.displacementScale!==0||material.alphaMap&&material.alphaTest>0||material.map&&material.alphaTest>0||material.alphaToCoverage===!0){let keyA=result.uuid,keyB=material.uuid,materialsForVariant=_materialCache[keyA];if(materialsForVariant===void 0)materialsForVariant={},_materialCache[keyA]=materialsForVariant;let cachedMaterial=materialsForVariant[keyB];if(cachedMaterial===void 0)cachedMaterial=result.clone(),materialsForVariant[keyB]=cachedMaterial,material.addEventListener("dispose",onMaterialDispose);result=cachedMaterial}if(result.visible=material.visible,result.wireframe=material.wireframe,type===VSMShadowMap)result.side=material.shadowSide!==null?material.shadowSide:material.side;else result.side=material.shadowSide!==null?material.shadowSide:shadowSide[material.side];if(result.alphaMap=material.alphaMap,result.alphaTest=material.alphaToCoverage===!0?0.5:material.alphaTest,result.map=material.map,result.clipShadows=material.clipShadows,result.clippingPlanes=material.clippingPlanes,result.clipIntersection=material.clipIntersection,result.displacementMap=material.displacementMap,result.displacementScale=material.displacementScale,result.displacementBias=material.displacementBias,result.wireframeLinewidth=material.wireframeLinewidth,result.linewidth=material.linewidth,light.isPointLight===!0&&result.isMeshDistanceMaterial===!0){let materialProperties=renderer.properties.get(result);materialProperties.light=light}return result}function renderObject(object,camera,shadowCamera,light,type){if(object.visible===!1)return;if(object.layers.test(camera.layers)&&(object.isMesh||object.isLine||object.isPoints)){if((object.castShadow||object.receiveShadow&&type===VSMShadowMap)&&(!object.frustumCulled||_frustum.intersectsObject(object))){object.modelViewMatrix.multiplyMatrices(shadowCamera.matrixWorldInverse,object.matrixWorld);let geometry=objects.update(object),material=object.material;if(Array.isArray(material)){let groups=geometry.groups;for(let k=0,kl=groups.length;k<kl;k++){let group=groups[k],groupMaterial=material[group.materialIndex];if(groupMaterial&&groupMaterial.visible){let depthMaterial=getDepthMaterial(object,groupMaterial,light,type);object.onBeforeShadow(renderer,object,camera,shadowCamera,geometry,depthMaterial,group),renderer.renderBufferDirect(shadowCamera,null,geometry,depthMaterial,object,group),object.onAfterShadow(renderer,object,camera,shadowCamera,geometry,depthMaterial,group)}}}else if(material.visible){let depthMaterial=getDepthMaterial(object,material,light,type);object.onBeforeShadow(renderer,object,camera,shadowCamera,geometry,depthMaterial,null),renderer.renderBufferDirect(shadowCamera,null,geometry,depthMaterial,object,null),object.onAfterShadow(renderer,object,camera,shadowCamera,geometry,depthMaterial,null)}}}let children=object.children;for(let i=0,l=children.length;i<l;i++)renderObject(children[i],camera,shadowCamera,light,type)}function onMaterialDispose(event){event.target.removeEventListener("dispose",onMaterialDispose);for(let id in _materialCache){let cache=_materialCache[id],uuid=event.target.uuid;if(uuid in cache)cache[uuid].dispose(),delete cache[uuid]}}}function WebGLState(gl,extensions){function ColorBuffer(){let locked=!1,color=new Vector4,currentColorMask=null,currentColorClear=new Vector4(0,0,0,0);return{setMask:function(colorMask){if(currentColorMask!==colorMask&&!locked)gl.colorMask(colorMask,colorMask,colorMask,colorMask),currentColorMask=colorMask},setLocked:function(lock){locked=lock},setClear:function(r,g,b,a,premultipliedAlpha){if(premultipliedAlpha===!0)r*=a,g*=a,b*=a;if(color.set(r,g,b,a),currentColorClear.equals(color)===!1)gl.clearColor(r,g,b,a),currentColorClear.copy(color)},reset:function(){locked=!1,currentColorMask=null,currentColorClear.set(-1,0,0,0)}}}function DepthBuffer(){let locked=!1,currentReversed=!1,currentDepthMask=null,currentDepthFunc=null,currentDepthClear=null;return{setReversed:function(reversed){if(currentReversed!==reversed){let ext=extensions.get("EXT_clip_control");if(reversed)ext.clipControlEXT(ext.LOWER_LEFT_EXT,ext.ZERO_TO_ONE_EXT);else ext.clipControlEXT(ext.LOWER_LEFT_EXT,ext.NEGATIVE_ONE_TO_ONE_EXT);currentReversed=reversed;let oldDepth=currentDepthClear;currentDepthClear=null,this.setClear(oldDepth)}},getReversed:function(){return currentReversed},setTest:function(depthTest){if(depthTest)enable(gl.DEPTH_TEST);else disable(gl.DEPTH_TEST)},setMask:function(depthMask){if(currentDepthMask!==depthMask&&!locked)gl.depthMask(depthMask),currentDepthMask=depthMask},setFunc:function(depthFunc){if(currentReversed)depthFunc=ReversedDepthFuncs[depthFunc];if(currentDepthFunc!==depthFunc){switch(depthFunc){case NeverDepth:gl.depthFunc(gl.NEVER);break;case AlwaysDepth:gl.depthFunc(gl.ALWAYS);break;case LessDepth:gl.depthFunc(gl.LESS);break;case LessEqualDepth:gl.depthFunc(gl.LEQUAL);break;case EqualDepth:gl.depthFunc(gl.EQUAL);break;case GreaterEqualDepth:gl.depthFunc(gl.GEQUAL);break;case GreaterDepth:gl.depthFunc(gl.GREATER);break;case NotEqualDepth:gl.depthFunc(gl.NOTEQUAL);break;default:gl.depthFunc(gl.LEQUAL)}currentDepthFunc=depthFunc}},setLocked:function(lock){locked=lock},setClear:function(depth){if(currentDepthClear!==depth){if(currentDepthClear=depth,currentReversed)depth=1-depth;gl.clearDepth(depth)}},reset:function(){locked=!1,currentDepthMask=null,currentDepthFunc=null,currentDepthClear=null,currentReversed=!1}}}function StencilBuffer(){let locked=!1,currentStencilMask=null,currentStencilFunc=null,currentStencilRef=null,currentStencilFuncMask=null,currentStencilFail=null,currentStencilZFail=null,currentStencilZPass=null,currentStencilClear=null;return{setTest:function(stencilTest){if(!locked)if(stencilTest)enable(gl.STENCIL_TEST);else disable(gl.STENCIL_TEST)},setMask:function(stencilMask){if(currentStencilMask!==stencilMask&&!locked)gl.stencilMask(stencilMask),currentStencilMask=stencilMask},setFunc:function(stencilFunc,stencilRef,stencilMask){if(currentStencilFunc!==stencilFunc||currentStencilRef!==stencilRef||currentStencilFuncMask!==stencilMask)gl.stencilFunc(stencilFunc,stencilRef,stencilMask),currentStencilFunc=stencilFunc,currentStencilRef=stencilRef,currentStencilFuncMask=stencilMask},setOp:function(stencilFail,stencilZFail,stencilZPass){if(currentStencilFail!==stencilFail||currentStencilZFail!==stencilZFail||currentStencilZPass!==stencilZPass)gl.stencilOp(stencilFail,stencilZFail,stencilZPass),currentStencilFail=stencilFail,currentStencilZFail=stencilZFail,currentStencilZPass=stencilZPass},setLocked:function(lock){locked=lock},setClear:function(stencil){if(currentStencilClear!==stencil)gl.clearStencil(stencil),currentStencilClear=stencil},reset:function(){locked=!1,currentStencilMask=null,currentStencilFunc=null,currentStencilRef=null,currentStencilFuncMask=null,currentStencilFail=null,currentStencilZFail=null,currentStencilZPass=null,currentStencilClear=null}}}let colorBuffer=new ColorBuffer,depthBuffer=new DepthBuffer,stencilBuffer=new StencilBuffer,uboBindings=new WeakMap,uboProgramMap=new WeakMap,enabledCapabilities={},parameters={},currentBoundFramebuffers={},currentDrawbuffers=new WeakMap,defaultDrawbuffers=[],currentProgram=null,currentBlendingEnabled=!1,currentBlending=null,currentBlendEquation=null,currentBlendSrc=null,currentBlendDst=null,currentBlendEquationAlpha=null,currentBlendSrcAlpha=null,currentBlendDstAlpha=null,currentBlendColor=new Color(0,0,0),currentBlendAlpha=0,currentPremultipledAlpha=!1,currentFlipSided=null,currentCullFace=null,currentLineWidth=null,currentPolygonOffsetFactor=null,currentPolygonOffsetUnits=null,maxTextures=gl.getParameter(gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS),lineWidthAvailable=!1,version=0,glVersion=gl.getParameter(gl.VERSION);if(glVersion.indexOf("WebGL")!==-1)version=parseFloat(/^WebGL (\d)/.exec(glVersion)[1]),lineWidthAvailable=version>=1;else if(glVersion.indexOf("OpenGL ES")!==-1)version=parseFloat(/^OpenGL ES (\d)/.exec(glVersion)[1]),lineWidthAvailable=version>=2;let currentTextureSlot=null,currentBoundTextures={},scissorParam=gl.getParameter(gl.SCISSOR_BOX),viewportParam=gl.getParameter(gl.VIEWPORT),currentScissor=new Vector4().fromArray(scissorParam),currentViewport=new Vector4().fromArray(viewportParam);function createTexture(type,target,count,dimensions){let data=new Uint8Array(4),texture=gl.createTexture();gl.bindTexture(type,texture),gl.texParameteri(type,gl.TEXTURE_MIN_FILTER,gl.NEAREST),gl.texParameteri(type,gl.TEXTURE_MAG_FILTER,gl.NEAREST);for(let i=0;i<count;i++)if(type===gl.TEXTURE_3D||type===gl.TEXTURE_2D_ARRAY)gl.texImage3D(target,0,gl.RGBA,1,1,dimensions,0,gl.RGBA,gl.UNSIGNED_BYTE,data);else gl.texImage2D(target+i,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,data);return texture}let emptyTextures={};emptyTextures[gl.TEXTURE_2D]=createTexture(gl.TEXTURE_2D,gl.TEXTURE_2D,1),emptyTextures[gl.TEXTURE_CUBE_MAP]=createTexture(gl.TEXTURE_CUBE_MAP,gl.TEXTURE_CUBE_MAP_POSITIVE_X,6),emptyTextures[gl.TEXTURE_2D_ARRAY]=createTexture(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_2D_ARRAY,1,1),emptyTextures[gl.TEXTURE_3D]=createTexture(gl.TEXTURE_3D,gl.TEXTURE_3D,1,1),colorBuffer.setClear(0,0,0,1),depthBuffer.setClear(1),stencilBuffer.setClear(0),enable(gl.DEPTH_TEST),depthBuffer.setFunc(LessEqualDepth),setFlipSided(!1),setCullFace(CullFaceBack),enable(gl.CULL_FACE),setBlending(NoBlending);function enable(id){if(enabledCapabilities[id]!==!0)gl.enable(id),enabledCapabilities[id]=!0}function disable(id){if(enabledCapabilities[id]!==!1)gl.disable(id),enabledCapabilities[id]=!1}function bindFramebuffer(target,framebuffer){if(currentBoundFramebuffers[target]!==framebuffer){if(gl.bindFramebuffer(target,framebuffer),currentBoundFramebuffers[target]=framebuffer,target===gl.DRAW_FRAMEBUFFER)currentBoundFramebuffers[gl.FRAMEBUFFER]=framebuffer;if(target===gl.FRAMEBUFFER)currentBoundFramebuffers[gl.DRAW_FRAMEBUFFER]=framebuffer;return!0}return!1}function drawBuffers(renderTarget,framebuffer){let drawBuffers2=defaultDrawbuffers,needsUpdate=!1;if(renderTarget){if(drawBuffers2=currentDrawbuffers.get(framebuffer),drawBuffers2===void 0)drawBuffers2=[],currentDrawbuffers.set(framebuffer,drawBuffers2);let textures=renderTarget.textures;if(drawBuffers2.length!==textures.length||drawBuffers2[0]!==gl.COLOR_ATTACHMENT0){for(let i=0,il=textures.length;i<il;i++)drawBuffers2[i]=gl.COLOR_ATTACHMENT0+i;drawBuffers2.length=textures.length,needsUpdate=!0}}else if(drawBuffers2[0]!==gl.BACK)drawBuffers2[0]=gl.BACK,needsUpdate=!0;if(needsUpdate)gl.drawBuffers(drawBuffers2)}function useProgram(program){if(currentProgram!==program)return gl.useProgram(program),currentProgram=program,!0;return!1}let equationToGL={[AddEquation]:gl.FUNC_ADD,[SubtractEquation]:gl.FUNC_SUBTRACT,[ReverseSubtractEquation]:gl.FUNC_REVERSE_SUBTRACT};equationToGL[MinEquation]=gl.MIN,equationToGL[MaxEquation]=gl.MAX;let factorToGL={[ZeroFactor]:gl.ZERO,[OneFactor]:gl.ONE,[SrcColorFactor]:gl.SRC_COLOR,[SrcAlphaFactor]:gl.SRC_ALPHA,[SrcAlphaSaturateFactor]:gl.SRC_ALPHA_SATURATE,[DstColorFactor]:gl.DST_COLOR,[DstAlphaFactor]:gl.DST_ALPHA,[OneMinusSrcColorFactor]:gl.ONE_MINUS_SRC_COLOR,[OneMinusSrcAlphaFactor]:gl.ONE_MINUS_SRC_ALPHA,[OneMinusDstColorFactor]:gl.ONE_MINUS_DST_COLOR,[OneMinusDstAlphaFactor]:gl.ONE_MINUS_DST_ALPHA,[ConstantColorFactor]:gl.CONSTANT_COLOR,[OneMinusConstantColorFactor]:gl.ONE_MINUS_CONSTANT_COLOR,[ConstantAlphaFactor]:gl.CONSTANT_ALPHA,[OneMinusConstantAlphaFactor]:gl.ONE_MINUS_CONSTANT_ALPHA};function setBlending(blending,blendEquation,blendSrc,blendDst,blendEquationAlpha,blendSrcAlpha,blendDstAlpha,blendColor,blendAlpha,premultipliedAlpha){if(blending===NoBlending){if(currentBlendingEnabled===!0)disable(gl.BLEND),currentBlendingEnabled=!1;return}if(currentBlendingEnabled===!1)enable(gl.BLEND),currentBlendingEnabled=!0;if(blending!==CustomBlending){if(blending!==currentBlending||premultipliedAlpha!==currentPremultipledAlpha){if(currentBlendEquation!==AddEquation||currentBlendEquationAlpha!==AddEquation)gl.blendEquation(gl.FUNC_ADD),currentBlendEquation=AddEquation,currentBlendEquationAlpha=AddEquation;if(premultipliedAlpha)switch(blending){case NormalBlending:gl.blendFuncSeparate(gl.ONE,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);break;case AdditiveBlending:gl.blendFunc(gl.ONE,gl.ONE);break;case SubtractiveBlending:gl.blendFuncSeparate(gl.ZERO,gl.ONE_MINUS_SRC_COLOR,gl.ZERO,gl.ONE);break;case MultiplyBlending:gl.blendFuncSeparate(gl.DST_COLOR,gl.ONE_MINUS_SRC_ALPHA,gl.ZERO,gl.ONE);break;default:error("WebGLState: Invalid blending: ",blending);break}else switch(blending){case NormalBlending:gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);break;case AdditiveBlending:gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE,gl.ONE,gl.ONE);break;case SubtractiveBlending:error("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case MultiplyBlending:error("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:error("WebGLState: Invalid blending: ",blending);break}currentBlendSrc=null,currentBlendDst=null,currentBlendSrcAlpha=null,currentBlendDstAlpha=null,currentBlendColor.set(0,0,0),currentBlendAlpha=0,currentBlending=blending,currentPremultipledAlpha=premultipliedAlpha}return}if(blendEquationAlpha=blendEquationAlpha||blendEquation,blendSrcAlpha=blendSrcAlpha||blendSrc,blendDstAlpha=blendDstAlpha||blendDst,blendEquation!==currentBlendEquation||blendEquationAlpha!==currentBlendEquationAlpha)gl.blendEquationSeparate(equationToGL[blendEquation],equationToGL[blendEquationAlpha]),currentBlendEquation=blendEquation,currentBlendEquationAlpha=blendEquationAlpha;if(blendSrc!==currentBlendSrc||blendDst!==currentBlendDst||blendSrcAlpha!==currentBlendSrcAlpha||blendDstAlpha!==currentBlendDstAlpha)gl.blendFuncSeparate(factorToGL[blendSrc],factorToGL[blendDst],factorToGL[blendSrcAlpha],factorToGL[blendDstAlpha]),currentBlendSrc=blendSrc,currentBlendDst=blendDst,currentBlendSrcAlpha=blendSrcAlpha,currentBlendDstAlpha=blendDstAlpha;if(blendColor.equals(currentBlendColor)===!1||blendAlpha!==currentBlendAlpha)gl.blendColor(blendColor.r,blendColor.g,blendColor.b,blendAlpha),currentBlendColor.copy(blendColor),currentBlendAlpha=blendAlpha;currentBlending=blending,currentPremultipledAlpha=!1}function setMaterial(material,frontFaceCW){material.side===DoubleSide?disable(gl.CULL_FACE):enable(gl.CULL_FACE);let flipSided=material.side===BackSide;if(frontFaceCW)flipSided=!flipSided;setFlipSided(flipSided),material.blending===NormalBlending&&material.transparent===!1?setBlending(NoBlending):setBlending(material.blending,material.blendEquation,material.blendSrc,material.blendDst,material.blendEquationAlpha,material.blendSrcAlpha,material.blendDstAlpha,material.blendColor,material.blendAlpha,material.premultipliedAlpha),depthBuffer.setFunc(material.depthFunc),depthBuffer.setTest(material.depthTest),depthBuffer.setMask(material.depthWrite),colorBuffer.setMask(material.colorWrite);let stencilWrite=material.stencilWrite;if(stencilBuffer.setTest(stencilWrite),stencilWrite)stencilBuffer.setMask(material.stencilWriteMask),stencilBuffer.setFunc(material.stencilFunc,material.stencilRef,material.stencilFuncMask),stencilBuffer.setOp(material.stencilFail,material.stencilZFail,material.stencilZPass);setPolygonOffset(material.polygonOffset,material.polygonOffsetFactor,material.polygonOffsetUnits),material.alphaToCoverage===!0?enable(gl.SAMPLE_ALPHA_TO_COVERAGE):disable(gl.SAMPLE_ALPHA_TO_COVERAGE)}function setFlipSided(flipSided){if(currentFlipSided!==flipSided){if(flipSided)gl.frontFace(gl.CW);else gl.frontFace(gl.CCW);currentFlipSided=flipSided}}function setCullFace(cullFace){if(cullFace!==CullFaceNone){if(enable(gl.CULL_FACE),cullFace!==currentCullFace)if(cullFace===CullFaceBack)gl.cullFace(gl.BACK);else if(cullFace===CullFaceFront)gl.cullFace(gl.FRONT);else gl.cullFace(gl.FRONT_AND_BACK)}else disable(gl.CULL_FACE);currentCullFace=cullFace}function setLineWidth(width){if(width!==currentLineWidth){if(lineWidthAvailable)gl.lineWidth(width);currentLineWidth=width}}function setPolygonOffset(polygonOffset,factor,units){if(polygonOffset){if(enable(gl.POLYGON_OFFSET_FILL),currentPolygonOffsetFactor!==factor||currentPolygonOffsetUnits!==units){if(currentPolygonOffsetFactor=factor,currentPolygonOffsetUnits=units,depthBuffer.getReversed())factor=-factor;gl.polygonOffset(factor,units)}}else disable(gl.POLYGON_OFFSET_FILL)}function setScissorTest(scissorTest){if(scissorTest)enable(gl.SCISSOR_TEST);else disable(gl.SCISSOR_TEST)}function activeTexture(webglSlot){if(webglSlot===void 0)webglSlot=gl.TEXTURE0+maxTextures-1;if(currentTextureSlot!==webglSlot)gl.activeTexture(webglSlot),currentTextureSlot=webglSlot}function bindTexture(webglType,webglTexture,webglSlot){if(webglSlot===void 0)if(currentTextureSlot===null)webglSlot=gl.TEXTURE0+maxTextures-1;else webglSlot=currentTextureSlot;let boundTexture=currentBoundTextures[webglSlot];if(boundTexture===void 0)boundTexture={type:void 0,texture:void 0},currentBoundTextures[webglSlot]=boundTexture;if(boundTexture.type!==webglType||boundTexture.texture!==webglTexture){if(currentTextureSlot!==webglSlot)gl.activeTexture(webglSlot),currentTextureSlot=webglSlot;gl.bindTexture(webglType,webglTexture||emptyTextures[webglType]),boundTexture.type=webglType,boundTexture.texture=webglTexture}}function unbindTexture(){let boundTexture=currentBoundTextures[currentTextureSlot];if(boundTexture!==void 0&&boundTexture.type!==void 0)gl.bindTexture(boundTexture.type,null),boundTexture.type=void 0,boundTexture.texture=void 0}function compressedTexImage2D(){try{gl.compressedTexImage2D(...arguments)}catch(e){error("WebGLState:",e)}}function compressedTexImage3D(){try{gl.compressedTexImage3D(...arguments)}catch(e){error("WebGLState:",e)}}function texSubImage2D(){try{gl.texSubImage2D(...arguments)}catch(e){error("WebGLState:",e)}}function texSubImage3D(){try{gl.texSubImage3D(...arguments)}catch(e){error("WebGLState:",e)}}function compressedTexSubImage2D(){try{gl.compressedTexSubImage2D(...arguments)}catch(e){error("WebGLState:",e)}}function compressedTexSubImage3D(){try{gl.compressedTexSubImage3D(...arguments)}catch(e){error("WebGLState:",e)}}function texStorage2D(){try{gl.texStorage2D(...arguments)}catch(e){error("WebGLState:",e)}}function texStorage3D(){try{gl.texStorage3D(...arguments)}catch(e){error("WebGLState:",e)}}function texImage2D(){try{gl.texImage2D(...arguments)}catch(e){error("WebGLState:",e)}}function texImage3D(){try{gl.texImage3D(...arguments)}catch(e){error("WebGLState:",e)}}function getParameter(name){if(parameters[name]!==void 0)return parameters[name];else return gl.getParameter(name)}function pixelStorei(name,value){if(parameters[name]!==value)gl.pixelStorei(name,value),parameters[name]=value}function scissor(scissor2){if(currentScissor.equals(scissor2)===!1)gl.scissor(scissor2.x,scissor2.y,scissor2.z,scissor2.w),currentScissor.copy(scissor2)}function viewport(viewport2){if(currentViewport.equals(viewport2)===!1)gl.viewport(viewport2.x,viewport2.y,viewport2.z,viewport2.w),currentViewport.copy(viewport2)}function updateUBOMapping(uniformsGroup,program){let mapping=uboProgramMap.get(program);if(mapping===void 0)mapping=new WeakMap,uboProgramMap.set(program,mapping);let blockIndex=mapping.get(uniformsGroup);if(blockIndex===void 0)blockIndex=gl.getUniformBlockIndex(program,uniformsGroup.name),mapping.set(uniformsGroup,blockIndex)}function uniformBlockBinding(uniformsGroup,program){let blockIndex=uboProgramMap.get(program).get(uniformsGroup);if(uboBindings.get(program)!==blockIndex)gl.uniformBlockBinding(program,blockIndex,uniformsGroup.__bindingPointIndex),uboBindings.set(program,blockIndex)}function reset(){gl.disable(gl.BLEND),gl.disable(gl.CULL_FACE),gl.disable(gl.DEPTH_TEST),gl.disable(gl.POLYGON_OFFSET_FILL),gl.disable(gl.SCISSOR_TEST),gl.disable(gl.STENCIL_TEST),gl.disable(gl.SAMPLE_ALPHA_TO_COVERAGE),gl.blendEquation(gl.FUNC_ADD),gl.blendFunc(gl.ONE,gl.ZERO),gl.blendFuncSeparate(gl.ONE,gl.ZERO,gl.ONE,gl.ZERO),gl.blendColor(0,0,0,0),gl.colorMask(!0,!0,!0,!0),gl.clearColor(0,0,0,0),gl.depthMask(!0),gl.depthFunc(gl.LESS),depthBuffer.setReversed(!1),gl.clearDepth(1),gl.stencilMask(4294967295),gl.stencilFunc(gl.ALWAYS,0,4294967295),gl.stencilOp(gl.KEEP,gl.KEEP,gl.KEEP),gl.clearStencil(0),gl.cullFace(gl.BACK),gl.frontFace(gl.CCW),gl.polygonOffset(0,0),gl.activeTexture(gl.TEXTURE0),gl.bindFramebuffer(gl.FRAMEBUFFER,null),gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,null),gl.bindFramebuffer(gl.READ_FRAMEBUFFER,null),gl.useProgram(null),gl.lineWidth(1),gl.scissor(0,0,gl.canvas.width,gl.canvas.height),gl.viewport(0,0,gl.canvas.width,gl.canvas.height),gl.pixelStorei(gl.PACK_ALIGNMENT,4),gl.pixelStorei(gl.UNPACK_ALIGNMENT,4),gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,!1),gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL,gl.BROWSER_DEFAULT_WEBGL),gl.pixelStorei(gl.PACK_ROW_LENGTH,0),gl.pixelStorei(gl.PACK_SKIP_PIXELS,0),gl.pixelStorei(gl.PACK_SKIP_ROWS,0),gl.pixelStorei(gl.UNPACK_ROW_LENGTH,0),gl.pixelStorei(gl.UNPACK_IMAGE_HEIGHT,0),gl.pixelStorei(gl.UNPACK_SKIP_PIXELS,0),gl.pixelStorei(gl.UNPACK_SKIP_ROWS,0),gl.pixelStorei(gl.UNPACK_SKIP_IMAGES,0),enabledCapabilities={},parameters={},currentTextureSlot=null,currentBoundTextures={},currentBoundFramebuffers={},currentDrawbuffers=new WeakMap,defaultDrawbuffers=[],currentProgram=null,currentBlendingEnabled=!1,currentBlending=null,currentBlendEquation=null,currentBlendSrc=null,currentBlendDst=null,currentBlendEquationAlpha=null,currentBlendSrcAlpha=null,currentBlendDstAlpha=null,currentBlendColor=new Color(0,0,0),currentBlendAlpha=0,currentPremultipledAlpha=!1,currentFlipSided=null,currentCullFace=null,currentLineWidth=null,currentPolygonOffsetFactor=null,currentPolygonOffsetUnits=null,currentScissor.set(0,0,gl.canvas.width,gl.canvas.height),currentViewport.set(0,0,gl.canvas.width,gl.canvas.height),colorBuffer.reset(),depthBuffer.reset(),stencilBuffer.reset()}return{buffers:{color:colorBuffer,depth:depthBuffer,stencil:stencilBuffer},enable,disable,bindFramebuffer,drawBuffers,useProgram,setBlending,setMaterial,setFlipSided,setCullFace,setLineWidth,setPolygonOffset,setScissorTest,activeTexture,bindTexture,unbindTexture,compressedTexImage2D,compressedTexImage3D,texImage2D,texImage3D,pixelStorei,getParameter,updateUBOMapping,uniformBlockBinding,texStorage2D,texStorage3D,texSubImage2D,texSubImage3D,compressedTexSubImage2D,compressedTexSubImage3D,scissor,viewport,reset}}function WebGLTextures(_gl,extensions,state,properties,capabilities,utils,info){let multisampledRTTExt=extensions.has("WEBGL_multisampled_render_to_texture")?extensions.get("WEBGL_multisampled_render_to_texture"):null,supportsInvalidateFramebuffer=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),_imageDimensions=new Vector2,_videoTextures=new WeakMap,_htmlTextures=new Set,_canvas,_sources=new WeakMap,useOffscreenCanvas=!1;try{useOffscreenCanvas=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch(err){}function createCanvas(width,height){return useOffscreenCanvas?new OffscreenCanvas(width,height):createElementNS("canvas")}function resizeImage(image,needsNewCanvas,maxSize){let scale=1,dimensions=getDimensions(image);if(dimensions.width>maxSize||dimensions.height>maxSize)scale=maxSize/Math.max(dimensions.width,dimensions.height);if(scale<1)if(typeof HTMLImageElement<"u"&&image instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&image instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&image instanceof ImageBitmap||typeof VideoFrame<"u"&&image instanceof VideoFrame){let width=Math.floor(scale*dimensions.width),height=Math.floor(scale*dimensions.height);if(_canvas===void 0)_canvas=createCanvas(width,height);let canvas=needsNewCanvas?createCanvas(width,height):_canvas;return canvas.width=width,canvas.height=height,canvas.getContext("2d").drawImage(image,0,0,width,height),warn("WebGLRenderer: Texture has been resized from ("+dimensions.width+"x"+dimensions.height+") to ("+width+"x"+height+")."),canvas}else{if("data"in image)warn("WebGLRenderer: Image in DataTexture is too big ("+dimensions.width+"x"+dimensions.height+").");return image}return image}function textureNeedsGenerateMipmaps(texture){return texture.generateMipmaps}function generateMipmap(target){_gl.generateMipmap(target)}function getTargetType(texture){if(texture.isWebGLCubeRenderTarget)return _gl.TEXTURE_CUBE_MAP;if(texture.isWebGL3DRenderTarget)return _gl.TEXTURE_3D;if(texture.isWebGLArrayRenderTarget||texture.isCompressedArrayTexture)return _gl.TEXTURE_2D_ARRAY;return _gl.TEXTURE_2D}function getInternalFormat(internalFormatName,glFormat,glType,normalized,colorSpace,forceLinearTransfer=!1){if(internalFormatName!==null){if(_gl[internalFormatName]!==void 0)return _gl[internalFormatName];warn("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+internalFormatName+"'")}let ext_texture_norm16;if(normalized){if(ext_texture_norm16=extensions.get("EXT_texture_norm16"),!ext_texture_norm16)warn("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension")}let internalFormat=glFormat;if(glFormat===_gl.RED){if(glType===_gl.FLOAT)internalFormat=_gl.R32F;if(glType===_gl.HALF_FLOAT)internalFormat=_gl.R16F;if(glType===_gl.UNSIGNED_BYTE)internalFormat=_gl.R8;if(glType===_gl.UNSIGNED_SHORT&&ext_texture_norm16)internalFormat=ext_texture_norm16.R16_EXT;if(glType===_gl.SHORT&&ext_texture_norm16)internalFormat=ext_texture_norm16.R16_SNORM_EXT}if(glFormat===_gl.RED_INTEGER){if(glType===_gl.UNSIGNED_BYTE)internalFormat=_gl.R8UI;if(glType===_gl.UNSIGNED_SHORT)internalFormat=_gl.R16UI;if(glType===_gl.UNSIGNED_INT)internalFormat=_gl.R32UI;if(glType===_gl.BYTE)internalFormat=_gl.R8I;if(glType===_gl.SHORT)internalFormat=_gl.R16I;if(glType===_gl.INT)internalFormat=_gl.R32I}if(glFormat===_gl.RG){if(glType===_gl.FLOAT)internalFormat=_gl.RG32F;if(glType===_gl.HALF_FLOAT)internalFormat=_gl.RG16F;if(glType===_gl.UNSIGNED_BYTE)internalFormat=_gl.RG8;if(glType===_gl.UNSIGNED_SHORT&&ext_texture_norm16)internalFormat=ext_texture_norm16.RG16_EXT;if(glType===_gl.SHORT&&ext_texture_norm16)internalFormat=ext_texture_norm16.RG16_SNORM_EXT}if(glFormat===_gl.RG_INTEGER){if(glType===_gl.UNSIGNED_BYTE)internalFormat=_gl.RG8UI;if(glType===_gl.UNSIGNED_SHORT)internalFormat=_gl.RG16UI;if(glType===_gl.UNSIGNED_INT)internalFormat=_gl.RG32UI;if(glType===_gl.BYTE)internalFormat=_gl.RG8I;if(glType===_gl.SHORT)internalFormat=_gl.RG16I;if(glType===_gl.INT)internalFormat=_gl.RG32I}if(glFormat===_gl.RGB_INTEGER){if(glType===_gl.UNSIGNED_BYTE)internalFormat=_gl.RGB8UI;if(glType===_gl.UNSIGNED_SHORT)internalFormat=_gl.RGB16UI;if(glType===_gl.UNSIGNED_INT)internalFormat=_gl.RGB32UI;if(glType===_gl.BYTE)internalFormat=_gl.RGB8I;if(glType===_gl.SHORT)internalFormat=_gl.RGB16I;if(glType===_gl.INT)internalFormat=_gl.RGB32I}if(glFormat===_gl.RGBA_INTEGER){if(glType===_gl.UNSIGNED_BYTE)internalFormat=_gl.RGBA8UI;if(glType===_gl.UNSIGNED_SHORT)internalFormat=_gl.RGBA16UI;if(glType===_gl.UNSIGNED_INT)internalFormat=_gl.RGBA32UI;if(glType===_gl.BYTE)internalFormat=_gl.RGBA8I;if(glType===_gl.SHORT)internalFormat=_gl.RGBA16I;if(glType===_gl.INT)internalFormat=_gl.RGBA32I}if(glFormat===_gl.RGB){if(glType===_gl.UNSIGNED_SHORT&&ext_texture_norm16)internalFormat=ext_texture_norm16.RGB16_EXT;if(glType===_gl.SHORT&&ext_texture_norm16)internalFormat=ext_texture_norm16.RGB16_SNORM_EXT;if(glType===_gl.UNSIGNED_INT_5_9_9_9_REV)internalFormat=_gl.RGB9_E5;if(glType===_gl.UNSIGNED_INT_10F_11F_11F_REV)internalFormat=_gl.R11F_G11F_B10F}if(glFormat===_gl.RGBA){let transfer=forceLinearTransfer?LinearTransfer:ColorManagement.getTransfer(colorSpace);if(glType===_gl.FLOAT)internalFormat=_gl.RGBA32F;if(glType===_gl.HALF_FLOAT)internalFormat=_gl.RGBA16F;if(glType===_gl.UNSIGNED_BYTE)internalFormat=transfer===SRGBTransfer?_gl.SRGB8_ALPHA8:_gl.RGBA8;if(glType===_gl.UNSIGNED_SHORT&&ext_texture_norm16)internalFormat=ext_texture_norm16.RGBA16_EXT;if(glType===_gl.SHORT&&ext_texture_norm16)internalFormat=ext_texture_norm16.RGBA16_SNORM_EXT;if(glType===_gl.UNSIGNED_SHORT_4_4_4_4)internalFormat=_gl.RGBA4;if(glType===_gl.UNSIGNED_SHORT_5_5_5_1)internalFormat=_gl.RGB5_A1}if(internalFormat===_gl.R16F||internalFormat===_gl.R32F||internalFormat===_gl.RG16F||internalFormat===_gl.RG32F||internalFormat===_gl.RGBA16F||internalFormat===_gl.RGBA32F)extensions.get("EXT_color_buffer_float");return internalFormat}function getInternalDepthFormat(useStencil,depthType){let glInternalFormat;if(useStencil){if(depthType===null||depthType===UnsignedIntType||depthType===UnsignedInt248Type)glInternalFormat=_gl.DEPTH24_STENCIL8;else if(depthType===FloatType)glInternalFormat=_gl.DEPTH32F_STENCIL8;else if(depthType===UnsignedShortType)glInternalFormat=_gl.DEPTH24_STENCIL8,warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")}else if(depthType===null||depthType===UnsignedIntType||depthType===UnsignedInt248Type)glInternalFormat=_gl.DEPTH_COMPONENT24;else if(depthType===FloatType)glInternalFormat=_gl.DEPTH_COMPONENT32F;else if(depthType===UnsignedShortType)glInternalFormat=_gl.DEPTH_COMPONENT16;return glInternalFormat}function getMipLevels(texture,image){if(textureNeedsGenerateMipmaps(texture)===!0||texture.isFramebufferTexture&&texture.minFilter!==NearestFilter&&texture.minFilter!==LinearFilter)return Math.log2(Math.max(image.width,image.height))+1;else if(texture.mipmaps!==void 0&&texture.mipmaps.length>0)return texture.mipmaps.length;else if(texture.isCompressedTexture&&Array.isArray(texture.image))return image.mipmaps.length;else return 1}function onTextureDispose(event){let texture=event.target;if(texture.removeEventListener("dispose",onTextureDispose),deallocateTexture(texture),texture.isVideoTexture)_videoTextures.delete(texture);if(texture.isHTMLTexture)_htmlTextures.delete(texture)}function onRenderTargetDispose(event){let renderTarget=event.target;renderTarget.removeEventListener("dispose",onRenderTargetDispose),deallocateRenderTarget(renderTarget)}function deallocateTexture(texture){let textureProperties=properties.get(texture);if(textureProperties.__webglInit===void 0)return;let source=texture.source,webglTextures=_sources.get(source);if(webglTextures){let webglTexture=webglTextures[textureProperties.__cacheKey];if(webglTexture.usedTimes--,webglTexture.usedTimes===0)deleteTexture(texture);if(Object.keys(webglTextures).length===0)_sources.delete(source)}properties.remove(texture)}function deleteTexture(texture){let textureProperties=properties.get(texture);_gl.deleteTexture(textureProperties.__webglTexture);let source=texture.source,webglTextures=_sources.get(source);delete webglTextures[textureProperties.__cacheKey],info.memory.textures--}function deallocateRenderTarget(renderTarget){let renderTargetProperties=properties.get(renderTarget);if(renderTarget.depthTexture)renderTarget.depthTexture.dispose(),properties.remove(renderTarget.depthTexture);if(renderTarget.isWebGLCubeRenderTarget)for(let i=0;i<6;i++){if(Array.isArray(renderTargetProperties.__webglFramebuffer[i]))for(let level=0;level<renderTargetProperties.__webglFramebuffer[i].length;level++)_gl.deleteFramebuffer(renderTargetProperties.__webglFramebuffer[i][level]);else _gl.deleteFramebuffer(renderTargetProperties.__webglFramebuffer[i]);if(renderTargetProperties.__webglDepthbuffer)_gl.deleteRenderbuffer(renderTargetProperties.__webglDepthbuffer[i])}else{if(Array.isArray(renderTargetProperties.__webglFramebuffer))for(let level=0;level<renderTargetProperties.__webglFramebuffer.length;level++)_gl.deleteFramebuffer(renderTargetProperties.__webglFramebuffer[level]);else _gl.deleteFramebuffer(renderTargetProperties.__webglFramebuffer);if(renderTargetProperties.__webglDepthbuffer)_gl.deleteRenderbuffer(renderTargetProperties.__webglDepthbuffer);if(renderTargetProperties.__webglMultisampledFramebuffer)_gl.deleteFramebuffer(renderTargetProperties.__webglMultisampledFramebuffer);if(renderTargetProperties.__webglColorRenderbuffer){for(let i=0;i<renderTargetProperties.__webglColorRenderbuffer.length;i++)if(renderTargetProperties.__webglColorRenderbuffer[i])_gl.deleteRenderbuffer(renderTargetProperties.__webglColorRenderbuffer[i])}if(renderTargetProperties.__webglDepthRenderbuffer)_gl.deleteRenderbuffer(renderTargetProperties.__webglDepthRenderbuffer)}let textures=renderTarget.textures;for(let i=0,il=textures.length;i<il;i++){let attachmentProperties=properties.get(textures[i]);if(attachmentProperties.__webglTexture)_gl.deleteTexture(attachmentProperties.__webglTexture),info.memory.textures--;properties.remove(textures[i])}properties.remove(renderTarget)}let textureUnits=0;function resetTextureUnits(){textureUnits=0}function getTextureUnits(){return textureUnits}function setTextureUnits(value){textureUnits=value}function allocateTextureUnit(){let textureUnit=textureUnits;if(textureUnit>=capabilities.maxTextures)warn("WebGLTextures: Trying to use "+textureUnit+" texture units while this GPU supports only "+capabilities.maxTextures);return textureUnits+=1,textureUnit}function getTextureCacheKey(texture){let array=[];return array.push(texture.wrapS),array.push(texture.wrapT),array.push(texture.wrapR||0),array.push(texture.magFilter),array.push(texture.minFilter),array.push(texture.anisotropy),array.push(texture.internalFormat),array.push(texture.format),array.push(texture.type),array.push(texture.generateMipmaps),array.push(texture.premultiplyAlpha),array.push(texture.flipY),array.push(texture.unpackAlignment),array.push(texture.colorSpace),array.join()}function setTexture2D(texture,slot){let textureProperties=properties.get(texture);if(texture.isVideoTexture)updateVideoTexture(texture);if(texture.isRenderTargetTexture===!1&&texture.isExternalTexture!==!0&&texture.version>0&&textureProperties.__version!==texture.version){let image=texture.image;if(image===null)warn("WebGLRenderer: Texture marked for update but no image data found.");else if(image.complete===!1)warn("WebGLRenderer: Texture marked for update but image is incomplete");else{uploadTexture(textureProperties,texture,slot);return}}else if(texture.isExternalTexture)textureProperties.__webglTexture=texture.sourceTexture?texture.sourceTexture:null;state.bindTexture(_gl.TEXTURE_2D,textureProperties.__webglTexture,_gl.TEXTURE0+slot)}function setTexture2DArray(texture,slot){let textureProperties=properties.get(texture);if(texture.isRenderTargetTexture===!1&&texture.version>0&&textureProperties.__version!==texture.version){uploadTexture(textureProperties,texture,slot);return}else if(texture.isExternalTexture)textureProperties.__webglTexture=texture.sourceTexture?texture.sourceTexture:null;state.bindTexture(_gl.TEXTURE_2D_ARRAY,textureProperties.__webglTexture,_gl.TEXTURE0+slot)}function setTexture3D(texture,slot){let textureProperties=properties.get(texture);if(texture.isRenderTargetTexture===!1&&texture.version>0&&textureProperties.__version!==texture.version){uploadTexture(textureProperties,texture,slot);return}state.bindTexture(_gl.TEXTURE_3D,textureProperties.__webglTexture,_gl.TEXTURE0+slot)}function setTextureCube(texture,slot){let textureProperties=properties.get(texture);if(texture.isCubeDepthTexture!==!0&&texture.version>0&&textureProperties.__version!==texture.version){uploadCubeTexture(textureProperties,texture,slot);return}state.bindTexture(_gl.TEXTURE_CUBE_MAP,textureProperties.__webglTexture,_gl.TEXTURE0+slot)}let wrappingToGL={[RepeatWrapping]:_gl.REPEAT,[ClampToEdgeWrapping]:_gl.CLAMP_TO_EDGE,[MirroredRepeatWrapping]:_gl.MIRRORED_REPEAT},filterToGL={[NearestFilter]:_gl.NEAREST,[NearestMipmapNearestFilter]:_gl.NEAREST_MIPMAP_NEAREST,[NearestMipmapLinearFilter]:_gl.NEAREST_MIPMAP_LINEAR,[LinearFilter]:_gl.LINEAR,[LinearMipmapNearestFilter]:_gl.LINEAR_MIPMAP_NEAREST,[LinearMipmapLinearFilter]:_gl.LINEAR_MIPMAP_LINEAR},compareToGL={[NeverCompare]:_gl.NEVER,[AlwaysCompare]:_gl.ALWAYS,[LessCompare]:_gl.LESS,[LessEqualCompare]:_gl.LEQUAL,[EqualCompare]:_gl.EQUAL,[GreaterEqualCompare]:_gl.GEQUAL,[GreaterCompare]:_gl.GREATER,[NotEqualCompare]:_gl.NOTEQUAL};function setTextureParameters(textureType,texture){if(texture.type===FloatType&&extensions.has("OES_texture_float_linear")===!1&&(texture.magFilter===LinearFilter||texture.magFilter===LinearMipmapNearestFilter||texture.magFilter===NearestMipmapLinearFilter||texture.magFilter===LinearMipmapLinearFilter||texture.minFilter===LinearFilter||texture.minFilter===LinearMipmapNearestFilter||texture.minFilter===NearestMipmapLinearFilter||texture.minFilter===LinearMipmapLinearFilter))warn("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.");if(_gl.texParameteri(textureType,_gl.TEXTURE_WRAP_S,wrappingToGL[texture.wrapS]),_gl.texParameteri(textureType,_gl.TEXTURE_WRAP_T,wrappingToGL[texture.wrapT]),textureType===_gl.TEXTURE_3D||textureType===_gl.TEXTURE_2D_ARRAY)_gl.texParameteri(textureType,_gl.TEXTURE_WRAP_R,wrappingToGL[texture.wrapR]);if(_gl.texParameteri(textureType,_gl.TEXTURE_MAG_FILTER,filterToGL[texture.magFilter]),_gl.texParameteri(textureType,_gl.TEXTURE_MIN_FILTER,filterToGL[texture.minFilter]),texture.compareFunction)_gl.texParameteri(textureType,_gl.TEXTURE_COMPARE_MODE,_gl.COMPARE_REF_TO_TEXTURE),_gl.texParameteri(textureType,_gl.TEXTURE_COMPARE_FUNC,compareToGL[texture.compareFunction]);if(extensions.has("EXT_texture_filter_anisotropic")===!0){if(texture.magFilter===NearestFilter)return;if(texture.minFilter!==NearestMipmapLinearFilter&&texture.minFilter!==LinearMipmapLinearFilter)return;if(texture.type===FloatType&&extensions.has("OES_texture_float_linear")===!1)return;if(texture.anisotropy>1||properties.get(texture).__currentAnisotropy){let extension=extensions.get("EXT_texture_filter_anisotropic");_gl.texParameterf(textureType,extension.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(texture.anisotropy,capabilities.getMaxAnisotropy())),properties.get(texture).__currentAnisotropy=texture.anisotropy}}}function initTexture(textureProperties,texture){let forceUpload=!1;if(textureProperties.__webglInit===void 0)textureProperties.__webglInit=!0,texture.addEventListener("dispose",onTextureDispose);let source=texture.source,webglTextures=_sources.get(source);if(webglTextures===void 0)webglTextures={},_sources.set(source,webglTextures);let textureCacheKey=getTextureCacheKey(texture);if(textureCacheKey!==textureProperties.__cacheKey){if(webglTextures[textureCacheKey]===void 0)webglTextures[textureCacheKey]={texture:_gl.createTexture(),usedTimes:0},info.memory.textures++,forceUpload=!0;webglTextures[textureCacheKey].usedTimes++;let webglTexture=webglTextures[textureProperties.__cacheKey];if(webglTexture!==void 0){if(webglTextures[textureProperties.__cacheKey].usedTimes--,webglTexture.usedTimes===0)deleteTexture(texture)}textureProperties.__cacheKey=textureCacheKey,textureProperties.__webglTexture=webglTextures[textureCacheKey].texture}return forceUpload}function getRow(index,rowLength,componentStride){return Math.floor(Math.floor(index/componentStride)/rowLength)}function updateTexture(texture,image,glFormat,glType){let updateRanges=texture.updateRanges;if(updateRanges.length===0)state.texSubImage2D(_gl.TEXTURE_2D,0,0,0,image.width,image.height,glFormat,glType,image.data);else{updateRanges.sort((a,b)=>a.start-b.start);let mergeIndex=0;for(let i=1;i<updateRanges.length;i++){let previousRange=updateRanges[mergeIndex],range=updateRanges[i],previousEnd=previousRange.start+previousRange.count,currentRow=getRow(range.start,image.width,4),previousRow=getRow(previousRange.start,image.width,4);if(range.start<=previousEnd+1&&currentRow===previousRow&&getRow(range.start+range.count-1,image.width,4)===currentRow)previousRange.count=Math.max(previousRange.count,range.start+range.count-previousRange.start);else++mergeIndex,updateRanges[mergeIndex]=range}updateRanges.length=mergeIndex+1;let currentUnpackRowLen=state.getParameter(_gl.UNPACK_ROW_LENGTH),currentUnpackSkipPixels=state.getParameter(_gl.UNPACK_SKIP_PIXELS),currentUnpackSkipRows=state.getParameter(_gl.UNPACK_SKIP_ROWS);state.pixelStorei(_gl.UNPACK_ROW_LENGTH,image.width);for(let i=0,l=updateRanges.length;i<l;i++){let range=updateRanges[i],pixelStart=Math.floor(range.start/4),pixelCount=Math.ceil(range.count/4),x=pixelStart%image.width,y=Math.floor(pixelStart/image.width),width=pixelCount,height=1;state.pixelStorei(_gl.UNPACK_SKIP_PIXELS,x),state.pixelStorei(_gl.UNPACK_SKIP_ROWS,y),state.texSubImage2D(_gl.TEXTURE_2D,0,x,y,width,1,glFormat,glType,image.data)}texture.clearUpdateRanges(),state.pixelStorei(_gl.UNPACK_ROW_LENGTH,currentUnpackRowLen),state.pixelStorei(_gl.UNPACK_SKIP_PIXELS,currentUnpackSkipPixels),state.pixelStorei(_gl.UNPACK_SKIP_ROWS,currentUnpackSkipRows)}}function uploadTexture(textureProperties,texture,slot){let textureType=_gl.TEXTURE_2D;if(texture.isDataArrayTexture||texture.isCompressedArrayTexture)textureType=_gl.TEXTURE_2D_ARRAY;if(texture.isData3DTexture)textureType=_gl.TEXTURE_3D;let forceUpload=initTexture(textureProperties,texture),source=texture.source;state.bindTexture(textureType,textureProperties.__webglTexture,_gl.TEXTURE0+slot);let sourceProperties=properties.get(source);if(source.version!==sourceProperties.__version||forceUpload===!0){if(state.activeTexture(_gl.TEXTURE0+slot),(typeof ImageBitmap<"u"&&texture.image instanceof ImageBitmap)===!1){let workingPrimaries=ColorManagement.getPrimaries(ColorManagement.workingColorSpace),texturePrimaries=texture.colorSpace===NoColorSpace?null:ColorManagement.getPrimaries(texture.colorSpace),unpackConversion=texture.colorSpace===NoColorSpace||workingPrimaries===texturePrimaries?_gl.NONE:_gl.BROWSER_DEFAULT_WEBGL;state.pixelStorei(_gl.UNPACK_FLIP_Y_WEBGL,texture.flipY),state.pixelStorei(_gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,texture.premultiplyAlpha),state.pixelStorei(_gl.UNPACK_COLORSPACE_CONVERSION_WEBGL,unpackConversion)}state.pixelStorei(_gl.UNPACK_ALIGNMENT,texture.unpackAlignment);let image=resizeImage(texture.image,!1,capabilities.maxTextureSize);image=verifyColorSpace(texture,image);let glFormat=utils.convert(texture.format,texture.colorSpace),glType=utils.convert(texture.type),glInternalFormat=getInternalFormat(texture.internalFormat,glFormat,glType,texture.normalized,texture.colorSpace,texture.isVideoTexture);setTextureParameters(textureType,texture);let mipmap,mipmaps=texture.mipmaps,useTexStorage=texture.isVideoTexture!==!0,allocateMemory=sourceProperties.__version===void 0||forceUpload===!0,dataReady=source.dataReady,levels=getMipLevels(texture,image);if(texture.isDepthTexture){if(glInternalFormat=getInternalDepthFormat(texture.format===DepthStencilFormat,texture.type),allocateMemory)if(useTexStorage)state.texStorage2D(_gl.TEXTURE_2D,1,glInternalFormat,image.width,image.height);else state.texImage2D(_gl.TEXTURE_2D,0,glInternalFormat,image.width,image.height,0,glFormat,glType,null)}else if(texture.isDataTexture)if(mipmaps.length>0){if(useTexStorage&&allocateMemory)state.texStorage2D(_gl.TEXTURE_2D,levels,glInternalFormat,mipmaps[0].width,mipmaps[0].height);for(let i=0,il=mipmaps.length;i<il;i++)if(mipmap=mipmaps[i],useTexStorage){if(dataReady)state.texSubImage2D(_gl.TEXTURE_2D,i,0,0,mipmap.width,mipmap.height,glFormat,glType,mipmap.data)}else state.texImage2D(_gl.TEXTURE_2D,i,glInternalFormat,mipmap.width,mipmap.height,0,glFormat,glType,mipmap.data);texture.generateMipmaps=!1}else if(useTexStorage){if(allocateMemory)state.texStorage2D(_gl.TEXTURE_2D,levels,glInternalFormat,image.width,image.height);if(dataReady)updateTexture(texture,image,glFormat,glType)}else state.texImage2D(_gl.TEXTURE_2D,0,glInternalFormat,image.width,image.height,0,glFormat,glType,image.data);else if(texture.isCompressedTexture)if(texture.isCompressedArrayTexture){if(useTexStorage&&allocateMemory)state.texStorage3D(_gl.TEXTURE_2D_ARRAY,levels,glInternalFormat,mipmaps[0].width,mipmaps[0].height,image.depth);for(let i=0,il=mipmaps.length;i<il;i++)if(mipmap=mipmaps[i],texture.format!==RGBAFormat)if(glFormat!==null)if(useTexStorage){if(dataReady)if(texture.layerUpdates.size>0){let layerByteLength=getByteLength(mipmap.width,mipmap.height,texture.format,texture.type);for(let layerIndex of texture.layerUpdates){let layerData=mipmap.data.subarray(layerIndex*layerByteLength/mipmap.data.BYTES_PER_ELEMENT,(layerIndex+1)*layerByteLength/mipmap.data.BYTES_PER_ELEMENT);state.compressedTexSubImage3D(_gl.TEXTURE_2D_ARRAY,i,0,0,layerIndex,mipmap.width,mipmap.height,1,glFormat,layerData)}texture.clearLayerUpdates()}else state.compressedTexSubImage3D(_gl.TEXTURE_2D_ARRAY,i,0,0,0,mipmap.width,mipmap.height,image.depth,glFormat,mipmap.data)}else state.compressedTexImage3D(_gl.TEXTURE_2D_ARRAY,i,glInternalFormat,mipmap.width,mipmap.height,image.depth,0,mipmap.data,0,0);else warn("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else if(useTexStorage){if(dataReady)state.texSubImage3D(_gl.TEXTURE_2D_ARRAY,i,0,0,0,mipmap.width,mipmap.height,image.depth,glFormat,glType,mipmap.data)}else state.texImage3D(_gl.TEXTURE_2D_ARRAY,i,glInternalFormat,mipmap.width,mipmap.height,image.depth,0,glFormat,glType,mipmap.data)}else{if(useTexStorage&&allocateMemory)state.texStorage2D(_gl.TEXTURE_2D,levels,glInternalFormat,mipmaps[0].width,mipmaps[0].height);for(let i=0,il=mipmaps.length;i<il;i++)if(mipmap=mipmaps[i],texture.format!==RGBAFormat)if(glFormat!==null)if(useTexStorage){if(dataReady)state.compressedTexSubImage2D(_gl.TEXTURE_2D,i,0,0,mipmap.width,mipmap.height,glFormat,mipmap.data)}else state.compressedTexImage2D(_gl.TEXTURE_2D,i,glInternalFormat,mipmap.width,mipmap.height,0,mipmap.data);else warn("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else if(useTexStorage){if(dataReady)state.texSubImage2D(_gl.TEXTURE_2D,i,0,0,mipmap.width,mipmap.height,glFormat,glType,mipmap.data)}else state.texImage2D(_gl.TEXTURE_2D,i,glInternalFormat,mipmap.width,mipmap.height,0,glFormat,glType,mipmap.data)}else if(texture.isDataArrayTexture)if(useTexStorage){if(allocateMemory)state.texStorage3D(_gl.TEXTURE_2D_ARRAY,levels,glInternalFormat,image.width,image.height,image.depth);if(dataReady)if(texture.layerUpdates.size>0){let layerByteLength=getByteLength(image.width,image.height,texture.format,texture.type);for(let layerIndex of texture.layerUpdates){let layerData=image.data.subarray(layerIndex*layerByteLength/image.data.BYTES_PER_ELEMENT,(layerIndex+1)*layerByteLength/image.data.BYTES_PER_ELEMENT);state.texSubImage3D(_gl.TEXTURE_2D_ARRAY,0,0,0,layerIndex,image.width,image.height,1,glFormat,glType,layerData)}texture.clearLayerUpdates()}else state.texSubImage3D(_gl.TEXTURE_2D_ARRAY,0,0,0,0,image.width,image.height,image.depth,glFormat,glType,image.data)}else state.texImage3D(_gl.TEXTURE_2D_ARRAY,0,glInternalFormat,image.width,image.height,image.depth,0,glFormat,glType,image.data);else if(texture.isData3DTexture)if(useTexStorage){if(allocateMemory)state.texStorage3D(_gl.TEXTURE_3D,levels,glInternalFormat,image.width,image.height,image.depth);if(dataReady)state.texSubImage3D(_gl.TEXTURE_3D,0,0,0,0,image.width,image.height,image.depth,glFormat,glType,image.data)}else state.texImage3D(_gl.TEXTURE_3D,0,glInternalFormat,image.width,image.height,image.depth,0,glFormat,glType,image.data);else if(texture.isFramebufferTexture){if(allocateMemory)if(useTexStorage)state.texStorage2D(_gl.TEXTURE_2D,levels,glInternalFormat,image.width,image.height);else{let{width,height}=image;for(let i=0;i<levels;i++)state.texImage2D(_gl.TEXTURE_2D,i,glInternalFormat,width,height,0,glFormat,glType,null),width>>=1,height>>=1}}else if(texture.isHTMLTexture){if("texElementImage2D"in _gl){let canvas=_gl.canvas;if(!canvas.hasAttribute("layoutsubtree"))canvas.setAttribute("layoutsubtree","true");if(image.parentNode!==canvas){canvas.appendChild(image),_htmlTextures.add(texture),canvas.onpaint=(event)=>{let changed=event.changedElements;for(let t of _htmlTextures)if(changed.includes(t.image))t.needsUpdate=!0},canvas.requestPaint();return}let level=0,internalFormat=_gl.RGBA,srcFormat=_gl.RGBA,srcType=_gl.UNSIGNED_BYTE;_gl.texElementImage2D(_gl.TEXTURE_2D,level,internalFormat,srcFormat,srcType,image),_gl.texParameteri(_gl.TEXTURE_2D,_gl.TEXTURE_MIN_FILTER,_gl.LINEAR),_gl.texParameteri(_gl.TEXTURE_2D,_gl.TEXTURE_WRAP_S,_gl.CLAMP_TO_EDGE),_gl.texParameteri(_gl.TEXTURE_2D,_gl.TEXTURE_WRAP_T,_gl.CLAMP_TO_EDGE)}}else if(mipmaps.length>0){if(useTexStorage&&allocateMemory){let dimensions=getDimensions(mipmaps[0]);state.texStorage2D(_gl.TEXTURE_2D,levels,glInternalFormat,dimensions.width,dimensions.height)}for(let i=0,il=mipmaps.length;i<il;i++)if(mipmap=mipmaps[i],useTexStorage){if(dataReady)state.texSubImage2D(_gl.TEXTURE_2D,i,0,0,glFormat,glType,mipmap)}else state.texImage2D(_gl.TEXTURE_2D,i,glInternalFormat,glFormat,glType,mipmap);texture.generateMipmaps=!1}else if(useTexStorage){if(allocateMemory){let dimensions=getDimensions(image);state.texStorage2D(_gl.TEXTURE_2D,levels,glInternalFormat,dimensions.width,dimensions.height)}if(dataReady)state.texSubImage2D(_gl.TEXTURE_2D,0,0,0,glFormat,glType,image)}else state.texImage2D(_gl.TEXTURE_2D,0,glInternalFormat,glFormat,glType,image);if(textureNeedsGenerateMipmaps(texture))generateMipmap(textureType);if(sourceProperties.__version=source.version,texture.onUpdate)texture.onUpdate(texture)}textureProperties.__version=texture.version}function uploadCubeTexture(textureProperties,texture,slot){if(texture.image.length!==6)return;let forceUpload=initTexture(textureProperties,texture),source=texture.source;state.bindTexture(_gl.TEXTURE_CUBE_MAP,textureProperties.__webglTexture,_gl.TEXTURE0+slot);let sourceProperties=properties.get(source);if(source.version!==sourceProperties.__version||forceUpload===!0){state.activeTexture(_gl.TEXTURE0+slot);let workingPrimaries=ColorManagement.getPrimaries(ColorManagement.workingColorSpace),texturePrimaries=texture.colorSpace===NoColorSpace?null:ColorManagement.getPrimaries(texture.colorSpace),unpackConversion=texture.colorSpace===NoColorSpace||workingPrimaries===texturePrimaries?_gl.NONE:_gl.BROWSER_DEFAULT_WEBGL;state.pixelStorei(_gl.UNPACK_FLIP_Y_WEBGL,texture.flipY),state.pixelStorei(_gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,texture.premultiplyAlpha),state.pixelStorei(_gl.UNPACK_ALIGNMENT,texture.unpackAlignment),state.pixelStorei(_gl.UNPACK_COLORSPACE_CONVERSION_WEBGL,unpackConversion);let isCompressed=texture.isCompressedTexture||texture.image[0].isCompressedTexture,isDataTexture=texture.image[0]&&texture.image[0].isDataTexture,cubeImage=[];for(let i=0;i<6;i++){if(!isCompressed&&!isDataTexture)cubeImage[i]=resizeImage(texture.image[i],!0,capabilities.maxCubemapSize);else cubeImage[i]=isDataTexture?texture.image[i].image:texture.image[i];cubeImage[i]=verifyColorSpace(texture,cubeImage[i])}let image=cubeImage[0],glFormat=utils.convert(texture.format,texture.colorSpace),glType=utils.convert(texture.type),glInternalFormat=getInternalFormat(texture.internalFormat,glFormat,glType,texture.normalized,texture.colorSpace),useTexStorage=texture.isVideoTexture!==!0,allocateMemory=sourceProperties.__version===void 0||forceUpload===!0,dataReady=source.dataReady,levels=getMipLevels(texture,image);setTextureParameters(_gl.TEXTURE_CUBE_MAP,texture);let mipmaps;if(isCompressed){if(useTexStorage&&allocateMemory)state.texStorage2D(_gl.TEXTURE_CUBE_MAP,levels,glInternalFormat,image.width,image.height);for(let i=0;i<6;i++){mipmaps=cubeImage[i].mipmaps;for(let j=0;j<mipmaps.length;j++){let mipmap=mipmaps[j];if(texture.format!==RGBAFormat)if(glFormat!==null)if(useTexStorage){if(dataReady)state.compressedTexSubImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,j,0,0,mipmap.width,mipmap.height,glFormat,mipmap.data)}else state.compressedTexImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,j,glInternalFormat,mipmap.width,mipmap.height,0,mipmap.data);else warn("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()");else if(useTexStorage){if(dataReady)state.texSubImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,j,0,0,mipmap.width,mipmap.height,glFormat,glType,mipmap.data)}else state.texImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,j,glInternalFormat,mipmap.width,mipmap.height,0,glFormat,glType,mipmap.data)}}}else{if(mipmaps=texture.mipmaps,useTexStorage&&allocateMemory){if(mipmaps.length>0)levels++;let dimensions=getDimensions(cubeImage[0]);state.texStorage2D(_gl.TEXTURE_CUBE_MAP,levels,glInternalFormat,dimensions.width,dimensions.height)}for(let i=0;i<6;i++)if(isDataTexture){if(useTexStorage){if(dataReady)state.texSubImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,0,0,0,cubeImage[i].width,cubeImage[i].height,glFormat,glType,cubeImage[i].data)}else state.texImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,0,glInternalFormat,cubeImage[i].width,cubeImage[i].height,0,glFormat,glType,cubeImage[i].data);for(let j=0;j<mipmaps.length;j++){let mipmapImage=mipmaps[j].image[i].image;if(useTexStorage){if(dataReady)state.texSubImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,j+1,0,0,mipmapImage.width,mipmapImage.height,glFormat,glType,mipmapImage.data)}else state.texImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,j+1,glInternalFormat,mipmapImage.width,mipmapImage.height,0,glFormat,glType,mipmapImage.data)}}else{if(useTexStorage){if(dataReady)state.texSubImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,0,0,0,glFormat,glType,cubeImage[i])}else state.texImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,0,glInternalFormat,glFormat,glType,cubeImage[i]);for(let j=0;j<mipmaps.length;j++){let mipmap=mipmaps[j];if(useTexStorage){if(dataReady)state.texSubImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,j+1,0,0,glFormat,glType,mipmap.image[i])}else state.texImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,j+1,glInternalFormat,glFormat,glType,mipmap.image[i])}}}if(textureNeedsGenerateMipmaps(texture))generateMipmap(_gl.TEXTURE_CUBE_MAP);if(sourceProperties.__version=source.version,texture.onUpdate)texture.onUpdate(texture)}textureProperties.__version=texture.version}function setupFrameBufferTexture(framebuffer,renderTarget,texture,attachment,textureTarget,level){let glFormat=utils.convert(texture.format,texture.colorSpace),glType=utils.convert(texture.type),glInternalFormat=getInternalFormat(texture.internalFormat,glFormat,glType,texture.normalized,texture.colorSpace),renderTargetProperties=properties.get(renderTarget),textureProperties=properties.get(texture);if(textureProperties.__renderTarget=renderTarget,!renderTargetProperties.__hasExternalTextures){let width=Math.max(1,renderTarget.width>>level),height=Math.max(1,renderTarget.height>>level);if(textureTarget===_gl.TEXTURE_3D||textureTarget===_gl.TEXTURE_2D_ARRAY)state.texImage3D(textureTarget,level,glInternalFormat,width,height,renderTarget.depth,0,glFormat,glType,null);else state.texImage2D(textureTarget,level,glInternalFormat,width,height,0,glFormat,glType,null)}if(state.bindFramebuffer(_gl.FRAMEBUFFER,framebuffer),useMultisampledRTT(renderTarget))multisampledRTTExt.framebufferTexture2DMultisampleEXT(_gl.FRAMEBUFFER,attachment,textureTarget,textureProperties.__webglTexture,0,getRenderTargetSamples(renderTarget));else if(textureTarget===_gl.TEXTURE_2D||textureTarget>=_gl.TEXTURE_CUBE_MAP_POSITIVE_X&&textureTarget<=_gl.TEXTURE_CUBE_MAP_NEGATIVE_Z)_gl.framebufferTexture2D(_gl.FRAMEBUFFER,attachment,textureTarget,textureProperties.__webglTexture,level);state.bindFramebuffer(_gl.FRAMEBUFFER,null)}function setupRenderBufferStorage(renderbuffer,renderTarget,useMultisample){if(_gl.bindRenderbuffer(_gl.RENDERBUFFER,renderbuffer),renderTarget.depthBuffer){let depthTexture=renderTarget.depthTexture,depthType=depthTexture&&depthTexture.isDepthTexture?depthTexture.type:null,glInternalFormat=getInternalDepthFormat(renderTarget.stencilBuffer,depthType),glAttachmentType=renderTarget.stencilBuffer?_gl.DEPTH_STENCIL_ATTACHMENT:_gl.DEPTH_ATTACHMENT;if(useMultisampledRTT(renderTarget))multisampledRTTExt.renderbufferStorageMultisampleEXT(_gl.RENDERBUFFER,getRenderTargetSamples(renderTarget),glInternalFormat,renderTarget.width,renderTarget.height);else if(useMultisample)_gl.renderbufferStorageMultisample(_gl.RENDERBUFFER,getRenderTargetSamples(renderTarget),glInternalFormat,renderTarget.width,renderTarget.height);else _gl.renderbufferStorage(_gl.RENDERBUFFER,glInternalFormat,renderTarget.width,renderTarget.height);_gl.framebufferRenderbuffer(_gl.FRAMEBUFFER,glAttachmentType,_gl.RENDERBUFFER,renderbuffer)}else{let textures=renderTarget.textures;for(let i=0;i<textures.length;i++){let texture=textures[i],glFormat=utils.convert(texture.format,texture.colorSpace),glType=utils.convert(texture.type),glInternalFormat=getInternalFormat(texture.internalFormat,glFormat,glType,texture.normalized,texture.colorSpace);if(useMultisampledRTT(renderTarget))multisampledRTTExt.renderbufferStorageMultisampleEXT(_gl.RENDERBUFFER,getRenderTargetSamples(renderTarget),glInternalFormat,renderTarget.width,renderTarget.height);else if(useMultisample)_gl.renderbufferStorageMultisample(_gl.RENDERBUFFER,getRenderTargetSamples(renderTarget),glInternalFormat,renderTarget.width,renderTarget.height);else _gl.renderbufferStorage(_gl.RENDERBUFFER,glInternalFormat,renderTarget.width,renderTarget.height)}}_gl.bindRenderbuffer(_gl.RENDERBUFFER,null)}function setupDepthTexture(framebuffer,renderTarget,cubeFace){let isCube=renderTarget.isWebGLCubeRenderTarget===!0;if(state.bindFramebuffer(_gl.FRAMEBUFFER,framebuffer),!(renderTarget.depthTexture&&renderTarget.depthTexture.isDepthTexture))throw Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let textureProperties=properties.get(renderTarget.depthTexture);if(textureProperties.__renderTarget=renderTarget,!textureProperties.__webglTexture||renderTarget.depthTexture.image.width!==renderTarget.width||renderTarget.depthTexture.image.height!==renderTarget.height)renderTarget.depthTexture.image.width=renderTarget.width,renderTarget.depthTexture.image.height=renderTarget.height,renderTarget.depthTexture.needsUpdate=!0;if(isCube){if(textureProperties.__webglInit===void 0)textureProperties.__webglInit=!0,renderTarget.depthTexture.addEventListener("dispose",onTextureDispose);if(textureProperties.__webglTexture===void 0){textureProperties.__webglTexture=_gl.createTexture(),state.bindTexture(_gl.TEXTURE_CUBE_MAP,textureProperties.__webglTexture),setTextureParameters(_gl.TEXTURE_CUBE_MAP,renderTarget.depthTexture);let glFormat=utils.convert(renderTarget.depthTexture.format),glType=utils.convert(renderTarget.depthTexture.type),glInternalFormat;if(renderTarget.depthTexture.format===DepthFormat)glInternalFormat=_gl.DEPTH_COMPONENT24;else if(renderTarget.depthTexture.format===DepthStencilFormat)glInternalFormat=_gl.DEPTH24_STENCIL8;for(let i=0;i<6;i++)_gl.texImage2D(_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,0,glInternalFormat,renderTarget.width,renderTarget.height,0,glFormat,glType,null)}}else setTexture2D(renderTarget.depthTexture,0);let webglDepthTexture=textureProperties.__webglTexture,samples=getRenderTargetSamples(renderTarget),glTextureType=isCube?_gl.TEXTURE_CUBE_MAP_POSITIVE_X+cubeFace:_gl.TEXTURE_2D,glAttachmentType=renderTarget.depthTexture.format===DepthStencilFormat?_gl.DEPTH_STENCIL_ATTACHMENT:_gl.DEPTH_ATTACHMENT;if(renderTarget.depthTexture.format===DepthFormat)if(useMultisampledRTT(renderTarget))multisampledRTTExt.framebufferTexture2DMultisampleEXT(_gl.FRAMEBUFFER,glAttachmentType,glTextureType,webglDepthTexture,0,samples);else _gl.framebufferTexture2D(_gl.FRAMEBUFFER,glAttachmentType,glTextureType,webglDepthTexture,0);else if(renderTarget.depthTexture.format===DepthStencilFormat)if(useMultisampledRTT(renderTarget))multisampledRTTExt.framebufferTexture2DMultisampleEXT(_gl.FRAMEBUFFER,glAttachmentType,glTextureType,webglDepthTexture,0,samples);else _gl.framebufferTexture2D(_gl.FRAMEBUFFER,glAttachmentType,glTextureType,webglDepthTexture,0);else throw Error("Unknown depthTexture format")}function setupDepthRenderbuffer(renderTarget){let renderTargetProperties=properties.get(renderTarget),isCube=renderTarget.isWebGLCubeRenderTarget===!0;if(renderTargetProperties.__boundDepthTexture!==renderTarget.depthTexture){let depthTexture=renderTarget.depthTexture;if(renderTargetProperties.__depthDisposeCallback)renderTargetProperties.__depthDisposeCallback();if(depthTexture){let disposeEvent=()=>{delete renderTargetProperties.__boundDepthTexture,delete renderTargetProperties.__depthDisposeCallback,depthTexture.removeEventListener("dispose",disposeEvent)};depthTexture.addEventListener("dispose",disposeEvent),renderTargetProperties.__depthDisposeCallback=disposeEvent}renderTargetProperties.__boundDepthTexture=depthTexture}if(renderTarget.depthTexture&&!renderTargetProperties.__autoAllocateDepthBuffer)if(isCube)for(let i=0;i<6;i++)setupDepthTexture(renderTargetProperties.__webglFramebuffer[i],renderTarget,i);else{let mipmaps=renderTarget.texture.mipmaps;if(mipmaps&&mipmaps.length>0)setupDepthTexture(renderTargetProperties.__webglFramebuffer[0],renderTarget,0);else setupDepthTexture(renderTargetProperties.__webglFramebuffer,renderTarget,0)}else if(isCube){renderTargetProperties.__webglDepthbuffer=[];for(let i=0;i<6;i++)if(state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglFramebuffer[i]),renderTargetProperties.__webglDepthbuffer[i]===void 0)renderTargetProperties.__webglDepthbuffer[i]=_gl.createRenderbuffer(),setupRenderBufferStorage(renderTargetProperties.__webglDepthbuffer[i],renderTarget,!1);else{let glAttachmentType=renderTarget.stencilBuffer?_gl.DEPTH_STENCIL_ATTACHMENT:_gl.DEPTH_ATTACHMENT,renderbuffer=renderTargetProperties.__webglDepthbuffer[i];_gl.bindRenderbuffer(_gl.RENDERBUFFER,renderbuffer),_gl.framebufferRenderbuffer(_gl.FRAMEBUFFER,glAttachmentType,_gl.RENDERBUFFER,renderbuffer)}}else{let mipmaps=renderTarget.texture.mipmaps;if(mipmaps&&mipmaps.length>0)state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglFramebuffer[0]);else state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglFramebuffer);if(renderTargetProperties.__webglDepthbuffer===void 0)renderTargetProperties.__webglDepthbuffer=_gl.createRenderbuffer(),setupRenderBufferStorage(renderTargetProperties.__webglDepthbuffer,renderTarget,!1);else{let glAttachmentType=renderTarget.stencilBuffer?_gl.DEPTH_STENCIL_ATTACHMENT:_gl.DEPTH_ATTACHMENT,renderbuffer=renderTargetProperties.__webglDepthbuffer;_gl.bindRenderbuffer(_gl.RENDERBUFFER,renderbuffer),_gl.framebufferRenderbuffer(_gl.FRAMEBUFFER,glAttachmentType,_gl.RENDERBUFFER,renderbuffer)}}state.bindFramebuffer(_gl.FRAMEBUFFER,null)}function rebindTextures(renderTarget,colorTexture,depthTexture){let renderTargetProperties=properties.get(renderTarget);if(colorTexture!==void 0)setupFrameBufferTexture(renderTargetProperties.__webglFramebuffer,renderTarget,renderTarget.texture,_gl.COLOR_ATTACHMENT0,_gl.TEXTURE_2D,0);if(depthTexture!==void 0)setupDepthRenderbuffer(renderTarget)}function setupRenderTarget(renderTarget){let texture=renderTarget.texture,renderTargetProperties=properties.get(renderTarget),textureProperties=properties.get(texture);renderTarget.addEventListener("dispose",onRenderTargetDispose);let textures=renderTarget.textures,isCube=renderTarget.isWebGLCubeRenderTarget===!0,isMultipleRenderTargets=textures.length>1;if(!isMultipleRenderTargets){if(textureProperties.__webglTexture===void 0)textureProperties.__webglTexture=_gl.createTexture();textureProperties.__version=texture.version,info.memory.textures++}if(isCube){renderTargetProperties.__webglFramebuffer=[];for(let i=0;i<6;i++)if(texture.mipmaps&&texture.mipmaps.length>0){renderTargetProperties.__webglFramebuffer[i]=[];for(let level=0;level<texture.mipmaps.length;level++)renderTargetProperties.__webglFramebuffer[i][level]=_gl.createFramebuffer()}else renderTargetProperties.__webglFramebuffer[i]=_gl.createFramebuffer()}else{if(texture.mipmaps&&texture.mipmaps.length>0){renderTargetProperties.__webglFramebuffer=[];for(let level=0;level<texture.mipmaps.length;level++)renderTargetProperties.__webglFramebuffer[level]=_gl.createFramebuffer()}else renderTargetProperties.__webglFramebuffer=_gl.createFramebuffer();if(isMultipleRenderTargets)for(let i=0,il=textures.length;i<il;i++){let attachmentProperties=properties.get(textures[i]);if(attachmentProperties.__webglTexture===void 0)attachmentProperties.__webglTexture=_gl.createTexture(),info.memory.textures++}if(renderTarget.samples>0&&useMultisampledRTT(renderTarget)===!1){renderTargetProperties.__webglMultisampledFramebuffer=_gl.createFramebuffer(),renderTargetProperties.__webglColorRenderbuffer=[],state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglMultisampledFramebuffer);for(let i=0;i<textures.length;i++){let texture2=textures[i];renderTargetProperties.__webglColorRenderbuffer[i]=_gl.createRenderbuffer(),_gl.bindRenderbuffer(_gl.RENDERBUFFER,renderTargetProperties.__webglColorRenderbuffer[i]);let glFormat=utils.convert(texture2.format,texture2.colorSpace),glType=utils.convert(texture2.type),glInternalFormat=getInternalFormat(texture2.internalFormat,glFormat,glType,texture2.normalized,texture2.colorSpace,renderTarget.isXRRenderTarget===!0),samples=getRenderTargetSamples(renderTarget);_gl.renderbufferStorageMultisample(_gl.RENDERBUFFER,samples,glInternalFormat,renderTarget.width,renderTarget.height),_gl.framebufferRenderbuffer(_gl.FRAMEBUFFER,_gl.COLOR_ATTACHMENT0+i,_gl.RENDERBUFFER,renderTargetProperties.__webglColorRenderbuffer[i])}if(_gl.bindRenderbuffer(_gl.RENDERBUFFER,null),renderTarget.depthBuffer)renderTargetProperties.__webglDepthRenderbuffer=_gl.createRenderbuffer(),setupRenderBufferStorage(renderTargetProperties.__webglDepthRenderbuffer,renderTarget,!0);state.bindFramebuffer(_gl.FRAMEBUFFER,null)}}if(isCube){state.bindTexture(_gl.TEXTURE_CUBE_MAP,textureProperties.__webglTexture),setTextureParameters(_gl.TEXTURE_CUBE_MAP,texture);for(let i=0;i<6;i++)if(texture.mipmaps&&texture.mipmaps.length>0)for(let level=0;level<texture.mipmaps.length;level++)setupFrameBufferTexture(renderTargetProperties.__webglFramebuffer[i][level],renderTarget,texture,_gl.COLOR_ATTACHMENT0,_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,level);else setupFrameBufferTexture(renderTargetProperties.__webglFramebuffer[i],renderTarget,texture,_gl.COLOR_ATTACHMENT0,_gl.TEXTURE_CUBE_MAP_POSITIVE_X+i,0);if(textureNeedsGenerateMipmaps(texture))generateMipmap(_gl.TEXTURE_CUBE_MAP);state.unbindTexture()}else if(isMultipleRenderTargets){for(let i=0,il=textures.length;i<il;i++){let attachment=textures[i],attachmentProperties=properties.get(attachment),glTextureType=_gl.TEXTURE_2D;if(renderTarget.isWebGL3DRenderTarget||renderTarget.isWebGLArrayRenderTarget)glTextureType=renderTarget.isWebGL3DRenderTarget?_gl.TEXTURE_3D:_gl.TEXTURE_2D_ARRAY;if(state.bindTexture(glTextureType,attachmentProperties.__webglTexture),setTextureParameters(glTextureType,attachment),setupFrameBufferTexture(renderTargetProperties.__webglFramebuffer,renderTarget,attachment,_gl.COLOR_ATTACHMENT0+i,glTextureType,0),textureNeedsGenerateMipmaps(attachment))generateMipmap(glTextureType)}state.unbindTexture()}else{let glTextureType=_gl.TEXTURE_2D;if(renderTarget.isWebGL3DRenderTarget||renderTarget.isWebGLArrayRenderTarget)glTextureType=renderTarget.isWebGL3DRenderTarget?_gl.TEXTURE_3D:_gl.TEXTURE_2D_ARRAY;if(state.bindTexture(glTextureType,textureProperties.__webglTexture),setTextureParameters(glTextureType,texture),texture.mipmaps&&texture.mipmaps.length>0)for(let level=0;level<texture.mipmaps.length;level++)setupFrameBufferTexture(renderTargetProperties.__webglFramebuffer[level],renderTarget,texture,_gl.COLOR_ATTACHMENT0,glTextureType,level);else setupFrameBufferTexture(renderTargetProperties.__webglFramebuffer,renderTarget,texture,_gl.COLOR_ATTACHMENT0,glTextureType,0);if(textureNeedsGenerateMipmaps(texture))generateMipmap(glTextureType);state.unbindTexture()}if(renderTarget.depthBuffer)setupDepthRenderbuffer(renderTarget)}function updateRenderTargetMipmap(renderTarget){let textures=renderTarget.textures;for(let i=0,il=textures.length;i<il;i++){let texture=textures[i];if(textureNeedsGenerateMipmaps(texture)){let targetType=getTargetType(renderTarget),webglTexture=properties.get(texture).__webglTexture;state.bindTexture(targetType,webglTexture),generateMipmap(targetType),state.unbindTexture()}}}let invalidationArrayRead=[],invalidationArrayDraw=[];function updateMultisampleRenderTarget(renderTarget){if(renderTarget.samples>0){if(useMultisampledRTT(renderTarget)===!1){let{textures,width,height}=renderTarget,mask=_gl.COLOR_BUFFER_BIT,depthStyle=renderTarget.stencilBuffer?_gl.DEPTH_STENCIL_ATTACHMENT:_gl.DEPTH_ATTACHMENT,renderTargetProperties=properties.get(renderTarget),isMultipleRenderTargets=textures.length>1;if(isMultipleRenderTargets)for(let i=0;i<textures.length;i++)state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglMultisampledFramebuffer),_gl.framebufferRenderbuffer(_gl.FRAMEBUFFER,_gl.COLOR_ATTACHMENT0+i,_gl.RENDERBUFFER,null),state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglFramebuffer),_gl.framebufferTexture2D(_gl.DRAW_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0+i,_gl.TEXTURE_2D,null,0);state.bindFramebuffer(_gl.READ_FRAMEBUFFER,renderTargetProperties.__webglMultisampledFramebuffer);let mipmaps=renderTarget.texture.mipmaps;if(mipmaps&&mipmaps.length>0)state.bindFramebuffer(_gl.DRAW_FRAMEBUFFER,renderTargetProperties.__webglFramebuffer[0]);else state.bindFramebuffer(_gl.DRAW_FRAMEBUFFER,renderTargetProperties.__webglFramebuffer);for(let i=0;i<textures.length;i++){if(renderTarget.resolveDepthBuffer){if(renderTarget.depthBuffer)mask|=_gl.DEPTH_BUFFER_BIT;if(renderTarget.stencilBuffer&&renderTarget.resolveStencilBuffer)mask|=_gl.STENCIL_BUFFER_BIT}if(isMultipleRenderTargets){_gl.framebufferRenderbuffer(_gl.READ_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,_gl.RENDERBUFFER,renderTargetProperties.__webglColorRenderbuffer[i]);let webglTexture=properties.get(textures[i]).__webglTexture;_gl.framebufferTexture2D(_gl.DRAW_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,_gl.TEXTURE_2D,webglTexture,0)}if(_gl.blitFramebuffer(0,0,width,height,0,0,width,height,mask,_gl.NEAREST),supportsInvalidateFramebuffer===!0){if(invalidationArrayRead.length=0,invalidationArrayDraw.length=0,invalidationArrayRead.push(_gl.COLOR_ATTACHMENT0+i),renderTarget.depthBuffer&&renderTarget.resolveDepthBuffer===!1)invalidationArrayRead.push(depthStyle),invalidationArrayDraw.push(depthStyle),_gl.invalidateFramebuffer(_gl.DRAW_FRAMEBUFFER,invalidationArrayDraw);_gl.invalidateFramebuffer(_gl.READ_FRAMEBUFFER,invalidationArrayRead)}}if(state.bindFramebuffer(_gl.READ_FRAMEBUFFER,null),state.bindFramebuffer(_gl.DRAW_FRAMEBUFFER,null),isMultipleRenderTargets)for(let i=0;i<textures.length;i++){state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglMultisampledFramebuffer),_gl.framebufferRenderbuffer(_gl.FRAMEBUFFER,_gl.COLOR_ATTACHMENT0+i,_gl.RENDERBUFFER,renderTargetProperties.__webglColorRenderbuffer[i]);let webglTexture=properties.get(textures[i]).__webglTexture;state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglFramebuffer),_gl.framebufferTexture2D(_gl.DRAW_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0+i,_gl.TEXTURE_2D,webglTexture,0)}state.bindFramebuffer(_gl.DRAW_FRAMEBUFFER,renderTargetProperties.__webglMultisampledFramebuffer)}else if(renderTarget.depthBuffer&&renderTarget.resolveDepthBuffer===!1&&supportsInvalidateFramebuffer){let depthStyle=renderTarget.stencilBuffer?_gl.DEPTH_STENCIL_ATTACHMENT:_gl.DEPTH_ATTACHMENT;_gl.invalidateFramebuffer(_gl.DRAW_FRAMEBUFFER,[depthStyle])}}}function getRenderTargetSamples(renderTarget){return Math.min(capabilities.maxSamples,renderTarget.samples)}function useMultisampledRTT(renderTarget){let renderTargetProperties=properties.get(renderTarget);return renderTarget.samples>0&&extensions.has("WEBGL_multisampled_render_to_texture")===!0&&renderTargetProperties.__useRenderToTexture!==!1}function updateVideoTexture(texture){let frame=info.render.frame;if(_videoTextures.get(texture)!==frame)_videoTextures.set(texture,frame),texture.update()}function verifyColorSpace(texture,image){let{colorSpace,format,type}=texture;if(texture.isCompressedTexture===!0||texture.isVideoTexture===!0)return image;if(colorSpace!==LinearSRGBColorSpace&&colorSpace!==NoColorSpace)if(ColorManagement.getTransfer(colorSpace)===SRGBTransfer){if(format!==RGBAFormat||type!==UnsignedByteType)warn("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.")}else error("WebGLTextures: Unsupported texture color space:",colorSpace);return image}function getDimensions(image){if(typeof HTMLImageElement<"u"&&image instanceof HTMLImageElement)_imageDimensions.width=image.naturalWidth||image.width,_imageDimensions.height=image.naturalHeight||image.height;else if(typeof VideoFrame<"u"&&image instanceof VideoFrame)_imageDimensions.width=image.displayWidth,_imageDimensions.height=image.displayHeight;else _imageDimensions.width=image.width,_imageDimensions.height=image.height;return _imageDimensions}this.allocateTextureUnit=allocateTextureUnit,this.resetTextureUnits=resetTextureUnits,this.getTextureUnits=getTextureUnits,this.setTextureUnits=setTextureUnits,this.setTexture2D=setTexture2D,this.setTexture2DArray=setTexture2DArray,this.setTexture3D=setTexture3D,this.setTextureCube=setTextureCube,this.rebindTextures=rebindTextures,this.setupRenderTarget=setupRenderTarget,this.updateRenderTargetMipmap=updateRenderTargetMipmap,this.updateMultisampleRenderTarget=updateMultisampleRenderTarget,this.setupDepthRenderbuffer=setupDepthRenderbuffer,this.setupFrameBufferTexture=setupFrameBufferTexture,this.useMultisampledRTT=useMultisampledRTT,this.isReversedDepthBuffer=function(){return state.buffers.depth.getReversed()}}function WebGLUtils(gl,extensions){function convert(p,colorSpace=NoColorSpace){let extension,transfer=ColorManagement.getTransfer(colorSpace);if(p===UnsignedByteType)return gl.UNSIGNED_BYTE;if(p===UnsignedShort4444Type)return gl.UNSIGNED_SHORT_4_4_4_4;if(p===UnsignedShort5551Type)return gl.UNSIGNED_SHORT_5_5_5_1;if(p===UnsignedInt5999Type)return gl.UNSIGNED_INT_5_9_9_9_REV;if(p===UnsignedInt101111Type)return gl.UNSIGNED_INT_10F_11F_11F_REV;if(p===ByteType)return gl.BYTE;if(p===ShortType)return gl.SHORT;if(p===UnsignedShortType)return gl.UNSIGNED_SHORT;if(p===IntType)return gl.INT;if(p===UnsignedIntType)return gl.UNSIGNED_INT;if(p===FloatType)return gl.FLOAT;if(p===HalfFloatType)return gl.HALF_FLOAT;if(p===AlphaFormat)return gl.ALPHA;if(p===RGBFormat)return gl.RGB;if(p===RGBAFormat)return gl.RGBA;if(p===DepthFormat)return gl.DEPTH_COMPONENT;if(p===DepthStencilFormat)return gl.DEPTH_STENCIL;if(p===RedFormat)return gl.RED;if(p===RedIntegerFormat)return gl.RED_INTEGER;if(p===RGFormat)return gl.RG;if(p===RGIntegerFormat)return gl.RG_INTEGER;if(p===RGBAIntegerFormat)return gl.RGBA_INTEGER;if(p===RGB_S3TC_DXT1_Format||p===RGBA_S3TC_DXT1_Format||p===RGBA_S3TC_DXT3_Format||p===RGBA_S3TC_DXT5_Format)if(transfer===SRGBTransfer)if(extension=extensions.get("WEBGL_compressed_texture_s3tc_srgb"),extension!==null){if(p===RGB_S3TC_DXT1_Format)return extension.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(p===RGBA_S3TC_DXT1_Format)return extension.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(p===RGBA_S3TC_DXT3_Format)return extension.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(p===RGBA_S3TC_DXT5_Format)return extension.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(extension=extensions.get("WEBGL_compressed_texture_s3tc"),extension!==null){if(p===RGB_S3TC_DXT1_Format)return extension.COMPRESSED_RGB_S3TC_DXT1_EXT;if(p===RGBA_S3TC_DXT1_Format)return extension.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(p===RGBA_S3TC_DXT3_Format)return extension.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(p===RGBA_S3TC_DXT5_Format)return extension.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(p===RGB_PVRTC_4BPPV1_Format||p===RGB_PVRTC_2BPPV1_Format||p===RGBA_PVRTC_4BPPV1_Format||p===RGBA_PVRTC_2BPPV1_Format)if(extension=extensions.get("WEBGL_compressed_texture_pvrtc"),extension!==null){if(p===RGB_PVRTC_4BPPV1_Format)return extension.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(p===RGB_PVRTC_2BPPV1_Format)return extension.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(p===RGBA_PVRTC_4BPPV1_Format)return extension.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(p===RGBA_PVRTC_2BPPV1_Format)return extension.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(p===RGB_ETC1_Format||p===RGB_ETC2_Format||p===RGBA_ETC2_EAC_Format||p===R11_EAC_Format||p===SIGNED_R11_EAC_Format||p===RG11_EAC_Format||p===SIGNED_RG11_EAC_Format)if(extension=extensions.get("WEBGL_compressed_texture_etc"),extension!==null){if(p===RGB_ETC1_Format||p===RGB_ETC2_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ETC2:extension.COMPRESSED_RGB8_ETC2;if(p===RGBA_ETC2_EAC_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:extension.COMPRESSED_RGBA8_ETC2_EAC;if(p===R11_EAC_Format)return extension.COMPRESSED_R11_EAC;if(p===SIGNED_R11_EAC_Format)return extension.COMPRESSED_SIGNED_R11_EAC;if(p===RG11_EAC_Format)return extension.COMPRESSED_RG11_EAC;if(p===SIGNED_RG11_EAC_Format)return extension.COMPRESSED_SIGNED_RG11_EAC}else return null;if(p===RGBA_ASTC_4x4_Format||p===RGBA_ASTC_5x4_Format||p===RGBA_ASTC_5x5_Format||p===RGBA_ASTC_6x5_Format||p===RGBA_ASTC_6x6_Format||p===RGBA_ASTC_8x5_Format||p===RGBA_ASTC_8x6_Format||p===RGBA_ASTC_8x8_Format||p===RGBA_ASTC_10x5_Format||p===RGBA_ASTC_10x6_Format||p===RGBA_ASTC_10x8_Format||p===RGBA_ASTC_10x10_Format||p===RGBA_ASTC_12x10_Format||p===RGBA_ASTC_12x12_Format)if(extension=extensions.get("WEBGL_compressed_texture_astc"),extension!==null){if(p===RGBA_ASTC_4x4_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:extension.COMPRESSED_RGBA_ASTC_4x4_KHR;if(p===RGBA_ASTC_5x4_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:extension.COMPRESSED_RGBA_ASTC_5x4_KHR;if(p===RGBA_ASTC_5x5_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:extension.COMPRESSED_RGBA_ASTC_5x5_KHR;if(p===RGBA_ASTC_6x5_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:extension.COMPRESSED_RGBA_ASTC_6x5_KHR;if(p===RGBA_ASTC_6x6_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:extension.COMPRESSED_RGBA_ASTC_6x6_KHR;if(p===RGBA_ASTC_8x5_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:extension.COMPRESSED_RGBA_ASTC_8x5_KHR;if(p===RGBA_ASTC_8x6_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:extension.COMPRESSED_RGBA_ASTC_8x6_KHR;if(p===RGBA_ASTC_8x8_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:extension.COMPRESSED_RGBA_ASTC_8x8_KHR;if(p===RGBA_ASTC_10x5_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:extension.COMPRESSED_RGBA_ASTC_10x5_KHR;if(p===RGBA_ASTC_10x6_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:extension.COMPRESSED_RGBA_ASTC_10x6_KHR;if(p===RGBA_ASTC_10x8_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:extension.COMPRESSED_RGBA_ASTC_10x8_KHR;if(p===RGBA_ASTC_10x10_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:extension.COMPRESSED_RGBA_ASTC_10x10_KHR;if(p===RGBA_ASTC_12x10_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:extension.COMPRESSED_RGBA_ASTC_12x10_KHR;if(p===RGBA_ASTC_12x12_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:extension.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(p===RGBA_BPTC_Format||p===RGB_BPTC_SIGNED_Format||p===RGB_BPTC_UNSIGNED_Format)if(extension=extensions.get("EXT_texture_compression_bptc"),extension!==null){if(p===RGBA_BPTC_Format)return transfer===SRGBTransfer?extension.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:extension.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(p===RGB_BPTC_SIGNED_Format)return extension.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(p===RGB_BPTC_UNSIGNED_Format)return extension.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(p===RED_RGTC1_Format||p===SIGNED_RED_RGTC1_Format||p===RED_GREEN_RGTC2_Format||p===SIGNED_RED_GREEN_RGTC2_Format)if(extension=extensions.get("EXT_texture_compression_rgtc"),extension!==null){if(p===RED_RGTC1_Format)return extension.COMPRESSED_RED_RGTC1_EXT;if(p===SIGNED_RED_RGTC1_Format)return extension.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(p===RED_GREEN_RGTC2_Format)return extension.COMPRESSED_RED_GREEN_RGTC2_EXT;if(p===SIGNED_RED_GREEN_RGTC2_Format)return extension.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;if(p===UnsignedInt248Type)return gl.UNSIGNED_INT_24_8;return gl[p]!==void 0?gl[p]:null}return{convert}}var _occlusion_vertex=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,_occlusion_fragment=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class WebXRDepthSensing{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(depthData,renderState){if(this.texture===null){let texture=new ExternalTexture(depthData.texture);if(depthData.depthNear!==renderState.depthNear||depthData.depthFar!==renderState.depthFar)this.depthNear=depthData.depthNear,this.depthFar=depthData.depthFar;this.texture=texture}}getMesh(cameraXR){if(this.texture!==null){if(this.mesh===null){let viewport=cameraXR.cameras[0].viewport,material=new ShaderMaterial({vertexShader:_occlusion_vertex,fragmentShader:_occlusion_fragment,uniforms:{depthColor:{value:this.texture},depthWidth:{value:viewport.z},depthHeight:{value:viewport.w}}});this.mesh=new Mesh(new PlaneGeometry(20,20),material)}}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class WebXRManager extends EventDispatcher{constructor(renderer,gl){super();let scope=this,session=null,framebufferScaleFactor=1,referenceSpace=null,referenceSpaceType="local-floor",foveation=1,customReferenceSpace=null,pose=null,glBinding=null,glProjLayer=null,glBaseLayer=null,xrFrame=null,supportsGlBinding=typeof XRWebGLBinding<"u",depthSensing=new WebXRDepthSensing,cameraAccessTextures={},attributes=gl.getContextAttributes(),initialRenderTarget=null,newRenderTarget=null,controllers=[],controllerInputSources=[],currentSize=new Vector2,currentPixelRatio=null,cameraL=new PerspectiveCamera;cameraL.viewport=new Vector4;let cameraR=new PerspectiveCamera;cameraR.viewport=new Vector4;let cameras=[cameraL,cameraR],cameraXR=new ArrayCamera,_currentDepthNear=null,_currentDepthFar=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(index){let controller=controllers[index];if(controller===void 0)controller=new WebXRController,controllers[index]=controller;return controller.getTargetRaySpace()},this.getControllerGrip=function(index){let controller=controllers[index];if(controller===void 0)controller=new WebXRController,controllers[index]=controller;return controller.getGripSpace()},this.getHand=function(index){let controller=controllers[index];if(controller===void 0)controller=new WebXRController,controllers[index]=controller;return controller.getHandSpace()};function onSessionEvent(event){let controllerIndex=controllerInputSources.indexOf(event.inputSource);if(controllerIndex===-1)return;let controller=controllers[controllerIndex];if(controller!==void 0)controller.update(event.inputSource,event.frame,customReferenceSpace||referenceSpace),controller.dispatchEvent({type:event.type,data:event.inputSource})}function onSessionEnd(){session.removeEventListener("select",onSessionEvent),session.removeEventListener("selectstart",onSessionEvent),session.removeEventListener("selectend",onSessionEvent),session.removeEventListener("squeeze",onSessionEvent),session.removeEventListener("squeezestart",onSessionEvent),session.removeEventListener("squeezeend",onSessionEvent),session.removeEventListener("end",onSessionEnd),session.removeEventListener("inputsourceschange",onInputSourcesChange);for(let i=0;i<controllers.length;i++){let inputSource=controllerInputSources[i];if(inputSource===null)continue;controllerInputSources[i]=null,controllers[i].disconnect(inputSource)}_currentDepthNear=null,_currentDepthFar=null,depthSensing.reset();for(let key in cameraAccessTextures)delete cameraAccessTextures[key];renderer.setRenderTarget(initialRenderTarget),glBaseLayer=null,glProjLayer=null,glBinding=null,session=null,newRenderTarget=null,animation.stop(),scope.isPresenting=!1,renderer.setPixelRatio(currentPixelRatio),renderer.setSize(currentSize.width,currentSize.height,!1),scope.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(value){if(framebufferScaleFactor=value,scope.isPresenting===!0)warn("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(value){if(referenceSpaceType=value,scope.isPresenting===!0)warn("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return customReferenceSpace||referenceSpace},this.setReferenceSpace=function(space){customReferenceSpace=space},this.getBaseLayer=function(){return glProjLayer!==null?glProjLayer:glBaseLayer},this.getBinding=function(){if(glBinding===null&&supportsGlBinding)glBinding=new XRWebGLBinding(session,gl);return glBinding},this.getFrame=function(){return xrFrame},this.getSession=function(){return session},this.setSession=async function(value){if(session=value,session!==null){if(initialRenderTarget=renderer.getRenderTarget(),session.addEventListener("select",onSessionEvent),session.addEventListener("selectstart",onSessionEvent),session.addEventListener("selectend",onSessionEvent),session.addEventListener("squeeze",onSessionEvent),session.addEventListener("squeezestart",onSessionEvent),session.addEventListener("squeezeend",onSessionEvent),session.addEventListener("end",onSessionEnd),session.addEventListener("inputsourceschange",onInputSourcesChange),attributes.xrCompatible!==!0)await gl.makeXRCompatible();if(currentPixelRatio=renderer.getPixelRatio(),renderer.getSize(currentSize),!(supportsGlBinding&&("createProjectionLayer"in XRWebGLBinding.prototype))){let layerInit={antialias:attributes.antialias,alpha:!0,depth:attributes.depth,stencil:attributes.stencil,framebufferScaleFactor};glBaseLayer=new XRWebGLLayer(session,gl,layerInit),session.updateRenderState({baseLayer:glBaseLayer}),renderer.setPixelRatio(1),renderer.setSize(glBaseLayer.framebufferWidth,glBaseLayer.framebufferHeight,!1),newRenderTarget=new WebGLRenderTarget(glBaseLayer.framebufferWidth,glBaseLayer.framebufferHeight,{format:RGBAFormat,type:UnsignedByteType,colorSpace:renderer.outputColorSpace,stencilBuffer:attributes.stencil,resolveDepthBuffer:glBaseLayer.ignoreDepthValues===!1,resolveStencilBuffer:glBaseLayer.ignoreDepthValues===!1})}else{let depthFormat=null,depthType=null,glDepthFormat=null;if(attributes.depth)glDepthFormat=attributes.stencil?gl.DEPTH24_STENCIL8:gl.DEPTH_COMPONENT24,depthFormat=attributes.stencil?DepthStencilFormat:DepthFormat,depthType=attributes.stencil?UnsignedInt248Type:UnsignedIntType;let projectionlayerInit={colorFormat:gl.RGBA8,depthFormat:glDepthFormat,scaleFactor:framebufferScaleFactor};glBinding=this.getBinding(),glProjLayer=glBinding.createProjectionLayer(projectionlayerInit),session.updateRenderState({layers:[glProjLayer]}),renderer.setPixelRatio(1),renderer.setSize(glProjLayer.textureWidth,glProjLayer.textureHeight,!1),newRenderTarget=new WebGLRenderTarget(glProjLayer.textureWidth,glProjLayer.textureHeight,{format:RGBAFormat,type:UnsignedByteType,depthTexture:new DepthTexture(glProjLayer.textureWidth,glProjLayer.textureHeight,depthType,void 0,void 0,void 0,void 0,void 0,void 0,depthFormat),stencilBuffer:attributes.stencil,colorSpace:renderer.outputColorSpace,samples:attributes.antialias?4:0,resolveDepthBuffer:glProjLayer.ignoreDepthValues===!1,resolveStencilBuffer:glProjLayer.ignoreDepthValues===!1})}newRenderTarget.isXRRenderTarget=!0,this.setFoveation(foveation),customReferenceSpace=null,referenceSpace=await session.requestReferenceSpace(referenceSpaceType),animation.setContext(session),animation.start(),scope.isPresenting=!0,scope.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(session!==null)return session.environmentBlendMode},this.getDepthTexture=function(){return depthSensing.getDepthTexture()};function onInputSourcesChange(event){for(let i=0;i<event.removed.length;i++){let inputSource=event.removed[i],index=controllerInputSources.indexOf(inputSource);if(index>=0)controllerInputSources[index]=null,controllers[index].disconnect(inputSource)}for(let i=0;i<event.added.length;i++){let inputSource=event.added[i],controllerIndex=controllerInputSources.indexOf(inputSource);if(controllerIndex===-1){for(let i2=0;i2<controllers.length;i2++)if(i2>=controllerInputSources.length){controllerInputSources.push(inputSource),controllerIndex=i2;break}else if(controllerInputSources[i2]===null){controllerInputSources[i2]=inputSource,controllerIndex=i2;break}if(controllerIndex===-1)break}let controller=controllers[controllerIndex];if(controller)controller.connect(inputSource)}}let cameraLPos=new Vector3,cameraRPos=new Vector3;function setProjectionFromUnion(camera,cameraL2,cameraR2){cameraLPos.setFromMatrixPosition(cameraL2.matrixWorld),cameraRPos.setFromMatrixPosition(cameraR2.matrixWorld);let ipd=cameraLPos.distanceTo(cameraRPos),projL=cameraL2.projectionMatrix.elements,projR=cameraR2.projectionMatrix.elements,near=projL[14]/(projL[10]-1),far=projL[14]/(projL[10]+1),topFov=(projL[9]+1)/projL[5],bottomFov=(projL[9]-1)/projL[5],leftFov=(projL[8]-1)/projL[0],rightFov=(projR[8]+1)/projR[0],left=near*leftFov,right=near*rightFov,zOffset=ipd/(-leftFov+rightFov),xOffset=zOffset*-leftFov;if(cameraL2.matrixWorld.decompose(camera.position,camera.quaternion,camera.scale),camera.translateX(xOffset),camera.translateZ(zOffset),camera.matrixWorld.compose(camera.position,camera.quaternion,camera.scale),camera.matrixWorldInverse.copy(camera.matrixWorld).invert(),projL[10]===-1)camera.projectionMatrix.copy(cameraL2.projectionMatrix),camera.projectionMatrixInverse.copy(cameraL2.projectionMatrixInverse);else{let near2=near+zOffset,far2=far+zOffset,left2=left-xOffset,right2=right+(ipd-xOffset),top2=topFov*far/far2*near2,bottom2=bottomFov*far/far2*near2;camera.projectionMatrix.makePerspective(left2,right2,top2,bottom2,near2,far2),camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert()}}function updateCamera(camera,parent){if(parent===null)camera.matrixWorld.copy(camera.matrix);else camera.matrixWorld.multiplyMatrices(parent.matrixWorld,camera.matrix);camera.matrixWorldInverse.copy(camera.matrixWorld).invert()}this.updateCamera=function(camera){if(session===null)return;let{near:depthNear,far:depthFar}=camera;if(depthSensing.texture!==null){if(depthSensing.depthNear>0)depthNear=depthSensing.depthNear;if(depthSensing.depthFar>0)depthFar=depthSensing.depthFar}if(cameraXR.near=cameraR.near=cameraL.near=depthNear,cameraXR.far=cameraR.far=cameraL.far=depthFar,_currentDepthNear!==cameraXR.near||_currentDepthFar!==cameraXR.far)session.updateRenderState({depthNear:cameraXR.near,depthFar:cameraXR.far}),_currentDepthNear=cameraXR.near,_currentDepthFar=cameraXR.far;cameraXR.layers.mask=camera.layers.mask|6,cameraL.layers.mask=cameraXR.layers.mask&-5,cameraR.layers.mask=cameraXR.layers.mask&-3;let parent=camera.parent,cameras2=cameraXR.cameras;updateCamera(cameraXR,parent);for(let i=0;i<cameras2.length;i++)updateCamera(cameras2[i],parent);if(cameras2.length===2)setProjectionFromUnion(cameraXR,cameraL,cameraR);else cameraXR.projectionMatrix.copy(cameraL.projectionMatrix);updateUserCamera(camera,cameraXR,parent)};function updateUserCamera(camera,cameraXR2,parent){if(parent===null)camera.matrix.copy(cameraXR2.matrixWorld);else camera.matrix.copy(parent.matrixWorld),camera.matrix.invert(),camera.matrix.multiply(cameraXR2.matrixWorld);if(camera.matrix.decompose(camera.position,camera.quaternion,camera.scale),camera.updateMatrixWorld(!0),camera.projectionMatrix.copy(cameraXR2.projectionMatrix),camera.projectionMatrixInverse.copy(cameraXR2.projectionMatrixInverse),camera.isPerspectiveCamera)camera.fov=RAD2DEG*2*Math.atan(1/camera.projectionMatrix.elements[5]),camera.zoom=1}this.getCamera=function(){return cameraXR},this.getFoveation=function(){if(glProjLayer===null&&glBaseLayer===null)return;return foveation},this.setFoveation=function(value){if(foveation=value,glProjLayer!==null)glProjLayer.fixedFoveation=value;if(glBaseLayer!==null&&glBaseLayer.fixedFoveation!==void 0)glBaseLayer.fixedFoveation=value},this.hasDepthSensing=function(){return depthSensing.texture!==null},this.getDepthSensingMesh=function(){return depthSensing.getMesh(cameraXR)},this.getCameraTexture=function(xrCamera){return cameraAccessTextures[xrCamera]};let onAnimationFrameCallback=null;function onAnimationFrame(time,frame){if(pose=frame.getViewerPose(customReferenceSpace||referenceSpace),xrFrame=frame,pose!==null){let views=pose.views;if(glBaseLayer!==null)renderer.setRenderTargetFramebuffer(newRenderTarget,glBaseLayer.framebuffer),renderer.setRenderTarget(newRenderTarget);let cameraXRNeedsUpdate=!1;if(views.length!==cameraXR.cameras.length)cameraXR.cameras.length=0,cameraXRNeedsUpdate=!0;for(let i=0;i<views.length;i++){let view=views[i],viewport=null;if(glBaseLayer!==null)viewport=glBaseLayer.getViewport(view);else{let glSubImage=glBinding.getViewSubImage(glProjLayer,view);if(viewport=glSubImage.viewport,i===0)renderer.setRenderTargetTextures(newRenderTarget,glSubImage.colorTexture,glSubImage.depthStencilTexture),renderer.setRenderTarget(newRenderTarget)}let camera=cameras[i];if(camera===void 0)camera=new PerspectiveCamera,camera.layers.enable(i),camera.viewport=new Vector4,cameras[i]=camera;if(camera.matrix.fromArray(view.transform.matrix),camera.matrix.decompose(camera.position,camera.quaternion,camera.scale),camera.projectionMatrix.fromArray(view.projectionMatrix),camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert(),camera.viewport.set(viewport.x,viewport.y,viewport.width,viewport.height),i===0)cameraXR.matrix.copy(camera.matrix),cameraXR.matrix.decompose(cameraXR.position,cameraXR.quaternion,cameraXR.scale);if(cameraXRNeedsUpdate===!0)cameraXR.cameras.push(camera)}let enabledFeatures=session.enabledFeatures;if(enabledFeatures&&enabledFeatures.includes("depth-sensing")&&session.depthUsage=="gpu-optimized"&&supportsGlBinding){glBinding=scope.getBinding();let depthData=glBinding.getDepthInformation(views[0]);if(depthData&&depthData.isValid&&depthData.texture)depthSensing.init(depthData,session.renderState)}if(enabledFeatures&&enabledFeatures.includes("camera-access")&&supportsGlBinding){renderer.state.unbindTexture(),glBinding=scope.getBinding();for(let i=0;i<views.length;i++){let camera=views[i].camera;if(camera){let cameraTex=cameraAccessTextures[camera];if(!cameraTex)cameraTex=new ExternalTexture,cameraAccessTextures[camera]=cameraTex;let glTexture=glBinding.getCameraImage(camera);cameraTex.sourceTexture=glTexture}}}}for(let i=0;i<controllers.length;i++){let inputSource=controllerInputSources[i],controller=controllers[i];if(inputSource!==null&&controller!==void 0)controller.update(inputSource,frame,customReferenceSpace||referenceSpace)}if(onAnimationFrameCallback)onAnimationFrameCallback(time,frame);if(frame.detectedPlanes)scope.dispatchEvent({type:"planesdetected",data:frame});xrFrame=null}let animation=new WebGLAnimation;animation.setAnimationLoop(onAnimationFrame),this.setAnimationLoop=function(callback){onAnimationFrameCallback=callback},this.dispose=function(){}}}var _m1=new Matrix4,_m=new Matrix3;_m.set(-1,0,0,0,1,0,0,0,1);function WebGLMaterials(renderer,properties){function refreshTransformUniform(map,uniform){if(map.matrixAutoUpdate===!0)map.updateMatrix();uniform.value.copy(map.matrix)}function refreshFogUniforms(uniforms,fog){if(fog.color.getRGB(uniforms.fogColor.value,getUnlitUniformColorSpace(renderer)),fog.isFog)uniforms.fogNear.value=fog.near,uniforms.fogFar.value=fog.far;else if(fog.isFogExp2)uniforms.fogDensity.value=fog.density}function refreshMaterialUniforms(uniforms,material,pixelRatio,height,transmissionRenderTarget){if(material.isNodeMaterial)material.uniformsNeedUpdate=!1;else if(material.isMeshBasicMaterial)refreshUniformsCommon(uniforms,material);else if(material.isMeshLambertMaterial){if(refreshUniformsCommon(uniforms,material),material.envMap)uniforms.envMapIntensity.value=material.envMapIntensity}else if(material.isMeshToonMaterial)refreshUniformsCommon(uniforms,material),refreshUniformsToon(uniforms,material);else if(material.isMeshPhongMaterial){if(refreshUniformsCommon(uniforms,material),refreshUniformsPhong(uniforms,material),material.envMap)uniforms.envMapIntensity.value=material.envMapIntensity}else if(material.isMeshStandardMaterial){if(refreshUniformsCommon(uniforms,material),refreshUniformsStandard(uniforms,material),material.isMeshPhysicalMaterial)refreshUniformsPhysical(uniforms,material,transmissionRenderTarget)}else if(material.isMeshMatcapMaterial)refreshUniformsCommon(uniforms,material),refreshUniformsMatcap(uniforms,material);else if(material.isMeshDepthMaterial)refreshUniformsCommon(uniforms,material);else if(material.isMeshDistanceMaterial)refreshUniformsCommon(uniforms,material),refreshUniformsDistance(uniforms,material);else if(material.isMeshNormalMaterial)refreshUniformsCommon(uniforms,material);else if(material.isLineBasicMaterial){if(refreshUniformsLine(uniforms,material),material.isLineDashedMaterial)refreshUniformsDash(uniforms,material)}else if(material.isPointsMaterial)refreshUniformsPoints(uniforms,material,pixelRatio,height);else if(material.isSpriteMaterial)refreshUniformsSprites(uniforms,material);else if(material.isShadowMaterial)uniforms.color.value.copy(material.color),uniforms.opacity.value=material.opacity;else if(material.isShaderMaterial)material.uniformsNeedUpdate=!1}function refreshUniformsCommon(uniforms,material){if(uniforms.opacity.value=material.opacity,material.color)uniforms.diffuse.value.copy(material.color);if(material.emissive)uniforms.emissive.value.copy(material.emissive).multiplyScalar(material.emissiveIntensity);if(material.map)uniforms.map.value=material.map,refreshTransformUniform(material.map,uniforms.mapTransform);if(material.alphaMap)uniforms.alphaMap.value=material.alphaMap,refreshTransformUniform(material.alphaMap,uniforms.alphaMapTransform);if(material.bumpMap){if(uniforms.bumpMap.value=material.bumpMap,refreshTransformUniform(material.bumpMap,uniforms.bumpMapTransform),uniforms.bumpScale.value=material.bumpScale,material.side===BackSide)uniforms.bumpScale.value*=-1}if(material.normalMap){if(uniforms.normalMap.value=material.normalMap,refreshTransformUniform(material.normalMap,uniforms.normalMapTransform),uniforms.normalScale.value.copy(material.normalScale),material.side===BackSide)uniforms.normalScale.value.negate()}if(material.displacementMap)uniforms.displacementMap.value=material.displacementMap,refreshTransformUniform(material.displacementMap,uniforms.displacementMapTransform),uniforms.displacementScale.value=material.displacementScale,uniforms.displacementBias.value=material.displacementBias;if(material.emissiveMap)uniforms.emissiveMap.value=material.emissiveMap,refreshTransformUniform(material.emissiveMap,uniforms.emissiveMapTransform);if(material.specularMap)uniforms.specularMap.value=material.specularMap,refreshTransformUniform(material.specularMap,uniforms.specularMapTransform);if(material.alphaTest>0)uniforms.alphaTest.value=material.alphaTest;let materialProperties=properties.get(material),envMap=materialProperties.envMap,envMapRotation=materialProperties.envMapRotation;if(envMap){if(uniforms.envMap.value=envMap,uniforms.envMapRotation.value.setFromMatrix4(_m1.makeRotationFromEuler(envMapRotation)).transpose(),envMap.isCubeTexture&&envMap.isRenderTargetTexture===!1)uniforms.envMapRotation.value.premultiply(_m);uniforms.reflectivity.value=material.reflectivity,uniforms.ior.value=material.ior,uniforms.refractionRatio.value=material.refractionRatio}if(material.lightMap)uniforms.lightMap.value=material.lightMap,uniforms.lightMapIntensity.value=material.lightMapIntensity,refreshTransformUniform(material.lightMap,uniforms.lightMapTransform);if(material.aoMap)uniforms.aoMap.value=material.aoMap,uniforms.aoMapIntensity.value=material.aoMapIntensity,refreshTransformUniform(material.aoMap,uniforms.aoMapTransform)}function refreshUniformsLine(uniforms,material){if(uniforms.diffuse.value.copy(material.color),uniforms.opacity.value=material.opacity,material.map)uniforms.map.value=material.map,refreshTransformUniform(material.map,uniforms.mapTransform)}function refreshUniformsDash(uniforms,material){uniforms.dashSize.value=material.dashSize,uniforms.totalSize.value=material.dashSize+material.gapSize,uniforms.scale.value=material.scale}function refreshUniformsPoints(uniforms,material,pixelRatio,height){if(uniforms.diffuse.value.copy(material.color),uniforms.opacity.value=material.opacity,uniforms.size.value=material.size*pixelRatio,uniforms.scale.value=height*0.5,material.map)uniforms.map.value=material.map,refreshTransformUniform(material.map,uniforms.uvTransform);if(material.alphaMap)uniforms.alphaMap.value=material.alphaMap,refreshTransformUniform(material.alphaMap,uniforms.alphaMapTransform);if(material.alphaTest>0)uniforms.alphaTest.value=material.alphaTest}function refreshUniformsSprites(uniforms,material){if(uniforms.diffuse.value.copy(material.color),uniforms.opacity.value=material.opacity,uniforms.rotation.value=material.rotation,material.map)uniforms.map.value=material.map,refreshTransformUniform(material.map,uniforms.mapTransform);if(material.alphaMap)uniforms.alphaMap.value=material.alphaMap,refreshTransformUniform(material.alphaMap,uniforms.alphaMapTransform);if(material.alphaTest>0)uniforms.alphaTest.value=material.alphaTest}function refreshUniformsPhong(uniforms,material){uniforms.specular.value.copy(material.specular),uniforms.shininess.value=Math.max(material.shininess,0.0001)}function refreshUniformsToon(uniforms,material){if(material.gradientMap)uniforms.gradientMap.value=material.gradientMap}function refreshUniformsStandard(uniforms,material){if(uniforms.metalness.value=material.metalness,material.metalnessMap)uniforms.metalnessMap.value=material.metalnessMap,refreshTransformUniform(material.metalnessMap,uniforms.metalnessMapTransform);if(uniforms.roughness.value=material.roughness,material.roughnessMap)uniforms.roughnessMap.value=material.roughnessMap,refreshTransformUniform(material.roughnessMap,uniforms.roughnessMapTransform);if(material.envMap)uniforms.envMapIntensity.value=material.envMapIntensity}function refreshUniformsPhysical(uniforms,material,transmissionRenderTarget){if(uniforms.ior.value=material.ior,material.sheen>0){if(uniforms.sheenColor.value.copy(material.sheenColor).multiplyScalar(material.sheen),uniforms.sheenRoughness.value=material.sheenRoughness,material.sheenColorMap)uniforms.sheenColorMap.value=material.sheenColorMap,refreshTransformUniform(material.sheenColorMap,uniforms.sheenColorMapTransform);if(material.sheenRoughnessMap)uniforms.sheenRoughnessMap.value=material.sheenRoughnessMap,refreshTransformUniform(material.sheenRoughnessMap,uniforms.sheenRoughnessMapTransform)}if(material.clearcoat>0){if(uniforms.clearcoat.value=material.clearcoat,uniforms.clearcoatRoughness.value=material.clearcoatRoughness,material.clearcoatMap)uniforms.clearcoatMap.value=material.clearcoatMap,refreshTransformUniform(material.clearcoatMap,uniforms.clearcoatMapTransform);if(material.clearcoatRoughnessMap)uniforms.clearcoatRoughnessMap.value=material.clearcoatRoughnessMap,refreshTransformUniform(material.clearcoatRoughnessMap,uniforms.clearcoatRoughnessMapTransform);if(material.clearcoatNormalMap){if(uniforms.clearcoatNormalMap.value=material.clearcoatNormalMap,refreshTransformUniform(material.clearcoatNormalMap,uniforms.clearcoatNormalMapTransform),uniforms.clearcoatNormalScale.value.copy(material.clearcoatNormalScale),material.side===BackSide)uniforms.clearcoatNormalScale.value.negate()}}if(material.dispersion>0)uniforms.dispersion.value=material.dispersion;if(material.iridescence>0){if(uniforms.iridescence.value=material.iridescence,uniforms.iridescenceIOR.value=material.iridescenceIOR,uniforms.iridescenceThicknessMinimum.value=material.iridescenceThicknessRange[0],uniforms.iridescenceThicknessMaximum.value=material.iridescenceThicknessRange[1],material.iridescenceMap)uniforms.iridescenceMap.value=material.iridescenceMap,refreshTransformUniform(material.iridescenceMap,uniforms.iridescenceMapTransform);if(material.iridescenceThicknessMap)uniforms.iridescenceThicknessMap.value=material.iridescenceThicknessMap,refreshTransformUniform(material.iridescenceThicknessMap,uniforms.iridescenceThicknessMapTransform)}if(material.transmission>0){if(uniforms.transmission.value=material.transmission,uniforms.transmissionSamplerMap.value=transmissionRenderTarget.texture,uniforms.transmissionSamplerSize.value.set(transmissionRenderTarget.width,transmissionRenderTarget.height),material.transmissionMap)uniforms.transmissionMap.value=material.transmissionMap,refreshTransformUniform(material.transmissionMap,uniforms.transmissionMapTransform);if(uniforms.thickness.value=material.thickness,material.thicknessMap)uniforms.thicknessMap.value=material.thicknessMap,refreshTransformUniform(material.thicknessMap,uniforms.thicknessMapTransform);uniforms.attenuationDistance.value=material.attenuationDistance,uniforms.attenuationColor.value.copy(material.attenuationColor)}if(material.anisotropy>0){if(uniforms.anisotropyVector.value.set(material.anisotropy*Math.cos(material.anisotropyRotation),material.anisotropy*Math.sin(material.anisotropyRotation)),material.anisotropyMap)uniforms.anisotropyMap.value=material.anisotropyMap,refreshTransformUniform(material.anisotropyMap,uniforms.anisotropyMapTransform)}if(uniforms.specularIntensity.value=material.specularIntensity,uniforms.specularColor.value.copy(material.specularColor),material.specularColorMap)uniforms.specularColorMap.value=material.specularColorMap,refreshTransformUniform(material.specularColorMap,uniforms.specularColorMapTransform);if(material.specularIntensityMap)uniforms.specularIntensityMap.value=material.specularIntensityMap,refreshTransformUniform(material.specularIntensityMap,uniforms.specularIntensityMapTransform)}function refreshUniformsMatcap(uniforms,material){if(material.matcap)uniforms.matcap.value=material.matcap}function refreshUniformsDistance(uniforms,material){let light=properties.get(material).light;uniforms.referencePosition.value.setFromMatrixPosition(light.matrixWorld),uniforms.nearDistance.value=light.shadow.camera.near,uniforms.farDistance.value=light.shadow.camera.far}return{refreshFogUniforms,refreshMaterialUniforms}}function WebGLUniformsGroups(gl,info,capabilities,state){let buffers={},updateList={},allocatedBindingPoints=[],maxBindingPoints=gl.getParameter(gl.MAX_UNIFORM_BUFFER_BINDINGS);function bind(uniformsGroup,program){let webglProgram=program.program;state.uniformBlockBinding(uniformsGroup,webglProgram)}function update(uniformsGroup,program){let buffer=buffers[uniformsGroup.id];if(buffer===void 0)prepareUniformsGroup(uniformsGroup),buffer=createBuffer(uniformsGroup),buffers[uniformsGroup.id]=buffer,uniformsGroup.addEventListener("dispose",onUniformsGroupsDispose);let webglProgram=program.program;state.updateUBOMapping(uniformsGroup,webglProgram);let frame=info.render.frame;if(updateList[uniformsGroup.id]!==frame)updateBufferData(uniformsGroup),updateList[uniformsGroup.id]=frame}function createBuffer(uniformsGroup){let bindingPointIndex=allocateBindingPointIndex();uniformsGroup.__bindingPointIndex=bindingPointIndex;let buffer=gl.createBuffer(),size=uniformsGroup.__size,usage=uniformsGroup.usage;return gl.bindBuffer(gl.UNIFORM_BUFFER,buffer),gl.bufferData(gl.UNIFORM_BUFFER,size,usage),gl.bindBuffer(gl.UNIFORM_BUFFER,null),gl.bindBufferBase(gl.UNIFORM_BUFFER,bindingPointIndex,buffer),buffer}function allocateBindingPointIndex(){for(let i=0;i<maxBindingPoints;i++)if(allocatedBindingPoints.indexOf(i)===-1)return allocatedBindingPoints.push(i),i;return error("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function updateBufferData(uniformsGroup){let buffer=buffers[uniformsGroup.id],uniforms=uniformsGroup.uniforms,cache=uniformsGroup.__cache;gl.bindBuffer(gl.UNIFORM_BUFFER,buffer);for(let i=0,il=uniforms.length;i<il;i++){let uniformArray=Array.isArray(uniforms[i])?uniforms[i]:[uniforms[i]];for(let j=0,jl=uniformArray.length;j<jl;j++){let uniform=uniformArray[j];if(hasUniformChanged(uniform,i,j,cache)===!0){let offset=uniform.__offset,values=Array.isArray(uniform.value)?uniform.value:[uniform.value],arrayOffset=0;for(let k=0;k<values.length;k++){let value=values[k],info2=getUniformSize(value);if(typeof value==="number"||typeof value==="boolean")uniform.__data[0]=value,gl.bufferSubData(gl.UNIFORM_BUFFER,offset+arrayOffset,uniform.__data);else if(value.isMatrix3)uniform.__data[0]=value.elements[0],uniform.__data[1]=value.elements[1],uniform.__data[2]=value.elements[2],uniform.__data[3]=0,uniform.__data[4]=value.elements[3],uniform.__data[5]=value.elements[4],uniform.__data[6]=value.elements[5],uniform.__data[7]=0,uniform.__data[8]=value.elements[6],uniform.__data[9]=value.elements[7],uniform.__data[10]=value.elements[8],uniform.__data[11]=0;else if(ArrayBuffer.isView(value))uniform.__data.set(new value.constructor(value.buffer,value.byteOffset,uniform.__data.length));else value.toArray(uniform.__data,arrayOffset),arrayOffset+=info2.storage/Float32Array.BYTES_PER_ELEMENT}gl.bufferSubData(gl.UNIFORM_BUFFER,offset,uniform.__data)}}}gl.bindBuffer(gl.UNIFORM_BUFFER,null)}function hasUniformChanged(uniform,index,indexArray,cache){let value=uniform.value,indexString=index+"_"+indexArray;if(cache[indexString]===void 0){if(typeof value==="number"||typeof value==="boolean")cache[indexString]=value;else if(ArrayBuffer.isView(value))cache[indexString]=value.slice();else cache[indexString]=value.clone();return!0}else{let cachedObject=cache[indexString];if(typeof value==="number"||typeof value==="boolean"){if(cachedObject!==value)return cache[indexString]=value,!0}else if(ArrayBuffer.isView(value))return!0;else if(cachedObject.equals(value)===!1)return cachedObject.copy(value),!0}return!1}function prepareUniformsGroup(uniformsGroup){let uniforms=uniformsGroup.uniforms,offset=0,chunkSize=16;for(let i=0,l=uniforms.length;i<l;i++){let uniformArray=Array.isArray(uniforms[i])?uniforms[i]:[uniforms[i]];for(let j=0,jl=uniformArray.length;j<jl;j++){let uniform=uniformArray[j],values=Array.isArray(uniform.value)?uniform.value:[uniform.value];for(let k=0,kl=values.length;k<kl;k++){let value=values[k],info2=getUniformSize(value),chunkOffset2=offset%chunkSize,chunkPadding=chunkOffset2%info2.boundary,chunkStart=chunkOffset2+chunkPadding;if(offset+=chunkPadding,chunkStart!==0&&chunkSize-chunkStart<info2.storage)offset+=chunkSize-chunkStart;uniform.__data=new Float32Array(info2.storage/Float32Array.BYTES_PER_ELEMENT),uniform.__offset=offset,offset+=info2.storage}}}let chunkOffset=offset%chunkSize;if(chunkOffset>0)offset+=chunkSize-chunkOffset;return uniformsGroup.__size=offset,uniformsGroup.__cache={},this}function getUniformSize(value){let info2={boundary:0,storage:0};if(typeof value==="number"||typeof value==="boolean")info2.boundary=4,info2.storage=4;else if(value.isVector2)info2.boundary=8,info2.storage=8;else if(value.isVector3||value.isColor)info2.boundary=16,info2.storage=12;else if(value.isVector4)info2.boundary=16,info2.storage=16;else if(value.isMatrix3)info2.boundary=48,info2.storage=48;else if(value.isMatrix4)info2.boundary=64,info2.storage=64;else if(value.isTexture)warn("WebGLRenderer: Texture samplers can not be part of an uniforms group.");else if(ArrayBuffer.isView(value))info2.boundary=16,info2.storage=value.byteLength;else warn("WebGLRenderer: Unsupported uniform value type.",value);return info2}function onUniformsGroupsDispose(event){let uniformsGroup=event.target;uniformsGroup.removeEventListener("dispose",onUniformsGroupsDispose);let index=allocatedBindingPoints.indexOf(uniformsGroup.__bindingPointIndex);allocatedBindingPoints.splice(index,1),gl.deleteBuffer(buffers[uniformsGroup.id]),delete buffers[uniformsGroup.id],delete updateList[uniformsGroup.id]}function dispose(){for(let id in buffers)gl.deleteBuffer(buffers[id]);allocatedBindingPoints=[],buffers={},updateList={}}return{bind,update,dispose}}var DATA=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),lut=null;function getDFGLUT(){if(lut===null)lut=new DataTexture(DATA,16,16,RGFormat,HalfFloatType),lut.name="DFG_LUT",lut.minFilter=LinearFilter,lut.magFilter=LinearFilter,lut.wrapS=ClampToEdgeWrapping,lut.wrapT=ClampToEdgeWrapping,lut.generateMipmaps=!1,lut.needsUpdate=!0;return lut}class WebGLRenderer{constructor(parameters={}){let{canvas=createCanvasElement(),context=null,depth=!0,stencil=!1,alpha=!1,antialias=!1,premultipliedAlpha=!0,preserveDrawingBuffer=!1,powerPreference="default",failIfMajorPerformanceCaveat=!1,reversedDepthBuffer=!1,outputBufferType=UnsignedByteType}=parameters;this.isWebGLRenderer=!0;let _alpha;if(context!==null){if(typeof WebGLRenderingContext<"u"&&context instanceof WebGLRenderingContext)throw Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");_alpha=context.getContextAttributes().alpha}else _alpha=alpha;let _outputBufferType=outputBufferType,INTEGER_FORMATS=new Set([RGBAIntegerFormat,RGIntegerFormat,RedIntegerFormat]),UNSIGNED_TYPES=new Set([UnsignedByteType,UnsignedIntType,UnsignedShortType,UnsignedInt248Type,UnsignedShort4444Type,UnsignedShort5551Type]),uintClearColor=new Uint32Array(4),intClearColor=new Int32Array(4),objectPosition=new Vector3,currentRenderList=null,currentRenderState=null,renderListStack=[],renderStateStack=[],output=null;this.domElement=canvas,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=NoToneMapping,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let _this=this,_isContextLost=!1,_nodesHandler=null;this._outputColorSpace=SRGBColorSpace;let _currentActiveCubeFace=0,_currentActiveMipmapLevel=0,_currentRenderTarget=null,_currentMaterialId=-1,_currentCamera=null,_currentViewport=new Vector4,_currentScissor=new Vector4,_currentScissorTest=null,_currentClearColor=new Color(0),_currentClearAlpha=0,_width=canvas.width,_height=canvas.height,_pixelRatio=1,_opaqueSort=null,_transparentSort=null,_viewport=new Vector4(0,0,_width,_height),_scissor=new Vector4(0,0,_width,_height),_scissorTest=!1,_frustum=new Frustum,_clippingEnabled=!1,_localClippingEnabled=!1,_projScreenMatrix2=new Matrix4,_vector3=new Vector3,_vector4=new Vector4,_emptyScene={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},_renderBackground=!1;function getTargetPixelRatio(){return _currentRenderTarget===null?_pixelRatio:1}let _gl=context;function getContext(contextName,contextAttributes){return canvas.getContext(contextName,contextAttributes)}try{let contextAttributes={alpha:!0,depth,stencil,antialias,premultipliedAlpha,preserveDrawingBuffer,powerPreference,failIfMajorPerformanceCaveat};if("setAttribute"in canvas)canvas.setAttribute("data-engine",`three.js r${REVISION}`);if(canvas.addEventListener("webglcontextlost",onContextLost,!1),canvas.addEventListener("webglcontextrestored",onContextRestore,!1),canvas.addEventListener("webglcontextcreationerror",onContextCreationError,!1),_gl===null){if(_gl=getContext("webgl2",contextAttributes),_gl===null)if(getContext("webgl2"))throw Error("Error creating WebGL context with your selected attributes.");else throw Error("Error creating WebGL context.")}}catch(e){throw error("WebGLRenderer: "+e.message),e}let extensions,capabilities,state,info,properties,textures,environments,attributes,geometries,objects,programCache,materials,renderLists,renderStates,clipping,shadowMap,background,morphtargets,bufferRenderer,indexedBufferRenderer,utils,bindingStates,uniformsGroups;function initGLContext(){if(extensions=new WebGLExtensions(_gl),extensions.init(),utils=new WebGLUtils(_gl,extensions),capabilities=new WebGLCapabilities(_gl,extensions,parameters,utils),state=new WebGLState(_gl,extensions),capabilities.reversedDepthBuffer&&reversedDepthBuffer)state.buffers.depth.setReversed(!0);info=new WebGLInfo(_gl),properties=new WebGLProperties,textures=new WebGLTextures(_gl,extensions,state,properties,capabilities,utils,info),environments=new WebGLEnvironments(_this),attributes=new WebGLAttributes(_gl),bindingStates=new WebGLBindingStates(_gl,attributes),geometries=new WebGLGeometries(_gl,attributes,info,bindingStates),objects=new WebGLObjects(_gl,geometries,attributes,bindingStates,info),morphtargets=new WebGLMorphtargets(_gl,capabilities,textures),clipping=new WebGLClipping(properties),programCache=new WebGLPrograms(_this,environments,extensions,capabilities,bindingStates,clipping),materials=new WebGLMaterials(_this,properties),renderLists=new WebGLRenderLists,renderStates=new WebGLRenderStates(extensions),background=new WebGLBackground(_this,environments,state,objects,_alpha,premultipliedAlpha),shadowMap=new WebGLShadowMap(_this,objects,capabilities),uniformsGroups=new WebGLUniformsGroups(_gl,info,capabilities,state),bufferRenderer=new WebGLBufferRenderer(_gl,extensions,info),indexedBufferRenderer=new WebGLIndexedBufferRenderer(_gl,extensions,info),info.programs=programCache.programs,_this.capabilities=capabilities,_this.extensions=extensions,_this.properties=properties,_this.renderLists=renderLists,_this.shadowMap=shadowMap,_this.state=state,_this.info=info}if(initGLContext(),_outputBufferType!==UnsignedByteType)output=new WebGLOutput(_outputBufferType,canvas.width,canvas.height,depth,stencil);let xr=new WebXRManager(_this,_gl);this.xr=xr,this.getContext=function(){return _gl},this.getContextAttributes=function(){return _gl.getContextAttributes()},this.forceContextLoss=function(){let extension=extensions.get("WEBGL_lose_context");if(extension)extension.loseContext()},this.forceContextRestore=function(){let extension=extensions.get("WEBGL_lose_context");if(extension)extension.restoreContext()},this.getPixelRatio=function(){return _pixelRatio},this.setPixelRatio=function(value){if(value===void 0)return;_pixelRatio=value,this.setSize(_width,_height,!1)},this.getSize=function(target){return target.set(_width,_height)},this.setSize=function(width,height,updateStyle=!0){if(xr.isPresenting){warn("WebGLRenderer: Can't change size while VR device is presenting.");return}if(_width=width,_height=height,canvas.width=Math.floor(width*_pixelRatio),canvas.height=Math.floor(height*_pixelRatio),updateStyle===!0)canvas.style.width=width+"px",canvas.style.height=height+"px";if(output!==null)output.setSize(canvas.width,canvas.height);this.setViewport(0,0,width,height)},this.getDrawingBufferSize=function(target){return target.set(_width*_pixelRatio,_height*_pixelRatio).floor()},this.setDrawingBufferSize=function(width,height,pixelRatio){_width=width,_height=height,_pixelRatio=pixelRatio,canvas.width=Math.floor(width*pixelRatio),canvas.height=Math.floor(height*pixelRatio),this.setViewport(0,0,width,height)},this.setEffects=function(effects){if(_outputBufferType===UnsignedByteType){error("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(effects){for(let i=0;i<effects.length;i++)if(effects[i].isOutputPass===!0){warn("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}output.setEffects(effects||[])},this.getCurrentViewport=function(target){return target.copy(_currentViewport)},this.getViewport=function(target){return target.copy(_viewport)},this.setViewport=function(x,y,width,height){if(x.isVector4)_viewport.set(x.x,x.y,x.z,x.w);else _viewport.set(x,y,width,height);state.viewport(_currentViewport.copy(_viewport).multiplyScalar(_pixelRatio).round())},this.getScissor=function(target){return target.copy(_scissor)},this.setScissor=function(x,y,width,height){if(x.isVector4)_scissor.set(x.x,x.y,x.z,x.w);else _scissor.set(x,y,width,height);state.scissor(_currentScissor.copy(_scissor).multiplyScalar(_pixelRatio).round())},this.getScissorTest=function(){return _scissorTest},this.setScissorTest=function(boolean){state.setScissorTest(_scissorTest=boolean)},this.setOpaqueSort=function(method){_opaqueSort=method},this.setTransparentSort=function(method){_transparentSort=method},this.getClearColor=function(target){return target.copy(background.getClearColor())},this.setClearColor=function(){background.setClearColor(...arguments)},this.getClearAlpha=function(){return background.getClearAlpha()},this.setClearAlpha=function(){background.setClearAlpha(...arguments)},this.clear=function(color=!0,depth2=!0,stencil2=!0){let bits=0;if(color){let isIntegerFormat=!1;if(_currentRenderTarget!==null){let targetFormat=_currentRenderTarget.texture.format;isIntegerFormat=INTEGER_FORMATS.has(targetFormat)}if(isIntegerFormat){let targetType=_currentRenderTarget.texture.type,isUnsignedType=UNSIGNED_TYPES.has(targetType),clearColor=background.getClearColor(),a=background.getClearAlpha(),r=clearColor.r,g=clearColor.g,b=clearColor.b;if(isUnsignedType)uintClearColor[0]=r,uintClearColor[1]=g,uintClearColor[2]=b,uintClearColor[3]=a,_gl.clearBufferuiv(_gl.COLOR,0,uintClearColor);else intClearColor[0]=r,intClearColor[1]=g,intClearColor[2]=b,intClearColor[3]=a,_gl.clearBufferiv(_gl.COLOR,0,intClearColor)}else bits|=_gl.COLOR_BUFFER_BIT}if(depth2)bits|=_gl.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0);if(stencil2)bits|=_gl.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295);if(bits!==0)_gl.clear(bits)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(nodesHandler){nodesHandler.setRenderer(this),_nodesHandler=nodesHandler},this.dispose=function(){canvas.removeEventListener("webglcontextlost",onContextLost,!1),canvas.removeEventListener("webglcontextrestored",onContextRestore,!1),canvas.removeEventListener("webglcontextcreationerror",onContextCreationError,!1),background.dispose(),renderLists.dispose(),renderStates.dispose(),properties.dispose(),environments.dispose(),objects.dispose(),bindingStates.dispose(),uniformsGroups.dispose(),programCache.dispose(),xr.dispose(),xr.removeEventListener("sessionstart",onXRSessionStart),xr.removeEventListener("sessionend",onXRSessionEnd),animation.stop()};function onContextLost(event){event.preventDefault(),log("WebGLRenderer: Context Lost."),_isContextLost=!0}function onContextRestore(){log("WebGLRenderer: Context Restored."),_isContextLost=!1;let infoAutoReset=info.autoReset,shadowMapEnabled=shadowMap.enabled,shadowMapAutoUpdate=shadowMap.autoUpdate,shadowMapNeedsUpdate=shadowMap.needsUpdate,shadowMapType=shadowMap.type;initGLContext(),info.autoReset=infoAutoReset,shadowMap.enabled=shadowMapEnabled,shadowMap.autoUpdate=shadowMapAutoUpdate,shadowMap.needsUpdate=shadowMapNeedsUpdate,shadowMap.type=shadowMapType}function onContextCreationError(event){error("WebGLRenderer: A WebGL context could not be created. Reason: ",event.statusMessage)}function onMaterialDispose(event){let material=event.target;material.removeEventListener("dispose",onMaterialDispose),deallocateMaterial(material)}function deallocateMaterial(material){releaseMaterialProgramReferences(material),properties.remove(material)}function releaseMaterialProgramReferences(material){let programs=properties.get(material).programs;if(programs!==void 0){if(programs.forEach(function(program){programCache.releaseProgram(program)}),material.isShaderMaterial)programCache.releaseShaderCache(material)}}this.renderBufferDirect=function(camera,scene,geometry,material,object,group){if(scene===null)scene=_emptyScene;let frontFaceCW=object.isMesh&&object.matrixWorld.determinant()<0,program=setProgram(camera,scene,geometry,material,object);state.setMaterial(material,frontFaceCW);let index=geometry.index,rangeFactor=1;if(material.wireframe===!0){if(index=geometries.getWireframeAttribute(geometry),index===void 0)return;rangeFactor=2}let drawRange=geometry.drawRange,position=geometry.attributes.position,drawStart=drawRange.start*rangeFactor,drawEnd=(drawRange.start+drawRange.count)*rangeFactor;if(group!==null)drawStart=Math.max(drawStart,group.start*rangeFactor),drawEnd=Math.min(drawEnd,(group.start+group.count)*rangeFactor);if(index!==null)drawStart=Math.max(drawStart,0),drawEnd=Math.min(drawEnd,index.count);else if(position!==void 0&&position!==null)drawStart=Math.max(drawStart,0),drawEnd=Math.min(drawEnd,position.count);let drawCount=drawEnd-drawStart;if(drawCount<0||drawCount===1/0)return;bindingStates.setup(object,material,program,geometry,index);let attribute,renderer=bufferRenderer;if(index!==null)attribute=attributes.get(index),renderer=indexedBufferRenderer,renderer.setIndex(attribute);if(object.isMesh)if(material.wireframe===!0)state.setLineWidth(material.wireframeLinewidth*getTargetPixelRatio()),renderer.setMode(_gl.LINES);else renderer.setMode(_gl.TRIANGLES);else if(object.isLine){let lineWidth=material.linewidth;if(lineWidth===void 0)lineWidth=1;if(state.setLineWidth(lineWidth*getTargetPixelRatio()),object.isLineSegments)renderer.setMode(_gl.LINES);else if(object.isLineLoop)renderer.setMode(_gl.LINE_LOOP);else renderer.setMode(_gl.LINE_STRIP)}else if(object.isPoints)renderer.setMode(_gl.POINTS);else if(object.isSprite)renderer.setMode(_gl.TRIANGLES);if(object.isBatchedMesh)if(!extensions.get("WEBGL_multi_draw")){let{_multiDrawStarts:starts,_multiDrawCounts:counts,_multiDrawCount:drawCount2}=object,bytesPerElement=index?attributes.get(index).bytesPerElement:1,uniforms=properties.get(material).currentProgram.getUniforms();for(let i=0;i<drawCount2;i++)uniforms.setValue(_gl,"_gl_DrawID",i),renderer.render(starts[i]/bytesPerElement,counts[i])}else renderer.renderMultiDraw(object._multiDrawStarts,object._multiDrawCounts,object._multiDrawCount);else if(object.isInstancedMesh)renderer.renderInstances(drawStart,drawCount,object.count);else if(geometry.isInstancedBufferGeometry){let maxInstanceCount=geometry._maxInstanceCount!==void 0?geometry._maxInstanceCount:1/0,instanceCount=Math.min(geometry.instanceCount,maxInstanceCount);renderer.renderInstances(drawStart,drawCount,instanceCount)}else renderer.render(drawStart,drawCount)};function prepareMaterial(material,scene,object){if(material.transparent===!0&&material.side===DoubleSide&&material.forceSinglePass===!1)material.side=BackSide,material.needsUpdate=!0,getProgram(material,scene,object),material.side=FrontSide,material.needsUpdate=!0,getProgram(material,scene,object),material.side=DoubleSide;else getProgram(material,scene,object)}this.compile=function(scene,camera,targetScene=null){if(targetScene===null)targetScene=scene;if(currentRenderState=renderStates.get(targetScene),currentRenderState.init(camera),renderStateStack.push(currentRenderState),targetScene.traverseVisible(function(object){if(object.isLight&&object.layers.test(camera.layers)){if(currentRenderState.pushLight(object),object.castShadow)currentRenderState.pushShadow(object)}}),scene!==targetScene)scene.traverseVisible(function(object){if(object.isLight&&object.layers.test(camera.layers)){if(currentRenderState.pushLight(object),object.castShadow)currentRenderState.pushShadow(object)}});currentRenderState.setupLights();let materials2=new Set;return scene.traverse(function(object){if(!(object.isMesh||object.isPoints||object.isLine||object.isSprite))return;let material=object.material;if(material)if(Array.isArray(material))for(let i=0;i<material.length;i++){let material2=material[i];prepareMaterial(material2,targetScene,object),materials2.add(material2)}else prepareMaterial(material,targetScene,object),materials2.add(material)}),currentRenderState=renderStateStack.pop(),materials2},this.compileAsync=function(scene,camera,targetScene=null){let materials2=this.compile(scene,camera,targetScene);return new Promise((resolve)=>{function checkMaterialsReady(){if(materials2.forEach(function(material){if(properties.get(material).currentProgram.isReady())materials2.delete(material)}),materials2.size===0){resolve(scene);return}setTimeout(checkMaterialsReady,10)}if(extensions.get("KHR_parallel_shader_compile")!==null)checkMaterialsReady();else setTimeout(checkMaterialsReady,10)})};let onAnimationFrameCallback=null;function onAnimationFrame(time){if(onAnimationFrameCallback)onAnimationFrameCallback(time)}function onXRSessionStart(){animation.stop()}function onXRSessionEnd(){animation.start()}let animation=new WebGLAnimation;if(animation.setAnimationLoop(onAnimationFrame),typeof self<"u")animation.setContext(self);this.setAnimationLoop=function(callback){onAnimationFrameCallback=callback,xr.setAnimationLoop(callback),callback===null?animation.stop():animation.start()},xr.addEventListener("sessionstart",onXRSessionStart),xr.addEventListener("sessionend",onXRSessionEnd),this.render=function(scene,camera){if(camera!==void 0&&camera.isCamera!==!0){error("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(_isContextLost===!0)return;if(_nodesHandler!==null)_nodesHandler.renderStart(scene,camera);let isXRPresenting=xr.enabled===!0&&xr.isPresenting===!0,useOutput=output!==null&&(_currentRenderTarget===null||isXRPresenting)&&output.begin(_this,_currentRenderTarget);if(scene.matrixWorldAutoUpdate===!0)scene.updateMatrixWorld();if(camera.parent===null&&camera.matrixWorldAutoUpdate===!0)camera.updateMatrixWorld();if(xr.enabled===!0&&xr.isPresenting===!0&&(output===null||output.isCompositing()===!1)){if(xr.cameraAutoUpdate===!0)xr.updateCamera(camera);camera=xr.getCamera()}if(scene.isScene===!0)scene.onBeforeRender(_this,scene,camera,_currentRenderTarget);if(currentRenderState=renderStates.get(scene,renderStateStack.length),currentRenderState.init(camera),currentRenderState.state.textureUnits=textures.getTextureUnits(),renderStateStack.push(currentRenderState),_projScreenMatrix2.multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse),_frustum.setFromProjectionMatrix(_projScreenMatrix2,WebGLCoordinateSystem,camera.reversedDepth),_localClippingEnabled=this.localClippingEnabled,_clippingEnabled=clipping.init(this.clippingPlanes,_localClippingEnabled),currentRenderList=renderLists.get(scene,renderListStack.length),currentRenderList.init(),renderListStack.push(currentRenderList),xr.enabled===!0&&xr.isPresenting===!0){let depthSensingMesh=_this.xr.getDepthSensingMesh();if(depthSensingMesh!==null)projectObject(depthSensingMesh,camera,-1/0,_this.sortObjects)}if(projectObject(scene,camera,0,_this.sortObjects),currentRenderList.finish(),_this.sortObjects===!0)currentRenderList.sort(_opaqueSort,_transparentSort);if(_renderBackground=xr.enabled===!1||xr.isPresenting===!1||xr.hasDepthSensing()===!1,_renderBackground)background.addToRenderList(currentRenderList,scene);if(this.info.render.frame++,_clippingEnabled===!0)clipping.beginShadows();let shadowsArray=currentRenderState.state.shadowsArray;if(shadowMap.render(shadowsArray,scene,camera),_clippingEnabled===!0)clipping.endShadows();if(this.info.autoReset===!0)this.info.reset();if((useOutput&&output.hasRenderPass())===!1){let{opaque:opaqueObjects,transmissive:transmissiveObjects}=currentRenderList;if(currentRenderState.setupLights(),camera.isArrayCamera){let cameras=camera.cameras;if(transmissiveObjects.length>0)for(let i=0,l=cameras.length;i<l;i++){let camera2=cameras[i];renderTransmissionPass(opaqueObjects,transmissiveObjects,scene,camera2)}if(_renderBackground)background.render(scene);for(let i=0,l=cameras.length;i<l;i++){let camera2=cameras[i];renderScene(currentRenderList,scene,camera2,camera2.viewport)}}else{if(transmissiveObjects.length>0)renderTransmissionPass(opaqueObjects,transmissiveObjects,scene,camera);if(_renderBackground)background.render(scene);renderScene(currentRenderList,scene,camera)}}if(_currentRenderTarget!==null&&_currentActiveMipmapLevel===0)textures.updateMultisampleRenderTarget(_currentRenderTarget),textures.updateRenderTargetMipmap(_currentRenderTarget);if(useOutput)output.end(_this);if(scene.isScene===!0)scene.onAfterRender(_this,scene,camera);if(bindingStates.resetDefaultState(),_currentMaterialId=-1,_currentCamera=null,renderStateStack.pop(),renderStateStack.length>0){if(currentRenderState=renderStateStack[renderStateStack.length-1],textures.setTextureUnits(currentRenderState.state.textureUnits),_clippingEnabled===!0)clipping.setGlobalState(_this.clippingPlanes,currentRenderState.state.camera)}else currentRenderState=null;if(renderListStack.pop(),renderListStack.length>0)currentRenderList=renderListStack[renderListStack.length-1];else currentRenderList=null;if(_nodesHandler!==null)_nodesHandler.renderEnd()};function projectObject(object,camera,groupOrder,sortObjects){if(object.visible===!1)return;if(object.layers.test(camera.layers)){if(object.isGroup)groupOrder=object.renderOrder;else if(object.isLOD){if(object.autoUpdate===!0)object.update(camera)}else if(object.isLightProbeGrid)currentRenderState.pushLightProbeGrid(object);else if(object.isLight){if(currentRenderState.pushLight(object),object.castShadow)currentRenderState.pushShadow(object)}else if(object.isSprite){if(!object.frustumCulled||_frustum.intersectsSprite(object)){if(sortObjects)_vector4.setFromMatrixPosition(object.matrixWorld).applyMatrix4(_projScreenMatrix2);let geometry=objects.update(object),material=object.material;if(material.visible)currentRenderList.push(object,geometry,material,groupOrder,_vector4.z,null)}}else if(object.isMesh||object.isLine||object.isPoints){if(!object.frustumCulled||_frustum.intersectsObject(object)){let geometry=objects.update(object),material=object.material;if(sortObjects){if(object.boundingSphere!==void 0){if(object.boundingSphere===null)object.computeBoundingSphere();_vector4.copy(object.boundingSphere.center)}else{if(geometry.boundingSphere===null)geometry.computeBoundingSphere();_vector4.copy(geometry.boundingSphere.center)}_vector4.applyMatrix4(object.matrixWorld).applyMatrix4(_projScreenMatrix2)}if(Array.isArray(material)){let groups=geometry.groups;for(let i=0,l=groups.length;i<l;i++){let group=groups[i],groupMaterial=material[group.materialIndex];if(groupMaterial&&groupMaterial.visible)currentRenderList.push(object,geometry,groupMaterial,groupOrder,_vector4.z,group)}}else if(material.visible)currentRenderList.push(object,geometry,material,groupOrder,_vector4.z,null)}}}let children=object.children;for(let i=0,l=children.length;i<l;i++)projectObject(children[i],camera,groupOrder,sortObjects)}function renderScene(currentRenderList2,scene,camera,viewport){let{opaque:opaqueObjects,transmissive:transmissiveObjects,transparent:transparentObjects}=currentRenderList2;if(currentRenderState.setupLightsView(camera),_clippingEnabled===!0)clipping.setGlobalState(_this.clippingPlanes,camera);if(viewport)state.viewport(_currentViewport.copy(viewport));if(opaqueObjects.length>0)renderObjects(opaqueObjects,scene,camera);if(transmissiveObjects.length>0)renderObjects(transmissiveObjects,scene,camera);if(transparentObjects.length>0)renderObjects(transparentObjects,scene,camera);state.buffers.depth.setTest(!0),state.buffers.depth.setMask(!0),state.buffers.color.setMask(!0),state.setPolygonOffset(!1)}function renderTransmissionPass(opaqueObjects,transmissiveObjects,scene,camera){if((scene.isScene===!0?scene.overrideMaterial:null)!==null)return;if(currentRenderState.state.transmissionRenderTarget[camera.id]===void 0){let hasHalfFloatSupport=extensions.has("EXT_color_buffer_half_float")||extensions.has("EXT_color_buffer_float");currentRenderState.state.transmissionRenderTarget[camera.id]=new WebGLRenderTarget(1,1,{generateMipmaps:!0,type:hasHalfFloatSupport?HalfFloatType:UnsignedByteType,minFilter:LinearMipmapLinearFilter,samples:Math.max(4,capabilities.samples),stencilBuffer:stencil,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:ColorManagement.workingColorSpace})}let transmissionRenderTarget=currentRenderState.state.transmissionRenderTarget[camera.id],activeViewport=camera.viewport||_currentViewport;transmissionRenderTarget.setSize(activeViewport.z*_this.transmissionResolutionScale,activeViewport.w*_this.transmissionResolutionScale);let currentRenderTarget=_this.getRenderTarget(),currentActiveCubeFace=_this.getActiveCubeFace(),currentActiveMipmapLevel=_this.getActiveMipmapLevel();if(_this.setRenderTarget(transmissionRenderTarget),_this.getClearColor(_currentClearColor),_currentClearAlpha=_this.getClearAlpha(),_currentClearAlpha<1)_this.setClearColor(16777215,0.5);if(_this.clear(),_renderBackground)background.render(scene);let currentToneMapping=_this.toneMapping;_this.toneMapping=NoToneMapping;let currentCameraViewport=camera.viewport;if(camera.viewport!==void 0)camera.viewport=void 0;if(currentRenderState.setupLightsView(camera),_clippingEnabled===!0)clipping.setGlobalState(_this.clippingPlanes,camera);if(renderObjects(opaqueObjects,scene,camera),textures.updateMultisampleRenderTarget(transmissionRenderTarget),textures.updateRenderTargetMipmap(transmissionRenderTarget),extensions.has("WEBGL_multisampled_render_to_texture")===!1){let renderTargetNeedsUpdate=!1;for(let i=0,l=transmissiveObjects.length;i<l;i++){let renderItem=transmissiveObjects[i],{object,geometry,material,group}=renderItem;if(material.side===DoubleSide&&object.layers.test(camera.layers)){let currentSide=material.side;material.side=BackSide,material.needsUpdate=!0,renderObject(object,scene,camera,geometry,material,group),material.side=currentSide,material.needsUpdate=!0,renderTargetNeedsUpdate=!0}}if(renderTargetNeedsUpdate===!0)textures.updateMultisampleRenderTarget(transmissionRenderTarget),textures.updateRenderTargetMipmap(transmissionRenderTarget)}if(_this.setRenderTarget(currentRenderTarget,currentActiveCubeFace,currentActiveMipmapLevel),_this.setClearColor(_currentClearColor,_currentClearAlpha),currentCameraViewport!==void 0)camera.viewport=currentCameraViewport;_this.toneMapping=currentToneMapping}function renderObjects(renderList,scene,camera){let overrideMaterial=scene.isScene===!0?scene.overrideMaterial:null;for(let i=0,l=renderList.length;i<l;i++){let renderItem=renderList[i],{object,geometry,group}=renderItem,material=renderItem.material;if(material.allowOverride===!0&&overrideMaterial!==null)material=overrideMaterial;if(object.layers.test(camera.layers))renderObject(object,scene,camera,geometry,material,group)}}function renderObject(object,scene,camera,geometry,material,group){if(object.onBeforeRender(_this,scene,camera,geometry,material,group),object.modelViewMatrix.multiplyMatrices(camera.matrixWorldInverse,object.matrixWorld),object.normalMatrix.getNormalMatrix(object.modelViewMatrix),material.onBeforeRender(_this,scene,camera,geometry,object,group),material.transparent===!0&&material.side===DoubleSide&&material.forceSinglePass===!1)material.side=BackSide,material.needsUpdate=!0,_this.renderBufferDirect(camera,scene,geometry,material,object,group),material.side=FrontSide,material.needsUpdate=!0,_this.renderBufferDirect(camera,scene,geometry,material,object,group),material.side=DoubleSide;else _this.renderBufferDirect(camera,scene,geometry,material,object,group);object.onAfterRender(_this,scene,camera,geometry,material,group)}function getProgram(material,scene,object){if(scene.isScene!==!0)scene=_emptyScene;let materialProperties=properties.get(material),lights=currentRenderState.state.lights,shadowsArray=currentRenderState.state.shadowsArray,lightsStateVersion=lights.state.version,parameters2=programCache.getParameters(material,lights.state,shadowsArray,scene,object,currentRenderState.state.lightProbeGridArray),programCacheKey=programCache.getProgramCacheKey(parameters2),programs=materialProperties.programs;materialProperties.environment=material.isMeshStandardMaterial||material.isMeshLambertMaterial||material.isMeshPhongMaterial?scene.environment:null,materialProperties.fog=scene.fog;let usePMREM=material.isMeshStandardMaterial||material.isMeshLambertMaterial&&!material.envMap||material.isMeshPhongMaterial&&!material.envMap;if(materialProperties.envMap=environments.get(material.envMap||materialProperties.environment,usePMREM),materialProperties.envMapRotation=materialProperties.environment!==null&&material.envMap===null?scene.environmentRotation:material.envMapRotation,programs===void 0)material.addEventListener("dispose",onMaterialDispose),programs=new Map,materialProperties.programs=programs;let program=programs.get(programCacheKey);if(program!==void 0){if(materialProperties.currentProgram===program&&materialProperties.lightsStateVersion===lightsStateVersion)return updateCommonMaterialProperties(material,parameters2),program}else{if(parameters2.uniforms=programCache.getUniforms(material),_nodesHandler!==null&&material.isNodeMaterial)_nodesHandler.build(material,object,parameters2);material.onBeforeCompile(parameters2,_this),program=programCache.acquireProgram(parameters2,programCacheKey),programs.set(programCacheKey,program),materialProperties.uniforms=parameters2.uniforms}let uniforms=materialProperties.uniforms;if(!material.isShaderMaterial&&!material.isRawShaderMaterial||material.clipping===!0)uniforms.clippingPlanes=clipping.uniform;if(updateCommonMaterialProperties(material,parameters2),materialProperties.needsLights=materialNeedsLights(material),materialProperties.lightsStateVersion=lightsStateVersion,materialProperties.needsLights)uniforms.ambientLightColor.value=lights.state.ambient,uniforms.lightProbe.value=lights.state.probe,uniforms.directionalLights.value=lights.state.directional,uniforms.directionalLightShadows.value=lights.state.directionalShadow,uniforms.spotLights.value=lights.state.spot,uniforms.spotLightShadows.value=lights.state.spotShadow,uniforms.rectAreaLights.value=lights.state.rectArea,uniforms.ltc_1.value=lights.state.rectAreaLTC1,uniforms.ltc_2.value=lights.state.rectAreaLTC2,uniforms.pointLights.value=lights.state.point,uniforms.pointLightShadows.value=lights.state.pointShadow,uniforms.hemisphereLights.value=lights.state.hemi,uniforms.directionalShadowMatrix.value=lights.state.directionalShadowMatrix,uniforms.spotLightMatrix.value=lights.state.spotLightMatrix,uniforms.spotLightMap.value=lights.state.spotLightMap,uniforms.pointShadowMatrix.value=lights.state.pointShadowMatrix;return materialProperties.lightProbeGrid=currentRenderState.state.lightProbeGridArray.length>0,materialProperties.currentProgram=program,materialProperties.uniformsList=null,program}function getUniformList(materialProperties){if(materialProperties.uniformsList===null){let progUniforms=materialProperties.currentProgram.getUniforms();materialProperties.uniformsList=WebGLUniforms.seqWithValue(progUniforms.seq,materialProperties.uniforms)}return materialProperties.uniformsList}function updateCommonMaterialProperties(material,parameters2){let materialProperties=properties.get(material);materialProperties.outputColorSpace=parameters2.outputColorSpace,materialProperties.batching=parameters2.batching,materialProperties.batchingColor=parameters2.batchingColor,materialProperties.instancing=parameters2.instancing,materialProperties.instancingColor=parameters2.instancingColor,materialProperties.instancingMorph=parameters2.instancingMorph,materialProperties.skinning=parameters2.skinning,materialProperties.morphTargets=parameters2.morphTargets,materialProperties.morphNormals=parameters2.morphNormals,materialProperties.morphColors=parameters2.morphColors,materialProperties.morphTargetsCount=parameters2.morphTargetsCount,materialProperties.numClippingPlanes=parameters2.numClippingPlanes,materialProperties.numIntersection=parameters2.numClipIntersection,materialProperties.vertexAlphas=parameters2.vertexAlphas,materialProperties.vertexTangents=parameters2.vertexTangents,materialProperties.toneMapping=parameters2.toneMapping}function findLightProbeGrid(volumes,object){if(volumes.length===0)return null;if(volumes.length===1)return volumes[0].texture!==null?volumes[0]:null;objectPosition.setFromMatrixPosition(object.matrixWorld);for(let i=0,l=volumes.length;i<l;i++){let v=volumes[i];if(v.texture!==null&&v.boundingBox.containsPoint(objectPosition))return v}return null}function setProgram(camera,scene,geometry,material,object){if(scene.isScene!==!0)scene=_emptyScene;textures.resetTextureUnits();let fog=scene.fog,environment=material.isMeshStandardMaterial||material.isMeshLambertMaterial||material.isMeshPhongMaterial?scene.environment:null,colorSpace=_currentRenderTarget===null?_this.outputColorSpace:_currentRenderTarget.isXRRenderTarget===!0?_currentRenderTarget.texture.colorSpace:ColorManagement.workingColorSpace,usePMREM=material.isMeshStandardMaterial||material.isMeshLambertMaterial&&!material.envMap||material.isMeshPhongMaterial&&!material.envMap,envMap=environments.get(material.envMap||environment,usePMREM),vertexAlphas=material.vertexColors===!0&&!!geometry.attributes.color&&geometry.attributes.color.itemSize===4,vertexTangents=!!geometry.attributes.tangent&&(!!material.normalMap||material.anisotropy>0),morphTargets=!!geometry.morphAttributes.position,morphNormals=!!geometry.morphAttributes.normal,morphColors=!!geometry.morphAttributes.color,toneMapping=NoToneMapping;if(material.toneMapped){if(_currentRenderTarget===null||_currentRenderTarget.isXRRenderTarget===!0)toneMapping=_this.toneMapping}let morphAttribute=geometry.morphAttributes.position||geometry.morphAttributes.normal||geometry.morphAttributes.color,morphTargetsCount=morphAttribute!==void 0?morphAttribute.length:0,materialProperties=properties.get(material),lights=currentRenderState.state.lights;if(_clippingEnabled===!0){if(_localClippingEnabled===!0||camera!==_currentCamera){let useCache=camera===_currentCamera&&material.id===_currentMaterialId;clipping.setState(material,camera,useCache)}}let needsProgramChange=!1;if(material.version===materialProperties.__version){if(materialProperties.needsLights&&materialProperties.lightsStateVersion!==lights.state.version)needsProgramChange=!0;else if(materialProperties.outputColorSpace!==colorSpace)needsProgramChange=!0;else if(object.isBatchedMesh&&materialProperties.batching===!1)needsProgramChange=!0;else if(!object.isBatchedMesh&&materialProperties.batching===!0)needsProgramChange=!0;else if(object.isBatchedMesh&&materialProperties.batchingColor===!0&&object.colorTexture===null)needsProgramChange=!0;else if(object.isBatchedMesh&&materialProperties.batchingColor===!1&&object.colorTexture!==null)needsProgramChange=!0;else if(object.isInstancedMesh&&materialProperties.instancing===!1)needsProgramChange=!0;else if(!object.isInstancedMesh&&materialProperties.instancing===!0)needsProgramChange=!0;else if(object.isSkinnedMesh&&materialProperties.skinning===!1)needsProgramChange=!0;else if(!object.isSkinnedMesh&&materialProperties.skinning===!0)needsProgramChange=!0;else if(object.isInstancedMesh&&materialProperties.instancingColor===!0&&object.instanceColor===null)needsProgramChange=!0;else if(object.isInstancedMesh&&materialProperties.instancingColor===!1&&object.instanceColor!==null)needsProgramChange=!0;else if(object.isInstancedMesh&&materialProperties.instancingMorph===!0&&object.morphTexture===null)needsProgramChange=!0;else if(object.isInstancedMesh&&materialProperties.instancingMorph===!1&&object.morphTexture!==null)needsProgramChange=!0;else if(materialProperties.envMap!==envMap)needsProgramChange=!0;else if(material.fog===!0&&materialProperties.fog!==fog)needsProgramChange=!0;else if(materialProperties.numClippingPlanes!==void 0&&(materialProperties.numClippingPlanes!==clipping.numPlanes||materialProperties.numIntersection!==clipping.numIntersection))needsProgramChange=!0;else if(materialProperties.vertexAlphas!==vertexAlphas)needsProgramChange=!0;else if(materialProperties.vertexTangents!==vertexTangents)needsProgramChange=!0;else if(materialProperties.morphTargets!==morphTargets)needsProgramChange=!0;else if(materialProperties.morphNormals!==morphNormals)needsProgramChange=!0;else if(materialProperties.morphColors!==morphColors)needsProgramChange=!0;else if(materialProperties.toneMapping!==toneMapping)needsProgramChange=!0;else if(materialProperties.morphTargetsCount!==morphTargetsCount)needsProgramChange=!0;else if(!!materialProperties.lightProbeGrid!==currentRenderState.state.lightProbeGridArray.length>0)needsProgramChange=!0}else needsProgramChange=!0,materialProperties.__version=material.version;let program=materialProperties.currentProgram;if(needsProgramChange===!0){if(program=getProgram(material,scene,object),_nodesHandler&&material.isNodeMaterial)_nodesHandler.onUpdateProgram(material,program,materialProperties)}let refreshProgram=!1,refreshMaterial=!1,refreshLights=!1,p_uniforms=program.getUniforms(),m_uniforms=materialProperties.uniforms;if(state.useProgram(program.program))refreshProgram=!0,refreshMaterial=!0,refreshLights=!0;if(material.id!==_currentMaterialId)_currentMaterialId=material.id,refreshMaterial=!0;if(materialProperties.needsLights){let objectVolume=findLightProbeGrid(currentRenderState.state.lightProbeGridArray,object);if(materialProperties.lightProbeGrid!==objectVolume)materialProperties.lightProbeGrid=objectVolume,refreshMaterial=!0}if(refreshProgram||_currentCamera!==camera){if(state.buffers.depth.getReversed()&&camera.reversedDepth!==!0)camera._reversedDepth=!0,camera.updateProjectionMatrix();p_uniforms.setValue(_gl,"projectionMatrix",camera.projectionMatrix),p_uniforms.setValue(_gl,"viewMatrix",camera.matrixWorldInverse);let uCamPos=p_uniforms.map.cameraPosition;if(uCamPos!==void 0)uCamPos.setValue(_gl,_vector3.setFromMatrixPosition(camera.matrixWorld));if(capabilities.logarithmicDepthBuffer)p_uniforms.setValue(_gl,"logDepthBufFC",2/(Math.log(camera.far+1)/Math.LN2));if(material.isMeshPhongMaterial||material.isMeshToonMaterial||material.isMeshLambertMaterial||material.isMeshBasicMaterial||material.isMeshStandardMaterial||material.isShaderMaterial)p_uniforms.setValue(_gl,"isOrthographic",camera.isOrthographicCamera===!0);if(_currentCamera!==camera)_currentCamera=camera,refreshMaterial=!0,refreshLights=!0}if(materialProperties.needsLights){if(lights.state.directionalShadowMap.length>0)p_uniforms.setValue(_gl,"directionalShadowMap",lights.state.directionalShadowMap,textures);if(lights.state.spotShadowMap.length>0)p_uniforms.setValue(_gl,"spotShadowMap",lights.state.spotShadowMap,textures);if(lights.state.pointShadowMap.length>0)p_uniforms.setValue(_gl,"pointShadowMap",lights.state.pointShadowMap,textures)}if(object.isSkinnedMesh){p_uniforms.setOptional(_gl,object,"bindMatrix"),p_uniforms.setOptional(_gl,object,"bindMatrixInverse");let skeleton=object.skeleton;if(skeleton){if(skeleton.boneTexture===null)skeleton.computeBoneTexture();p_uniforms.setValue(_gl,"boneTexture",skeleton.boneTexture,textures)}}if(object.isBatchedMesh){if(p_uniforms.setOptional(_gl,object,"batchingTexture"),p_uniforms.setValue(_gl,"batchingTexture",object._matricesTexture,textures),p_uniforms.setOptional(_gl,object,"batchingIdTexture"),p_uniforms.setValue(_gl,"batchingIdTexture",object._indirectTexture,textures),p_uniforms.setOptional(_gl,object,"batchingColorTexture"),object._colorsTexture!==null)p_uniforms.setValue(_gl,"batchingColorTexture",object._colorsTexture,textures)}let morphAttributes=geometry.morphAttributes;if(morphAttributes.position!==void 0||morphAttributes.normal!==void 0||morphAttributes.color!==void 0)morphtargets.update(object,geometry,program);if(refreshMaterial||materialProperties.receiveShadow!==object.receiveShadow)materialProperties.receiveShadow=object.receiveShadow,p_uniforms.setValue(_gl,"receiveShadow",object.receiveShadow);if((material.isMeshStandardMaterial||material.isMeshLambertMaterial||material.isMeshPhongMaterial)&&material.envMap===null&&scene.environment!==null)m_uniforms.envMapIntensity.value=scene.environmentIntensity;if(m_uniforms.dfgLUT!==void 0)m_uniforms.dfgLUT.value=getDFGLUT();if(refreshMaterial){if(p_uniforms.setValue(_gl,"toneMappingExposure",_this.toneMappingExposure),materialProperties.needsLights)markUniformsLightsNeedsUpdate(m_uniforms,refreshLights);if(fog&&material.fog===!0)materials.refreshFogUniforms(m_uniforms,fog);if(materials.refreshMaterialUniforms(m_uniforms,material,_pixelRatio,_height,currentRenderState.state.transmissionRenderTarget[camera.id]),materialProperties.needsLights&&materialProperties.lightProbeGrid){let volume=materialProperties.lightProbeGrid;m_uniforms.probesSH.value=volume.texture,m_uniforms.probesMin.value.copy(volume.boundingBox.min),m_uniforms.probesMax.value.copy(volume.boundingBox.max),m_uniforms.probesResolution.value.copy(volume.resolution)}WebGLUniforms.upload(_gl,getUniformList(materialProperties),m_uniforms,textures)}if(material.isShaderMaterial&&material.uniformsNeedUpdate===!0)WebGLUniforms.upload(_gl,getUniformList(materialProperties),m_uniforms,textures),material.uniformsNeedUpdate=!1;if(material.isSpriteMaterial)p_uniforms.setValue(_gl,"center",object.center);if(p_uniforms.setValue(_gl,"modelViewMatrix",object.modelViewMatrix),p_uniforms.setValue(_gl,"normalMatrix",object.normalMatrix),p_uniforms.setValue(_gl,"modelMatrix",object.matrixWorld),material.uniformsGroups!==void 0){let groups=material.uniformsGroups;for(let i=0,l=groups.length;i<l;i++){let group=groups[i];uniformsGroups.update(group,program),uniformsGroups.bind(group,program)}}return program}function markUniformsLightsNeedsUpdate(uniforms,value){uniforms.ambientLightColor.needsUpdate=value,uniforms.lightProbe.needsUpdate=value,uniforms.directionalLights.needsUpdate=value,uniforms.directionalLightShadows.needsUpdate=value,uniforms.pointLights.needsUpdate=value,uniforms.pointLightShadows.needsUpdate=value,uniforms.spotLights.needsUpdate=value,uniforms.spotLightShadows.needsUpdate=value,uniforms.rectAreaLights.needsUpdate=value,uniforms.hemisphereLights.needsUpdate=value}function materialNeedsLights(material){return material.isMeshLambertMaterial||material.isMeshToonMaterial||material.isMeshPhongMaterial||material.isMeshStandardMaterial||material.isShadowMaterial||material.isShaderMaterial&&material.lights===!0}this.getActiveCubeFace=function(){return _currentActiveCubeFace},this.getActiveMipmapLevel=function(){return _currentActiveMipmapLevel},this.getRenderTarget=function(){return _currentRenderTarget},this.setRenderTargetTextures=function(renderTarget,colorTexture,depthTexture){let renderTargetProperties=properties.get(renderTarget);if(renderTargetProperties.__autoAllocateDepthBuffer=renderTarget.resolveDepthBuffer===!1,renderTargetProperties.__autoAllocateDepthBuffer===!1)renderTargetProperties.__useRenderToTexture=!1;properties.get(renderTarget.texture).__webglTexture=colorTexture,properties.get(renderTarget.depthTexture).__webglTexture=renderTargetProperties.__autoAllocateDepthBuffer?void 0:depthTexture,renderTargetProperties.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(renderTarget,defaultFramebuffer){let renderTargetProperties=properties.get(renderTarget);renderTargetProperties.__webglFramebuffer=defaultFramebuffer,renderTargetProperties.__useDefaultFramebuffer=defaultFramebuffer===void 0};let _scratchFrameBuffer=_gl.createFramebuffer();this.setRenderTarget=function(renderTarget,activeCubeFace=0,activeMipmapLevel=0){_currentRenderTarget=renderTarget,_currentActiveCubeFace=activeCubeFace,_currentActiveMipmapLevel=activeMipmapLevel;let framebuffer=null,isCube=!1,isRenderTarget3D=!1;if(renderTarget){let renderTargetProperties=properties.get(renderTarget);if(renderTargetProperties.__useDefaultFramebuffer!==void 0){state.bindFramebuffer(_gl.FRAMEBUFFER,renderTargetProperties.__webglFramebuffer),_currentViewport.copy(renderTarget.viewport),_currentScissor.copy(renderTarget.scissor),_currentScissorTest=renderTarget.scissorTest,state.viewport(_currentViewport),state.scissor(_currentScissor),state.setScissorTest(_currentScissorTest),_currentMaterialId=-1;return}else if(renderTargetProperties.__webglFramebuffer===void 0)textures.setupRenderTarget(renderTarget);else if(renderTargetProperties.__hasExternalTextures)textures.rebindTextures(renderTarget,properties.get(renderTarget.texture).__webglTexture,properties.get(renderTarget.depthTexture).__webglTexture);else if(renderTarget.depthBuffer){let depthTexture=renderTarget.depthTexture;if(renderTargetProperties.__boundDepthTexture!==depthTexture){if(depthTexture!==null&&properties.has(depthTexture)&&(renderTarget.width!==depthTexture.image.width||renderTarget.height!==depthTexture.image.height))throw Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");textures.setupDepthRenderbuffer(renderTarget)}}let texture=renderTarget.texture;if(texture.isData3DTexture||texture.isDataArrayTexture||texture.isCompressedArrayTexture)isRenderTarget3D=!0;let __webglFramebuffer=properties.get(renderTarget).__webglFramebuffer;if(renderTarget.isWebGLCubeRenderTarget){if(Array.isArray(__webglFramebuffer[activeCubeFace]))framebuffer=__webglFramebuffer[activeCubeFace][activeMipmapLevel];else framebuffer=__webglFramebuffer[activeCubeFace];isCube=!0}else if(renderTarget.samples>0&&textures.useMultisampledRTT(renderTarget)===!1)framebuffer=properties.get(renderTarget).__webglMultisampledFramebuffer;else if(Array.isArray(__webglFramebuffer))framebuffer=__webglFramebuffer[activeMipmapLevel];else framebuffer=__webglFramebuffer;_currentViewport.copy(renderTarget.viewport),_currentScissor.copy(renderTarget.scissor),_currentScissorTest=renderTarget.scissorTest}else _currentViewport.copy(_viewport).multiplyScalar(_pixelRatio).floor(),_currentScissor.copy(_scissor).multiplyScalar(_pixelRatio).floor(),_currentScissorTest=_scissorTest;if(activeMipmapLevel!==0)framebuffer=_scratchFrameBuffer;if(state.bindFramebuffer(_gl.FRAMEBUFFER,framebuffer))state.drawBuffers(renderTarget,framebuffer);if(state.viewport(_currentViewport),state.scissor(_currentScissor),state.setScissorTest(_currentScissorTest),isCube){let textureProperties=properties.get(renderTarget.texture);_gl.framebufferTexture2D(_gl.FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,_gl.TEXTURE_CUBE_MAP_POSITIVE_X+activeCubeFace,textureProperties.__webglTexture,activeMipmapLevel)}else if(isRenderTarget3D){let layer=activeCubeFace;for(let i=0;i<renderTarget.textures.length;i++){let textureProperties=properties.get(renderTarget.textures[i]);_gl.framebufferTextureLayer(_gl.FRAMEBUFFER,_gl.COLOR_ATTACHMENT0+i,textureProperties.__webglTexture,activeMipmapLevel,layer)}}else if(renderTarget!==null&&activeMipmapLevel!==0){let textureProperties=properties.get(renderTarget.texture);_gl.framebufferTexture2D(_gl.FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,_gl.TEXTURE_2D,textureProperties.__webglTexture,activeMipmapLevel)}_currentMaterialId=-1},this.readRenderTargetPixels=function(renderTarget,x,y,width,height,buffer,activeCubeFaceIndex,textureIndex=0){if(!(renderTarget&&renderTarget.isWebGLRenderTarget)){error("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let framebuffer=properties.get(renderTarget).__webglFramebuffer;if(renderTarget.isWebGLCubeRenderTarget&&activeCubeFaceIndex!==void 0)framebuffer=framebuffer[activeCubeFaceIndex];if(framebuffer){state.bindFramebuffer(_gl.FRAMEBUFFER,framebuffer);try{let texture=renderTarget.textures[textureIndex],textureFormat=texture.format,textureType=texture.type;if(renderTarget.textures.length>1)_gl.readBuffer(_gl.COLOR_ATTACHMENT0+textureIndex);if(!capabilities.textureFormatReadable(textureFormat)){error("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!capabilities.textureTypeReadable(textureType)){error("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}if(x>=0&&x<=renderTarget.width-width&&(y>=0&&y<=renderTarget.height-height))_gl.readPixels(x,y,width,height,utils.convert(textureFormat),utils.convert(textureType),buffer)}finally{let framebuffer2=_currentRenderTarget!==null?properties.get(_currentRenderTarget).__webglFramebuffer:null;state.bindFramebuffer(_gl.FRAMEBUFFER,framebuffer2)}}},this.readRenderTargetPixelsAsync=async function(renderTarget,x,y,width,height,buffer,activeCubeFaceIndex,textureIndex=0){if(!(renderTarget&&renderTarget.isWebGLRenderTarget))throw Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let framebuffer=properties.get(renderTarget).__webglFramebuffer;if(renderTarget.isWebGLCubeRenderTarget&&activeCubeFaceIndex!==void 0)framebuffer=framebuffer[activeCubeFaceIndex];if(framebuffer)if(x>=0&&x<=renderTarget.width-width&&(y>=0&&y<=renderTarget.height-height)){state.bindFramebuffer(_gl.FRAMEBUFFER,framebuffer);let texture=renderTarget.textures[textureIndex],textureFormat=texture.format,textureType=texture.type;if(renderTarget.textures.length>1)_gl.readBuffer(_gl.COLOR_ATTACHMENT0+textureIndex);if(!capabilities.textureFormatReadable(textureFormat))throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!capabilities.textureTypeReadable(textureType))throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");let glBuffer=_gl.createBuffer();_gl.bindBuffer(_gl.PIXEL_PACK_BUFFER,glBuffer),_gl.bufferData(_gl.PIXEL_PACK_BUFFER,buffer.byteLength,_gl.STREAM_READ),_gl.readPixels(x,y,width,height,utils.convert(textureFormat),utils.convert(textureType),0);let currFramebuffer=_currentRenderTarget!==null?properties.get(_currentRenderTarget).__webglFramebuffer:null;state.bindFramebuffer(_gl.FRAMEBUFFER,currFramebuffer);let sync=_gl.fenceSync(_gl.SYNC_GPU_COMMANDS_COMPLETE,0);return _gl.flush(),await probeAsync(_gl,sync,4),_gl.bindBuffer(_gl.PIXEL_PACK_BUFFER,glBuffer),_gl.getBufferSubData(_gl.PIXEL_PACK_BUFFER,0,buffer),_gl.deleteBuffer(glBuffer),_gl.deleteSync(sync),buffer}else throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(texture,position=null,level=0){let levelScale=Math.pow(2,-level),width=Math.floor(texture.image.width*levelScale),height=Math.floor(texture.image.height*levelScale),x=position!==null?position.x:0,y=position!==null?position.y:0;textures.setTexture2D(texture,0),_gl.copyTexSubImage2D(_gl.TEXTURE_2D,level,0,0,x,y,width,height),state.unbindTexture()};let _srcFramebuffer=_gl.createFramebuffer(),_dstFramebuffer=_gl.createFramebuffer();if(this.copyTextureToTexture=function(srcTexture,dstTexture,srcRegion=null,dstPosition=null,srcLevel=0,dstLevel=0){let width,height,depth2,minX,minY,minZ,dstX,dstY,dstZ,image=srcTexture.isCompressedTexture?srcTexture.mipmaps[dstLevel]:srcTexture.image;if(srcRegion!==null)width=srcRegion.max.x-srcRegion.min.x,height=srcRegion.max.y-srcRegion.min.y,depth2=srcRegion.isBox3?srcRegion.max.z-srcRegion.min.z:1,minX=srcRegion.min.x,minY=srcRegion.min.y,minZ=srcRegion.isBox3?srcRegion.min.z:0;else{let levelScale=Math.pow(2,-srcLevel);if(width=Math.floor(image.width*levelScale),height=Math.floor(image.height*levelScale),srcTexture.isDataArrayTexture)depth2=image.depth;else if(srcTexture.isData3DTexture)depth2=Math.floor(image.depth*levelScale);else depth2=1;minX=0,minY=0,minZ=0}if(dstPosition!==null)dstX=dstPosition.x,dstY=dstPosition.y,dstZ=dstPosition.z;else dstX=0,dstY=0,dstZ=0;let glFormat=utils.convert(dstTexture.format),glType=utils.convert(dstTexture.type),glTarget;if(dstTexture.isData3DTexture)textures.setTexture3D(dstTexture,0),glTarget=_gl.TEXTURE_3D;else if(dstTexture.isDataArrayTexture||dstTexture.isCompressedArrayTexture)textures.setTexture2DArray(dstTexture,0),glTarget=_gl.TEXTURE_2D_ARRAY;else textures.setTexture2D(dstTexture,0),glTarget=_gl.TEXTURE_2D;state.activeTexture(_gl.TEXTURE0),state.pixelStorei(_gl.UNPACK_FLIP_Y_WEBGL,dstTexture.flipY),state.pixelStorei(_gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,dstTexture.premultiplyAlpha),state.pixelStorei(_gl.UNPACK_ALIGNMENT,dstTexture.unpackAlignment);let currentUnpackRowLen=state.getParameter(_gl.UNPACK_ROW_LENGTH),currentUnpackImageHeight=state.getParameter(_gl.UNPACK_IMAGE_HEIGHT),currentUnpackSkipPixels=state.getParameter(_gl.UNPACK_SKIP_PIXELS),currentUnpackSkipRows=state.getParameter(_gl.UNPACK_SKIP_ROWS),currentUnpackSkipImages=state.getParameter(_gl.UNPACK_SKIP_IMAGES);state.pixelStorei(_gl.UNPACK_ROW_LENGTH,image.width),state.pixelStorei(_gl.UNPACK_IMAGE_HEIGHT,image.height),state.pixelStorei(_gl.UNPACK_SKIP_PIXELS,minX),state.pixelStorei(_gl.UNPACK_SKIP_ROWS,minY),state.pixelStorei(_gl.UNPACK_SKIP_IMAGES,minZ);let isSrc3D=srcTexture.isDataArrayTexture||srcTexture.isData3DTexture,isDst3D=dstTexture.isDataArrayTexture||dstTexture.isData3DTexture;if(srcTexture.isDepthTexture){let srcTextureProperties=properties.get(srcTexture),dstTextureProperties=properties.get(dstTexture),srcRenderTargetProperties=properties.get(srcTextureProperties.__renderTarget),dstRenderTargetProperties=properties.get(dstTextureProperties.__renderTarget);state.bindFramebuffer(_gl.READ_FRAMEBUFFER,srcRenderTargetProperties.__webglFramebuffer),state.bindFramebuffer(_gl.DRAW_FRAMEBUFFER,dstRenderTargetProperties.__webglFramebuffer);for(let i=0;i<depth2;i++){if(isSrc3D)_gl.framebufferTextureLayer(_gl.READ_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,properties.get(srcTexture).__webglTexture,srcLevel,minZ+i),_gl.framebufferTextureLayer(_gl.DRAW_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,properties.get(dstTexture).__webglTexture,dstLevel,dstZ+i);_gl.blitFramebuffer(minX,minY,width,height,dstX,dstY,width,height,_gl.DEPTH_BUFFER_BIT,_gl.NEAREST)}state.bindFramebuffer(_gl.READ_FRAMEBUFFER,null),state.bindFramebuffer(_gl.DRAW_FRAMEBUFFER,null)}else if(srcLevel!==0||srcTexture.isRenderTargetTexture||properties.has(srcTexture)){let srcTextureProperties=properties.get(srcTexture),dstTextureProperties=properties.get(dstTexture);state.bindFramebuffer(_gl.READ_FRAMEBUFFER,_srcFramebuffer),state.bindFramebuffer(_gl.DRAW_FRAMEBUFFER,_dstFramebuffer);for(let i=0;i<depth2;i++){if(isSrc3D)_gl.framebufferTextureLayer(_gl.READ_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,srcTextureProperties.__webglTexture,srcLevel,minZ+i);else _gl.framebufferTexture2D(_gl.READ_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,_gl.TEXTURE_2D,srcTextureProperties.__webglTexture,srcLevel);if(isDst3D)_gl.framebufferTextureLayer(_gl.DRAW_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,dstTextureProperties.__webglTexture,dstLevel,dstZ+i);else _gl.framebufferTexture2D(_gl.DRAW_FRAMEBUFFER,_gl.COLOR_ATTACHMENT0,_gl.TEXTURE_2D,dstTextureProperties.__webglTexture,dstLevel);if(srcLevel!==0)_gl.blitFramebuffer(minX,minY,width,height,dstX,dstY,width,height,_gl.COLOR_BUFFER_BIT,_gl.NEAREST);else if(isDst3D)_gl.copyTexSubImage3D(glTarget,dstLevel,dstX,dstY,dstZ+i,minX,minY,width,height);else _gl.copyTexSubImage2D(glTarget,dstLevel,dstX,dstY,minX,minY,width,height)}state.bindFramebuffer(_gl.READ_FRAMEBUFFER,null),state.bindFramebuffer(_gl.DRAW_FRAMEBUFFER,null)}else if(isDst3D)if(srcTexture.isDataTexture||srcTexture.isData3DTexture)_gl.texSubImage3D(glTarget,dstLevel,dstX,dstY,dstZ,width,height,depth2,glFormat,glType,image.data);else if(dstTexture.isCompressedArrayTexture)_gl.compressedTexSubImage3D(glTarget,dstLevel,dstX,dstY,dstZ,width,height,depth2,glFormat,image.data);else _gl.texSubImage3D(glTarget,dstLevel,dstX,dstY,dstZ,width,height,depth2,glFormat,glType,image);else if(srcTexture.isDataTexture)_gl.texSubImage2D(_gl.TEXTURE_2D,dstLevel,dstX,dstY,width,height,glFormat,glType,image.data);else if(srcTexture.isCompressedTexture)_gl.compressedTexSubImage2D(_gl.TEXTURE_2D,dstLevel,dstX,dstY,image.width,image.height,glFormat,image.data);else _gl.texSubImage2D(_gl.TEXTURE_2D,dstLevel,dstX,dstY,width,height,glFormat,glType,image);if(state.pixelStorei(_gl.UNPACK_ROW_LENGTH,currentUnpackRowLen),state.pixelStorei(_gl.UNPACK_IMAGE_HEIGHT,currentUnpackImageHeight),state.pixelStorei(_gl.UNPACK_SKIP_PIXELS,currentUnpackSkipPixels),state.pixelStorei(_gl.UNPACK_SKIP_ROWS,currentUnpackSkipRows),state.pixelStorei(_gl.UNPACK_SKIP_IMAGES,currentUnpackSkipImages),dstLevel===0&&dstTexture.generateMipmaps)_gl.generateMipmap(glTarget);state.unbindTexture()},this.initRenderTarget=function(target){if(properties.get(target).__webglFramebuffer===void 0)textures.setupRenderTarget(target)},this.initTexture=function(texture){if(texture.isCubeTexture)textures.setTextureCube(texture,0);else if(texture.isData3DTexture)textures.setTexture3D(texture,0);else if(texture.isDataArrayTexture||texture.isCompressedArrayTexture)textures.setTexture2DArray(texture,0);else textures.setTexture2D(texture,0);state.unbindTexture()},this.resetState=function(){_currentActiveCubeFace=0,_currentActiveMipmapLevel=0,_currentRenderTarget=null,state.reset(),bindingStates.reset()},typeof __THREE_DEVTOOLS__<"u")__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return WebGLCoordinateSystem}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(colorSpace){this._outputColorSpace=colorSpace;let gl=this.getContext();gl.drawingBufferColorSpace=ColorManagement._getDrawingBufferColorSpace(colorSpace),gl.unpackColorSpace=ColorManagement._getUnpackColorSpace()}}
export{ShaderChunk,UniformsLib,WebGLRenderer,exports_three_module};
