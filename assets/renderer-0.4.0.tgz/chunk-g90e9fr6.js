async function drainGpu(renderer){let device=renderer?.backend?.device;if(device)await device.queue.onSubmittedWorkDone().catch(()=>{})}
export{drainGpu};
