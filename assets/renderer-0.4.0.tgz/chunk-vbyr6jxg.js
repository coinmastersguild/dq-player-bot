import{acquireNativePreviewLifetime,waitForNativePreviewRetirement}from"./chunk-qjrbm67z.js";import"./chunk-7jhxxf1p.js";export{waitForNativePreviewRetirement,acquireNativePreviewLifetime};
