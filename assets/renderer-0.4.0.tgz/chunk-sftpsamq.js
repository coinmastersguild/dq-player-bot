import{MIRA_EYE_GEOMETRY,createHalflingFemaleEyeGeometry}from"./chunk-eznkp1x9.js";import"./chunk-7jhxxf1p.js";export{createHalflingFemaleEyeGeometry,MIRA_EYE_GEOMETRY};
