var HALFLING_FEMALE_EYE_SURFACE=Object.freeze({irisRadius:0.43,pupilFraction:0.4,irisCenter:Object.freeze([0,0.045]),sourceColor:"#634529",scleraColor:"#d7d2c5"});function createHalflingFemaleEyeMaterial(source,{THREE}={}){if(!source?.isMaterial||source.name!=="HalflingFemale Eyes Runtime"||!THREE?.Color)throw Error("Mira eye surface requires the appearance-cloned HalflingFemale material and THREE.");let sourceKey=source.customProgramCacheKey.call(source);if(!sourceKey.includes("|dq-halfling-appearance-v1-iris"))throw Error("Create Mira eye surface after Halfling appearance.");let material=source.clone();material.name="Mira Authored Eyes",material.defines={...source.defines},material.roughness=0.26,material.metalness=0,material.transparent=!1,material.opacity=1,material.alphaTest=0,material.userData={...source.userData,miraEyeSurface:!0,sourceMaterialName:source.name,sourceResourcesOwned:!1};let uniforms={dqMiraEyeSourceColor:{value:new THREE.Color(HALFLING_FEMALE_EYE_SURFACE.sourceColor)},dqMiraEyeScleraColor:{value:new THREE.Color(HALFLING_FEMALE_EYE_SURFACE.scleraColor)}};return material.onBeforeCompile=function(shader,renderer){if(source.onBeforeCompile.call(this,shader,renderer),!shader.uniforms.dqHalflingColor||!shader.uniforms.dqHalflingAmount)throw Error("Missing live Mira eye color uniforms.");if(!shader.vertexShader.includes("#include <begin_vertex>")||!shader.fragmentShader.includes("#include <alphatest_fragment>"))throw Error("Unsupported Mira eye shader anchors.");Object.assign(shader.uniforms,uniforms),shader.vertexShader=`attribute vec3 dqMiraEyeCoord;
varying vec3 vDQMiraEyeCoord;
`+shader.vertexShader.replace("#include <begin_vertex>",`vDQMiraEyeCoord=dqMiraEyeCoord;
#include <begin_vertex>`),shader.fragmentShader=`
varying vec3 vDQMiraEyeCoord;
uniform vec3 dqMiraEyeSourceColor;
uniform vec3 dqMiraEyeScleraColor;
`+shader.fragmentShader.replace("#include <alphatest_fragment>",`#include <alphatest_fragment>

// Coordinates belong to each neutral sphere and follow its skin/morph geometry.
vec3 dqMiraEyeP=normalize(vDQMiraEyeCoord);
vec2 dqMiraIrisCoord=dqMiraEyeP.xy-vec2(0.0,0.045);
float dqMiraEyeR=length(dqMiraIrisCoord);
float dqMiraEyeAngle=atan(dqMiraIrisCoord.y,dqMiraIrisCoord.x+0.0000001);
float dqMiraEyeAA=max(fwidth(dqMiraEyeR),0.001);
float dqMiraIrisR=dqMiraEyeR/0.43;
float dqMiraFront=smoothstep(0.15,0.35,dqMiraEyeP.z);
float dqMiraIrisMask=(1.0-smoothstep(0.43-dqMiraEyeAA,0.43+dqMiraEyeAA,dqMiraEyeR))*dqMiraFront;
float dqMiraPupilMask=(1.0-smoothstep(0.172-dqMiraEyeAA,0.172+dqMiraEyeAA,dqMiraEyeR))*dqMiraFront;
vec3 dqMiraIrisColor=mix(dqMiraEyeSourceColor,dqHalflingColor,dqHalflingAmount);
// Fine radial variation and a soft collarette keep the iris detailed at close
// range without retaining the source atlas's tiny angular color islands.
float dqMiraFibers=0.5+0.5*sin(dqMiraEyeAngle*43.0+sin(dqMiraEyeAngle*13.0)*2.7+dqMiraIrisR*25.0);
float dqMiraFine=0.5+0.5*sin(dqMiraEyeAngle*157.0+dqMiraIrisR*79.0+sin(dqMiraEyeAngle*29.0));
float dqMiraFiberFade=smoothstep(0.39,0.54,dqMiraIrisR)*(1.0-smoothstep(0.86,0.99,dqMiraIrisR));
float dqMiraCollarette=exp(-pow((dqMiraIrisR-0.53-0.025*sin(dqMiraEyeAngle*17.0))/0.065,2.0));
float dqMiraDetail=0.82+dqMiraFiberFade*(0.36*dqMiraFibers+0.12*dqMiraFine)+0.12*dqMiraCollarette;
float dqMiraLimbal=1.0-0.72*smoothstep(0.84,0.985,dqMiraIrisR);
vec3 dqMiraIris=dqMiraIrisColor*dqMiraDetail*dqMiraLimbal;
// The globe stays off-white. Very faint broad variation avoids flat paper-white
// wedges; no baked shadow, vein line, or makeup is projected onto the sclera.
float dqMiraScleraDetail=1.0-0.035*abs(dqMiraEyeP.x)-0.025*(1.0-max(dqMiraEyeP.z,0.0));
vec3 dqMiraSurface=dqMiraEyeScleraColor*dqMiraScleraDetail;
dqMiraSurface=mix(dqMiraSurface,dqMiraIris,dqMiraIrisMask);
dqMiraSurface=mix(dqMiraSurface,vec3(0.0025,0.0022,0.0018),dqMiraPupilMask);
// One restrained corneal catchlight; scene lighting provides the main specular.
float dqMiraCatchlight=exp(-dot(dqMiraEyeP.xy-vec2(-0.14,0.17),dqMiraEyeP.xy-vec2(-0.14,0.17))/0.00055)*dqMiraFront;
diffuseColor.rgb=mix(dqMiraSurface,vec3(0.82,0.82,0.77),0.28*dqMiraCatchlight);
`)},material.customProgramCacheKey=()=>sourceKey+"|dq-mira-eye-procedural-v1",material.needsUpdate=!0,material}
export{HALFLING_FEMALE_EYE_SURFACE,createHalflingFemaleEyeMaterial};
