import{createHairPhysics}from"./chunk-q5d0dqmv.js";import"./chunk-nrf8bzw3.js";import"./chunk-pz7tgqgm.js";import"./chunk-7jhxxf1p.js";export{createHairPhysics};
