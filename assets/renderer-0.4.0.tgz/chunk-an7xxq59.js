import{DEFAULT_APPEARANCE,validateAppearance}from"./chunk-c8spxrqh.js";function appearanceMaterialRole(name=""){let plain=name.replace(/^DQ_PBR_/,"").replace(/\.\d+(?=__RESTORE|$)/,"").replace(/__RESTORE$/,"");if(/^HumanFemale (Torso|Face|Legs|Arms|Genitals)$/.test(plain))return"skin";if(/^HumanFemale Irises$/.test(plain))return"iris";if(/(?:^|[ _])Hair[ _](?:Loose|Short)(?:[ _-]|$)/i.test(plain)||/^EyeBrows(?:-|$)/i.test(plain))return"hair";return null}var GLSL=`
uniform float dqAppearanceAmount;
uniform vec3 dqAppearanceColor;
vec3 dqRecolorAppearance(vec3 sourceColor) {
#if DQ_APPEARANCE_ROLE == 1
  // A ratio in linear light preserves skin texture, freckles and lip color differences.
  return sourceColor * dqAppearanceColor;
#else
  float luminance=dot(max(sourceColor,vec3(0.0)),vec3(0.2126,0.7152,0.0722));
#if DQ_APPEARANCE_ROLE == 2
  // Lift a black source albedo before recoloring so blond/silver can actually exist.
  float detail=clamp(pow(luminance,0.38)*4.5,0.12,1.45);
#else
  float detail=clamp(pow(luminance,0.45)*3.2,0.12,1.5);
#endif
  return dqAppearanceColor * detail;
#endif
}
`;function createAppearanceController(root,{THREE}={}){if(!THREE?.Color)throw Error("Appearance controller requires THREE.Color.");let current={...DEFAULT_APPEARANCE},registered=new Map,baselineSkin=new THREE.Color(DEFAULT_APPEARANCE.skinTone),disposed=!1;function update(record){let field={skin:"skinTone",hair:"hairColor",iris:"irisColor"}[record.role];record.uniforms.dqAppearanceAmount.value=current[field]===DEFAULT_APPEARANCE[field]?0:1;let color=record.uniforms.dqAppearanceColor.value;if(color.set(current[field]),record.role==="skin")color.r/=baselineSkin.r,color.g/=baselineSkin.g,color.b/=baselineSkin.b}function register(object){if(disposed)throw Error("Appearance controller has been disposed.");return object?.traverse((node)=>{if(!node.isMesh)return;for(let material of Array.isArray(node.material)?node.material:[node.material]){if(!material||registered.has(material))continue;let role=appearanceMaterialRole(material.name);if(!role)continue;let{onBeforeCompile:originalCompile,customProgramCacheKey:originalKey,defines:originalDefines}=material,previousKey=originalKey.call(material),uniforms={dqAppearanceAmount:{value:0},dqAppearanceColor:{value:new THREE.Color}};material.defines={...material.defines,DQ_APPEARANCE_ROLE:{skin:1,hair:2,iris:3}[role]},material.onBeforeCompile=function(shader,renderer){if(originalCompile.call(this,shader,renderer),!shader.fragmentShader.includes("#include <map_fragment>"))throw Error("Unsupported appearance shader for "+material.name);Object.assign(shader.uniforms,uniforms),shader.fragmentShader=GLSL+`
`+shader.fragmentShader.replace("#include <map_fragment>",`#include <map_fragment>
diffuseColor.rgb = mix(diffuseColor.rgb, dqRecolorAppearance(diffuseColor.rgb), dqAppearanceAmount);`)},material.customProgramCacheKey=()=>previousKey+"|dq-appearance-v1-"+role,material.needsUpdate=!0;let record={role,uniforms,originalCompile,originalKey,originalDefines};registered.set(material,record),update(record)}}),registered.size}function set(value){if(disposed)throw Error("Appearance controller has been disposed.");current=validateAppearance(value);for(let record of registered.values())update(record);return{...current}}function dispose(){if(disposed)return;for(let[material,record]of registered)material.onBeforeCompile=record.originalCompile,material.customProgramCacheKey=record.originalKey,material.defines=record.originalDefines,material.needsUpdate=!0;registered.clear(),disposed=!0}return register(root),{set,register,state:()=>({...current}),dispose}}
export{appearanceMaterialRole,createAppearanceController};
