import{MORPH_WORKSHOP_CONFIGS,getMorphWorkshopFace}from"./chunk-4nhqbetj.js";import"./chunk-7jhxxf1p.js";export{getMorphWorkshopFace,MORPH_WORKSHOP_CONFIGS};
