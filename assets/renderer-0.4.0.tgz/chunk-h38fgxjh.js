var proofs=new WeakMap;function rememberZeroMorph(attribute){proofs.set(attribute,{array:new WeakRef(attribute.array),version:attribute.version??0})}function knownZeroMorph(attribute){let proof=proofs.get(attribute);return!!proof&&attribute.dqMutableMorph!==!0&&attribute.array===proof.array.deref()&&(attribute.version??0)===proof.version}
export{rememberZeroMorph,knownZeroMorph};
