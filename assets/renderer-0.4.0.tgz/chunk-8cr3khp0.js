import{createFaceIdentityController}from"./chunk-3z96vwcv.js";import"./chunk-7jhxxf1p.js";export{createFaceIdentityController};
