import{HALFLING_FEMALE_EYE_SURFACE,createHalflingFemaleEyeMaterial}from"./chunk-vv6q8tr9.js";import"./chunk-7jhxxf1p.js";export{createHalflingFemaleEyeMaterial,HALFLING_FEMALE_EYE_SURFACE};
