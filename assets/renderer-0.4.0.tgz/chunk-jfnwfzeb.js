function goldRelative(directory,path){if(typeof path!=="string"||!path||path.includes("\\")||path.includes("?")||path.includes("#"))throw Error("Invalid Gold dependency path");let url=new URL(path,"https://title.invalid/"+directory);if(url.origin!=="https://title.invalid")throw Error("External Gold dependency rejected");return decodeURIComponent(url.pathname.slice(1))}
export{goldRelative};
