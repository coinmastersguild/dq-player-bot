var MAX_SKIN_DECALS=8,DEFAULT_SKIN_MARKINGS=Object.freeze({mode:"clean",tattoos:Object.freeze({enabled:!1,colorMode:"source",color:"#30292e",opacity:1}),scars:Object.freeze({enabled:!1,opacity:1,relief:1}),decals:Object.freeze([])}),clone=(value)=>JSON.parse(JSON.stringify(value)),FIELDS=["cleanColor","cleanNormal","sourceColor","sourceNormal","tattooMask","scarMask"],DESIGNS=["rune","bands","slash","cross"],own=(o,key)=>Object.prototype.hasOwnProperty.call(o,key);function object(value,label){if(!value||typeof value!=="object"||Array.isArray(value))throw Error(label+" must be an object.");return value}function keys(value,allowed,label){for(let key of Object.keys(value))if(!allowed.includes(key))throw Error("Unknown "+label+" setting: "+key)}function number(value,min,max,label){if(typeof value!=="number"||!Number.isFinite(value)||value<min||value>max)throw Error("Invalid "+label+".");return value}function color(value,label){if(typeof value!=="string"||!/^#[0-9a-f]{6}$/i.test(value))throw Error(label+" must be a six-digit hex color.");return value.toLowerCase()}function vector(value,label){if(!Array.isArray(value)||value.length!==3)throw Error(label+" must contain three numbers.");return Array.from(value,(v)=>number(v,-1e4,1e4,label))}function flag(value,label){if(typeof value!=="boolean")throw Error(label+" must be boolean.");return value}function validateSkinMarkings(input,previous=DEFAULT_SKIN_MARKINGS){object(input,"Skin markings"),keys(input,["mode","tattoos","scars","decals"],"skin");let next=clone(previous);if(own(input,"mode")){if(!["clean","original"].includes(input.mode))throw Error("Skin mode must be clean or original.");next.mode=input.mode}for(let group of["tattoos","scars"])if(own(input,group)){let value=object(input[group],group);if(keys(value,group==="tattoos"?["enabled","colorMode","color","opacity"]:["enabled","opacity","relief"],group),own(value,"enabled"))next[group].enabled=flag(value.enabled,group+" enabled");if(own(value,"opacity"))next[group].opacity=number(value.opacity,0,1,group+" opacity");if(group==="scars"&&own(value,"relief"))next.scars.relief=number(value.relief,0,1,"scar relief");if(group==="tattoos"){if(own(value,"colorMode")){if(!["source","tint"].includes(value.colorMode))throw Error("Tattoo color mode must be source or tint.");next.tattoos.colorMode=value.colorMode}if(own(value,"color"))next.tattoos.color=color(value.color,"Tattoo color")}}if(own(input,"decals")){if(!Array.isArray(input.decals)||input.decals.length>8)throw Error("Use at most 8 skin decals.");let ids=new Set;next.decals=Array.from(input.decals,(value)=>{if(object(value,"Decal"),keys(value,["id","type","design","position","normal","size","rotation","color","opacity","relief"],"decal"),typeof value.id!=="string"||!/^[a-z0-9][a-z0-9._-]{0,63}$/i.test(value.id)||ids.has(value.id))throw Error("Decal IDs must be unique stable identifiers.");if(ids.add(value.id),!["tattoo","scar"].includes(value.type))throw Error("Invalid decal type.");if(!DESIGNS.includes(value.design))throw Error("Invalid decal design.");let normal=vector(value.normal,"Decal normal"),length=Math.hypot(...normal);if(length<0.000001)throw Error("Decal normal cannot be zero.");return{id:value.id,type:value.type,design:value.design,position:vector(value.position,"Decal position"),normal:Math.abs(length-1)>0.000000000001?normal.map((v)=>v/length):normal,size:number(value.size,0.005,0.25,"decal size"),rotation:number(value.rotation,-180,180,"decal rotation"),color:color(value.color,"Decal color"),opacity:number(value.opacity,0,1,"decal opacity"),relief:number(value.relief,0,1,"decal relief")}})}return next}var VARYINGS=`
varying vec3 vDQMarkPosition;
varying vec3 vDQMarkNormal;
`,FRAGMENT=`
uniform float dqSkinActive;
uniform sampler2D dqSkinSourceColor;
uniform sampler2D dqSkinSourceNormal;
uniform sampler2D dqSkinTattooMask;
uniform sampler2D dqSkinScarMask;
uniform float dqSkinTattooAmount;
uniform float dqSkinTattooTint;
uniform vec3 dqSkinTattooColor;
uniform float dqSkinScarAmount;
uniform float dqSkinScarRelief;
uniform int dqSkinDecalCount;
uniform int dqSkinDecalType[8];
uniform int dqSkinDecalDesign[8];
uniform vec3 dqSkinDecalPosition[8];
uniform vec3 dqSkinDecalNormal[8];
uniform vec3 dqSkinDecalColor[8];
uniform vec4 dqSkinDecalParams[8];
uniform float dqSkinHasDecalRelief;

float dqSkinSegment(vec2 p, vec2 a, vec2 b) {
  vec2 ab=b-a;
  return length(p-a-ab*clamp(dot(p-a,ab)/max(dot(ab,ab),0.000001),0.0,1.0));
}
float dqSkinStamp(vec2 p, int design) {
  float distanceToInk;
  float width=0.037;
  if(design==0) {
    // Original simple angular rune: staff with two pairs of branches.
    distanceToInk=dqSkinSegment(p,vec2(0.0,-0.39),vec2(0.0,0.39));
    distanceToInk=min(distanceToInk,dqSkinSegment(p,vec2(0.0,0.05),vec2(0.28,0.3)));
    distanceToInk=min(distanceToInk,dqSkinSegment(p,vec2(0.0,0.05),vec2(-0.28,0.3)));
    distanceToInk=min(distanceToInk,dqSkinSegment(p,vec2(0.0,-0.22),vec2(0.23,-0.03)));
    distanceToInk=min(distanceToInk,dqSkinSegment(p,vec2(0.0,-0.22),vec2(-0.23,-0.03)));
  } else if(design==1) {
    distanceToInk=min(dqSkinSegment(p,vec2(-0.36,-0.24),vec2(0.36,-0.24)),
      min(dqSkinSegment(p,vec2(-0.36,0.0),vec2(0.36,0.0)),
      dqSkinSegment(p,vec2(-0.36,0.24),vec2(0.36,0.24))));
    width=0.055;
  } else {
    distanceToInk=dqSkinSegment(p,vec2(-0.2,-0.39),vec2(0.2,0.39));
    if(design==3)distanceToInk=min(distanceToInk,dqSkinSegment(p,vec2(-0.27,0.27),vec2(0.27,-0.27)));
    // A tapered edge prevents scar ends from reading as square stickers.
    width=0.014+0.024*clamp(1.0-abs(p.y)/0.43,0.0,1.0);
  }
  float antialias=max(fwidth(distanceToInk),0.003);
  return 1.0-smoothstep(width-antialias,width+antialias,distanceToInk);
}
float dqSkinDecalMask(int index) {
  vec3 anchorNormal=dqSkinDecalNormal[index];
  vec3 tangent=normalize(cross(abs(anchorNormal.y)<0.95?vec3(0.0,1.0,0.0):vec3(1.0,0.0,0.0),anchorNormal));
  vec3 bitangent=cross(anchorNormal,tangent);
  vec3 delta=vDQMarkPosition-dqSkinDecalPosition[index];
  float size=dqSkinDecalParams[index].x;
  vec2 p=vec2(dot(delta,tangent),dot(delta,bitangent))/size;
  float angle=dqSkinDecalParams[index].y;
  float c=cos(angle),s=sin(angle);
  p=mat2(c,-s,s,c)*p;
  float facing=smoothstep(0.25,0.65,dot(normalize(vDQMarkNormal),anchorNormal));
  float depth=1.0-smoothstep(size*0.12,size*0.35,abs(dot(delta,anchorNormal)));
  float bounds=1.0-smoothstep(0.49,0.53,max(abs(p.x),abs(p.y)));
  return dqSkinStamp(p,dqSkinDecalDesign[index])*facing*depth*bounds;
}
vec3 dqSkinPerturbNormal(vec3 surfacePosition, vec3 surfaceNormal, vec2 heightDerivative) {
  // Evaluate derivatives before branching. Degenerate/grazing fragments keep
  // their existing normal instead of normalizing a zero vector.
  vec3 sigmaX=dFdx(surfacePosition),sigmaY=dFdy(surfacePosition);
  vec3 r1=cross(sigmaY,surfaceNormal),r2=cross(surfaceNormal,sigmaX);
  float determinant=dot(sigmaX,r1);
  if(abs(determinant)<0.0000000001 || dot(heightDerivative,heightDerivative)==0.0)return surfaceNormal;
  vec3 gradient=sign(determinant)*(heightDerivative.x*r1+heightDerivative.y*r2);
  vec3 bumped=abs(determinant)*surfaceNormal-gradient;
  float magnitude=dot(bumped,bumped);
  return magnitude>0.000000000000000001?bumped*inversesqrt(magnitude):surfaceNormal;
}
`,COLOR_FRAGMENT=`
vec3 dqSkinUntintedBase=diffuseColor.rgb;
// DQ_SKIN_BASE_COLOR_TRANSFORM
if(dqSkinActive>0.5) {
  vec3 cleanSkin=dqSkinUntintedBase;
  vec3 sourceSkin=texture2D(dqSkinSourceColor,vMapUv).rgb*diffuse;
  #if defined(USE_COLOR_ALPHA)
    sourceSkin*=vColor.rgb;
  #elif defined(USE_COLOR)
    sourceSkin*=vColor;
  #endif
  float scarMask=texture2D(dqSkinScarMask,vMapUv).r;
  float tattooMask=texture2D(dqSkinTattooMask,vMapUv).r;
  diffuseColor.rgb=mix(diffuseColor.rgb,sourceSkin,scarMask*dqSkinScarAmount);
  float detail=clamp(dot(cleanSkin,vec3(0.2126,0.7152,0.0722))/0.35,0.12,1.5);
  vec3 tattooColor=mix(sourceSkin,dqSkinTattooColor*detail,dqSkinTattooTint);
  diffuseColor.rgb=mix(diffuseColor.rgb,tattooColor,tattooMask*dqSkinTattooAmount);
  for(int i=0;i<8;i++) {
    if(i>=dqSkinDecalCount)break;
    float amount=dqSkinDecalMask(i)*dqSkinDecalParams[i].z;
    diffuseColor.rgb=mix(diffuseColor.rgb,dqSkinDecalColor[i]*detail,amount);
  }
}
`,SOURCE_NORMAL=`
if(dqSkinActive>0.5) {
  float scarNormalAmount=texture2D(dqSkinScarMask,vMapUv).r*dqSkinScarRelief;
  vec3 sourceNormal=texture2D(dqSkinSourceNormal,vNormalMapUv).xyz*2.0-1.0;
  sourceNormal.xy*=normalScale;
  if(scarNormalAmount>0.0) {
    vec3 blendedNormal=mix(mapN,sourceNormal,scarNormalAmount);
    float magnitude=dot(blendedNormal,blendedNormal);
    if(magnitude>0.00000001)mapN=blendedNormal*inversesqrt(magnitude);
  }
}
`,DECAL_NORMAL=`
if(dqSkinActive>0.5 && dqSkinHasDecalRelief>0.5) {
  float height=0.0;
  for(int i=0;i<8;i++) {
    if(i>=dqSkinDecalCount)break;
    if(dqSkinDecalType[i]==1) {
      float amplitude=min(dqSkinDecalParams[i].x*0.02,0.0015);
      height+=dqSkinDecalMask(i)*amplitude*dqSkinDecalParams[i].z*dqSkinDecalParams[i].w;
    }
  }
  vec2 heightDerivative=vec2(dFdx(height),dFdy(height));
  normal=dqSkinPerturbNormal(-vViewPosition,normal,heightDerivative);
}
`;function snapshot(material){return{map:material.map,normalMap:material.normalMap,color:material.color?.getHexString(),alphaTest:material.alphaTest,opacity:material.opacity,transparent:material.transparent,side:material.side,normalScale:material.normalScale?.toArray(),roughness:material.roughness,compile:material.onBeforeCompile,key:material.customProgramCacheKey,defines:material.defines}}function unchanged(material,baseline){let current=snapshot(material);return Object.keys(baseline).every((key)=>key==="normalScale"?JSON.stringify(current[key])===JSON.stringify(baseline[key]):current[key]===baseline[key])}function createSkinMarkings(root,{THREE,library,textures}={}){if(!root?.traverse||!THREE?.Color||!THREE?.ShaderChunk)throw Error("Skin markings require a root and THREE.");if(object(library,"Skin library"),typeof library.id!=="string"||!library.id||typeof library.modelSha256!=="string"||!/^[a-f0-9]{64}$/i.test(library.modelSha256))throw Error("Skin library must identify its model revision.");if(!Array.isArray(library.materials)||!library.materials.length)throw Error("Skin library has no material bindings.");let definitions=new Map,resolved=new Map,records=new Map,bindings=[],textureFor=(id)=>textures instanceof Map?textures.get(id):textures?.[id];for(let entry of library.materials){if(object(entry,"Skin material"),typeof entry.name!=="string"||!entry.name||definitions.has(entry.name))throw Error("Skin material names must be explicit and unique.");definitions.set(entry.name,entry);let maps={};for(let field of FIELDS){if(field.endsWith("Normal")&&entry.cleanNormal===null&&entry.sourceNormal===null){maps[field]=null;continue}if(typeof entry[field]!=="string"||!textureFor(entry[field])?.isTexture)throw Error("Missing "+field+" texture for "+entry.name);maps[field]=textureFor(entry[field])}resolved.set(entry.name,maps)}let found=new Set;root.traverse((node)=>{if(!node.isMesh)return;let materials=[].concat(node.material),matches=materials.filter((m)=>definitions.has(m?.name));if(!matches.length)return;if(node.geometry?.getAttribute("position")?.itemSize!==3||node.geometry?.getAttribute("normal")?.itemSize!==3)throw Error("Skin mesh requires position and normal attributes: "+node.name);bindings.push({node,original:node.material});for(let source of matches){found.add(source.name);let needsNormal=resolved.get(source.name).sourceNormal!==null;if(!source.map?.isTexture||needsNormal&&(!source.normalMap?.isTexture||source.normalMapType!==THREE.TangentSpaceNormalMap)||!needsNormal&&source.normalMap)throw Error("Skin material needs source color and matching tangent-space normal maps: "+source.name);for(let map of[source.map,source.normalMap].filter(Boolean)){let channel=map.channel;if(!Number.isInteger(channel)||channel<0||channel>3)throw Error("Unsupported skin UV channel: "+source.name);let attribute=channel===0?"uv":"uv"+channel;if(node.geometry.getAttribute(attribute)?.itemSize!==2)throw Error("Skin mesh is missing "+attribute+": "+node.name)}if(records.has(source))continue;records.set(source,{source,baseline:snapshot(source),entry:definitions.get(source.name),input:resolved.get(source.name)})}});for(let name of definitions.keys())if(!found.has(name))throw Error("Missing skin material: "+name);let normalChunk=THREE.ShaderChunk.normal_fragment_maps;if(typeof normalChunk!=="string"||!normalChunk.includes("mapN.xy *= normalScale;"))throw Error("Unsupported Three.js normal shader.");let extendedNormal=normalChunk.replace("mapN.xy *= normalScale;",`mapN.xy *= normalScale;
`+SOURCE_NORMAL),current=clone(DEFAULT_SKIN_MARKINGS),disposed=!1;for(let record of records.values()){let{source,input}=record,material=source.clone(),maps={};record.material=material,record.maps=maps;for(let field of FIELDS){if(input[field]===null){maps[field]=null;continue}let normal=field.endsWith("Normal"),mask=field.endsWith("Mask"),map=(normal?source.normalMap:source.map).clone();if(map.source=input[field].source,normal||mask)map.colorSpace=THREE.NoColorSpace;map.needsUpdate=!0,maps[field]=map}let uniforms={dqSkinActive:{value:1},dqSkinSourceColor:{value:maps.sourceColor},dqSkinSourceNormal:{value:maps.sourceNormal},dqSkinTattooMask:{value:maps.tattooMask},dqSkinScarMask:{value:maps.scarMask},dqSkinTattooAmount:{value:0},dqSkinTattooTint:{value:0},dqSkinTattooColor:{value:new THREE.Color},dqSkinScarAmount:{value:0},dqSkinScarRelief:{value:0},dqSkinDecalCount:{value:0},dqSkinDecalType:{value:new Int32Array(8)},dqSkinDecalDesign:{value:new Int32Array(8)},dqSkinDecalPosition:{value:Array.from({length:8},()=>new THREE.Vector3)},dqSkinDecalNormal:{value:Array.from({length:8},()=>new THREE.Vector3(0,0,1))},dqSkinDecalColor:{value:Array.from({length:8},()=>new THREE.Color)},dqSkinDecalParams:{value:Array.from({length:8},()=>new THREE.Vector4(0.1,0,0,0))},dqSkinHasDecalRelief:{value:0}};record.uniforms=uniforms;let originalCompile=source.onBeforeCompile,previousKey=source.customProgramCacheKey.call(source);material.onBeforeCompile=function(shader,renderer){if(originalCompile.call(this,shader,renderer),!shader.vertexShader.includes("#include <begin_vertex>")||!shader.fragmentShader.includes("#include <color_fragment>")||!shader.fragmentShader.includes("#include <normal_fragment_maps>"))throw Error("Unsupported skin-markings shader for "+source.name);Object.assign(shader.uniforms,uniforms),shader.vertexShader=VARYINGS+`
`+shader.vertexShader.replace("#include <begin_vertex>",`vDQMarkPosition = ( modelMatrix * vec4( position, 1.0 ) ).xyz;
vDQMarkNormal = normalize( mat3( modelMatrix ) * normal );
#include <begin_vertex>`),shader.fragmentShader=VARYINGS+`
`+FRAGMENT+`
`+shader.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
`+COLOR_FRAGMENT).replace("#include <normal_fragment_maps>",extendedNormal+`
`+DECAL_NORMAL)},material.customProgramCacheKey=()=>previousKey+"|dq-skin-markings-v1",material.needsUpdate=!0}for(let{node,original}of bindings){let mapped=[].concat(original).map((material)=>records.get(material)?.material??material);node.material=Array.isArray(original)?mapped:mapped[0]}function update(){for(let record of records.values()){let{material,maps,source,uniforms:u}=record,active=current.mode==="clean",map=active?maps.cleanColor:source.map,normalMap=active?maps.cleanNormal:source.normalMap;if(material.map!==map||material.normalMap!==normalMap)material.map=map,material.normalMap=normalMap,material.needsUpdate=!0;u.dqSkinActive.value=active?1:0,u.dqSkinTattooAmount.value=active&&current.tattoos.enabled?current.tattoos.opacity:0,u.dqSkinTattooTint.value=current.tattoos.colorMode==="tint"?1:0,u.dqSkinTattooColor.value.set(current.tattoos.color),u.dqSkinScarAmount.value=active&&current.scars.enabled?current.scars.opacity:0,u.dqSkinScarRelief.value=active&&current.scars.enabled?current.scars.relief:0,u.dqSkinDecalCount.value=active?current.decals.length:0,u.dqSkinHasDecalRelief.value=active&&current.decals.some((d)=>d.type==="scar"&&d.opacity>0&&d.relief>0)?1:0,current.decals.forEach((decal,i)=>{u.dqSkinDecalType.value[i]=decal.type==="scar"?1:0,u.dqSkinDecalDesign.value[i]=DESIGNS.indexOf(decal.design),u.dqSkinDecalPosition.value[i].fromArray(decal.position),u.dqSkinDecalNormal.value[i].fromArray(decal.normal),u.dqSkinDecalColor.value[i].set(decal.color),u.dqSkinDecalParams.value[i].set(decal.size,decal.rotation*Math.PI/180,decal.opacity,decal.relief)})}}function set(value){if(disposed)throw Error("Skin markings have been disposed.");return current=validateSkinMarkings(value,current),update(),clone(current)}function reset(){return set(clone(DEFAULT_SKIN_MARKINGS))}function inspect(){return{libraryId:library.id,modelSha256:library.modelSha256,state:clone(current),disposed,decalFrame:"world-space raw bind vertices; keep root transform fixed",materials:[...records.values()].map((r)=>{let active=disposed?r.source:r.material,u=r.uniforms;return{name:r.source.name,sourceMaterialUuid:r.source.uuid,activeMaterialUuid:active.uuid,sourcePreserved:unchanged(r.source,r.baseline),sourceColorUuid:r.baseline.map.uuid,sourceNormalUuid:r.baseline.normalMap?.uuid??null,activeColorUuid:active.map?.uuid,activeNormalUuid:active.normalMap?.uuid,cleanColorActive:active.map===r.maps.cleanColor,cleanNormalActive:active.normalMap===r.maps.cleanNormal,sourceColorActive:active.map===r.baseline.map,sourceNormalActive:active.normalMap===r.baseline.normalMap,tattooMaskActive:!disposed&&u.dqSkinTattooAmount.value>0,scarColorMaskActive:!disposed&&u.dqSkinScarAmount.value>0,scarNormalMaskActive:!disposed&&!!r.maps.sourceNormal&&u.dqSkinScarRelief.value>0,overlaysActive:!disposed&&u.dqSkinActive.value===1,decalsActive:disposed?0:u.dqSkinDecalCount.value,alphaPreserved:active.alphaTest===r.baseline.alphaTest&&active.opacity===r.baseline.opacity&&active.transparent===r.baseline.transparent,textureBindings:{...r.entry}}})}}function dispose(){if(disposed)return;for(let{node,original}of bindings)node.material=original;for(let r of records.values()){for(let map of Object.values(r.maps))map?.dispose();r.material.dispose()}current=clone(DEFAULT_SKIN_MARKINGS),disposed=!0}return update(),{set,state:()=>clone(current),inspect,reset,dispose}}
export{MAX_SKIN_DECALS,DEFAULT_SKIN_MARKINGS,validateSkinMarkings,createSkinMarkings};
