import{UniformsLib}from"./chunk-nrf8bzw3.js";import{BackSide,BufferAttribute,BufferGeometry,Color,DynamicDrawUsage,Euler,GLBufferAttribute,Group,InterleavedBuffer,InterleavedBufferAttribute,Line,LineBasicMaterial,LineSegments,Material,MathUtils,Matrix3,Matrix4,Object3D,Quaternion,REVISION,ShaderMaterial,Skeleton,SkinnedMesh,TangentSpaceNormalMap,UniformsUtils,Vector2,Vector3}from"./chunk-pz7tgqgm.js";/*!
 * @pixiv/three-vrm v3.5.4
 * VRM file loader for three.js.
 *
 * Copyright (c) 2019-2026 pixiv Inc.
 * @pixiv/three-vrm is distributed under MIT License
 * https://github.com/pixiv/three-vrm/blob/release/LICENSE
 */var __async2=(__this,__arguments,generator)=>{return new Promise((resolve,reject)=>{var fulfilled=(value)=>{try{step(generator.next(value))}catch(e){reject(e)}},rejected=(value)=>{try{step(generator.throw(value))}catch(e){reject(e)}},step=(x)=>x.done?resolve(x.value):Promise.resolve(x.value).then(fulfilled,rejected);step((generator=generator.apply(__this,__arguments)).next())})},VRMExpression=class extends Object3D{constructor(expressionName){super();this.weight=0,this.isBinary=!1,this.overrideBlink="none",this.overrideLookAt="none",this.overrideMouth="none",this._binds=[],this.name=`VRMExpression_${expressionName}`,this.expressionName=expressionName,this.type="VRMExpression",this.visible=!1}get binds(){return this._binds}get overrideBlinkAmount(){if(this.overrideBlink==="block")return 0<this.outputWeight?1:0;else if(this.overrideBlink==="blend")return this.outputWeight;else return 0}get overrideLookAtAmount(){if(this.overrideLookAt==="block")return 0<this.outputWeight?1:0;else if(this.overrideLookAt==="blend")return this.outputWeight;else return 0}get overrideMouthAmount(){if(this.overrideMouth==="block")return 0<this.outputWeight?1:0;else if(this.overrideMouth==="blend")return this.outputWeight;else return 0}get outputWeight(){if(this.isBinary)return this.weight>0.5?1:0;return this.weight}addBind(bind){this._binds.push(bind)}deleteBind(bind){let index=this._binds.indexOf(bind);if(index>=0)this._binds.splice(index,1)}applyWeight(options){var _a;let actualWeight=this.outputWeight;if(actualWeight*=(_a=options==null?void 0:options.multiplier)!=null?_a:1,this.isBinary&&actualWeight<1)actualWeight=0;this._binds.forEach((bind)=>bind.applyWeight(actualWeight))}clearAppliedWeight(){this._binds.forEach((bind)=>bind.clearAppliedWeight())}};function extractPrimitivesInternal(gltf,nodeIndex,node){var _a,_b;let json=gltf.parser.json,schemaNode=(_a=json.nodes)==null?void 0:_a[nodeIndex];if(schemaNode==null)return console.warn(`extractPrimitivesInternal: Attempt to use nodes[${nodeIndex}] of glTF but the node doesn't exist`),null;let meshIndex=schemaNode.mesh;if(meshIndex==null)return null;let schemaMesh=(_b=json.meshes)==null?void 0:_b[meshIndex];if(schemaMesh==null)return console.warn(`extractPrimitivesInternal: Attempt to use meshes[${meshIndex}] of glTF but the mesh doesn't exist`),null;let primitiveCount=schemaMesh.primitives.length,primitives=[];return node.traverse((object)=>{if(primitives.length<primitiveCount){if(object.isMesh)primitives.push(object)}}),primitives}function gltfExtractPrimitivesFromNode(gltf,nodeIndex){return __async2(this,null,function*(){let node=yield gltf.parser.getDependency("node",nodeIndex);return extractPrimitivesInternal(gltf,nodeIndex,node)})}var VRMExpressionPresetName={Aa:"aa",Ih:"ih",Ou:"ou",Ee:"ee",Oh:"oh",Blink:"blink",Happy:"happy",Angry:"angry",Sad:"sad",Relaxed:"relaxed",LookUp:"lookUp",Surprised:"surprised",LookDown:"lookDown",LookLeft:"lookLeft",LookRight:"lookRight",BlinkLeft:"blinkLeft",BlinkRight:"blinkRight",Neutral:"neutral"};function saturate(value){return Math.max(Math.min(value,1),0)}var VRMExpressionManager=class _VRMExpressionManager{constructor(){this.blinkExpressionNames=["blink","blinkLeft","blinkRight"],this.lookAtExpressionNames=["lookLeft","lookRight","lookUp","lookDown"],this.mouthExpressionNames=["aa","ee","ih","oh","ou"],this._expressions=[],this._expressionMap={}}get expressions(){return this._expressions.concat()}get expressionMap(){return Object.assign({},this._expressionMap)}get presetExpressionMap(){let result={},presetNameSet=new Set(Object.values(VRMExpressionPresetName));return Object.entries(this._expressionMap).forEach(([name,expression])=>{if(presetNameSet.has(name))result[name]=expression}),result}get customExpressionMap(){let result={},presetNameSet=new Set(Object.values(VRMExpressionPresetName));return Object.entries(this._expressionMap).forEach(([name,expression])=>{if(!presetNameSet.has(name))result[name]=expression}),result}copy(source){return this._expressions.concat().forEach((expression)=>{this.unregisterExpression(expression)}),source._expressions.forEach((expression)=>{this.registerExpression(expression)}),this.blinkExpressionNames=source.blinkExpressionNames.concat(),this.lookAtExpressionNames=source.lookAtExpressionNames.concat(),this.mouthExpressionNames=source.mouthExpressionNames.concat(),this}clone(){return new _VRMExpressionManager().copy(this)}getExpression(name){var _a;return(_a=this._expressionMap[name])!=null?_a:null}registerExpression(expression){this._expressions.push(expression),this._expressionMap[expression.expressionName]=expression}unregisterExpression(expression){let index=this._expressions.indexOf(expression);if(index===-1)console.warn("VRMExpressionManager: The specified expressions is not registered");this._expressions.splice(index,1),delete this._expressionMap[expression.expressionName]}getValue(name){var _a;let expression=this.getExpression(name);return(_a=expression==null?void 0:expression.weight)!=null?_a:null}setValue(name,weight){let expression=this.getExpression(name);if(expression)expression.weight=saturate(weight)}resetValues(){this._expressions.forEach((expression)=>{expression.weight=0})}getExpressionTrackName(name){let expression=this.getExpression(name);return expression?`${expression.name}.weight`:null}update(){let weightMultipliers=this._calculateWeightMultipliers();this._expressions.forEach((expression)=>{expression.clearAppliedWeight()}),this._expressions.forEach((expression)=>{let multiplier=1,name=expression.expressionName;if(this.blinkExpressionNames.indexOf(name)!==-1)multiplier*=weightMultipliers.blink;if(this.lookAtExpressionNames.indexOf(name)!==-1)multiplier*=weightMultipliers.lookAt;if(this.mouthExpressionNames.indexOf(name)!==-1)multiplier*=weightMultipliers.mouth;expression.applyWeight({multiplier})})}_calculateWeightMultipliers(){let blink=1,lookAt=1,mouth=1;return this._expressions.forEach((expression)=>{blink-=expression.overrideBlinkAmount,lookAt-=expression.overrideLookAtAmount,mouth-=expression.overrideMouthAmount}),blink=Math.max(0,blink),lookAt=Math.max(0,lookAt),mouth=Math.max(0,mouth),{blink,lookAt,mouth}}},VRMExpressionMaterialColorType={Color:"color",EmissionColor:"emissionColor",ShadeColor:"shadeColor",MatcapColor:"matcapColor",RimColor:"rimColor",OutlineColor:"outlineColor"},v0ExpressionMaterialColorMap={_Color:VRMExpressionMaterialColorType.Color,_EmissionColor:VRMExpressionMaterialColorType.EmissionColor,_ShadeColor:VRMExpressionMaterialColorType.ShadeColor,_RimColor:VRMExpressionMaterialColorType.RimColor,_OutlineColor:VRMExpressionMaterialColorType.OutlineColor},_color=new Color,_VRMExpressionMaterialColorBind=class _VRMExpressionMaterialColorBind2{constructor({material,type,targetValue,targetAlpha}){this.material=material,this.type=type,this.targetValue=targetValue,this.targetAlpha=targetAlpha!=null?targetAlpha:1;let color=this._initColorBindState(),alpha=this._initAlphaBindState();this._state={color,alpha}}applyWeight(weight){let{color,alpha}=this._state;if(color!=null){let{propertyName,deltaValue}=color,target=this.material[propertyName];if(target!=null)target.add(_color.copy(deltaValue).multiplyScalar(weight))}if(alpha!=null){let{propertyName,deltaValue}=alpha;if(this.material[propertyName]!=null)this.material[propertyName]+=deltaValue*weight}}clearAppliedWeight(){let{color,alpha}=this._state;if(color!=null){let{propertyName,initialValue}=color,target=this.material[propertyName];if(target!=null)target.copy(initialValue)}if(alpha!=null){let{propertyName,initialValue}=alpha;if(this.material[propertyName]!=null)this.material[propertyName]=initialValue}}_initColorBindState(){var _a,_b,_c;let{material,type,targetValue}=this,propertyNameMap=this._getPropertyNameMap(),propertyName=(_b=(_a=propertyNameMap==null?void 0:propertyNameMap[type])==null?void 0:_a[0])!=null?_b:null;if(propertyName==null)return console.warn(`Tried to add a material color bind to the material ${(_c=material.name)!=null?_c:"(no name)"}, the type ${type} but the material or the type is not supported.`),null;let initialValue=material[propertyName].clone(),deltaValue=new Color(targetValue.r-initialValue.r,targetValue.g-initialValue.g,targetValue.b-initialValue.b);return{propertyName,initialValue,deltaValue}}_initAlphaBindState(){var _a,_b,_c;let{material,type,targetAlpha}=this,propertyNameMap=this._getPropertyNameMap(),propertyName=(_b=(_a=propertyNameMap==null?void 0:propertyNameMap[type])==null?void 0:_a[1])!=null?_b:null;if(propertyName==null&&targetAlpha!==1)return console.warn(`Tried to add a material alpha bind to the material ${(_c=material.name)!=null?_c:"(no name)"}, the type ${type} but the material or the type does not support alpha.`),null;if(propertyName==null)return null;let initialValue=material[propertyName],deltaValue=targetAlpha-initialValue;return{propertyName,initialValue,deltaValue}}_getPropertyNameMap(){var _a,_b;return(_b=(_a=Object.entries(_VRMExpressionMaterialColorBind2._propertyNameMapMap).find(([distinguisher])=>{return this.material[distinguisher]===!0}))==null?void 0:_a[1])!=null?_b:null}};_VRMExpressionMaterialColorBind._propertyNameMapMap={isMeshStandardMaterial:{color:["color","opacity"],emissionColor:["emissive",null]},isMeshBasicMaterial:{color:["color","opacity"]},isMToonMaterial:{color:["color","opacity"],emissionColor:["emissive",null],outlineColor:["outlineColorFactor",null],matcapColor:["matcapFactor",null],rimColor:["parametricRimColorFactor",null],shadeColor:["shadeColorFactor",null]}};var VRMExpressionMaterialColorBind=_VRMExpressionMaterialColorBind,VRMExpressionMorphTargetBind=class{constructor({primitives,index,weight}){this.primitives=primitives,this.index=index,this.weight=weight}applyWeight(weight){this.primitives.forEach((mesh)=>{var _a;if(((_a=mesh.morphTargetInfluences)==null?void 0:_a[this.index])!=null)mesh.morphTargetInfluences[this.index]+=this.weight*weight})}clearAppliedWeight(){this.primitives.forEach((mesh)=>{var _a;if(((_a=mesh.morphTargetInfluences)==null?void 0:_a[this.index])!=null)mesh.morphTargetInfluences[this.index]=0})}},_v2=new Vector2,_VRMExpressionTextureTransformBind=class _VRMExpressionTextureTransformBind2{constructor({material,scale,offset}){var _a,_b;this.material=material,this.scale=scale,this.offset=offset;let propertyNames=(_a=Object.entries(_VRMExpressionTextureTransformBind2._propertyNamesMap).find(([distinguisher])=>{return material[distinguisher]===!0}))==null?void 0:_a[1];if(propertyNames==null)console.warn(`Tried to add a texture transform bind to the material ${(_b=material.name)!=null?_b:"(no name)"} but the material is not supported.`),this._properties=[];else this._properties=[],propertyNames.forEach((propertyName)=>{var _a2;let texture=(_a2=material[propertyName])==null?void 0:_a2.clone();if(!texture)return null;material[propertyName]=texture;let initialOffset=texture.offset.clone(),initialScale=texture.repeat.clone(),deltaOffset=offset.clone().sub(initialOffset),deltaScale=scale.clone().sub(initialScale);this._properties.push({name:propertyName,initialOffset,deltaOffset,initialScale,deltaScale})})}applyWeight(weight){this._properties.forEach((property)=>{let target=this.material[property.name];if(target===void 0)return;target.offset.add(_v2.copy(property.deltaOffset).multiplyScalar(weight)),target.repeat.add(_v2.copy(property.deltaScale).multiplyScalar(weight))})}clearAppliedWeight(){this._properties.forEach((property)=>{let target=this.material[property.name];if(target===void 0)return;target.offset.copy(property.initialOffset),target.repeat.copy(property.initialScale)})}};_VRMExpressionTextureTransformBind._propertyNamesMap={isMeshStandardMaterial:["map","emissiveMap","bumpMap","normalMap","displacementMap","roughnessMap","metalnessMap","alphaMap"],isMeshBasicMaterial:["map","specularMap","alphaMap"],isMToonMaterial:["map","normalMap","emissiveMap","shadeMultiplyTexture","rimMultiplyTexture","outlineWidthMultiplyTexture","uvAnimationMaskTexture"]};var VRMExpressionTextureTransformBind=_VRMExpressionTextureTransformBind,POSSIBLE_SPEC_VERSIONS=new Set(["1.0","1.0-beta"]),_VRMExpressionLoaderPlugin=class _VRMExpressionLoaderPlugin2{get name(){return"VRMExpressionLoaderPlugin"}constructor(parser){this.parser=parser}afterRoot(gltf){return __async2(this,null,function*(){gltf.userData.vrmExpressionManager=yield this.___v2Import(gltf)})}___v2Import(gltf){return __async2(this,null,function*(){let v1Result=yield this._v1Import(gltf);if(v1Result)return v1Result;let v0Result=yield this._v0Import(gltf);if(v0Result)return v0Result;return null})}_v1Import(gltf){return __async2(this,null,function*(){var _a,_b;let json=this.parser.json;if(((_a=json.extensionsUsed)==null?void 0:_a.indexOf("VRMC_vrm"))===-1)return null;let extension=(_b=json.extensions)==null?void 0:_b.VRMC_vrm;if(!extension)return null;let specVersion=extension.specVersion;if(!POSSIBLE_SPEC_VERSIONS.has(specVersion))return console.warn(`VRMExpressionLoaderPlugin: Unknown VRMC_vrm specVersion "${specVersion}"`),null;let schemaExpressions=extension.expressions;if(!schemaExpressions)return null;let presetNameSet=new Set(Object.values(VRMExpressionPresetName)),nameSchemaExpressionMap=new Map;if(schemaExpressions.preset!=null)Object.entries(schemaExpressions.preset).forEach(([name,schemaExpression])=>{if(schemaExpression==null)return;if(!presetNameSet.has(name)){console.warn(`VRMExpressionLoaderPlugin: Unknown preset name "${name}" detected. Ignoring the expression`);return}nameSchemaExpressionMap.set(name,schemaExpression)});if(schemaExpressions.custom!=null)Object.entries(schemaExpressions.custom).forEach(([name,schemaExpression])=>{if(presetNameSet.has(name)){console.warn(`VRMExpressionLoaderPlugin: Custom expression cannot have preset name "${name}". Ignoring the expression`);return}nameSchemaExpressionMap.set(name,schemaExpression)});let manager=new VRMExpressionManager;return yield Promise.all(Array.from(nameSchemaExpressionMap.entries()).map((_0)=>__async2(this,[_0],function*([name,schemaExpression]){var _a2,_b2,_c,_d,_e,_f,_g;let expression=new VRMExpression(name);if(gltf.scene.add(expression),expression.isBinary=(_a2=schemaExpression.isBinary)!=null?_a2:!1,expression.overrideBlink=(_b2=schemaExpression.overrideBlink)!=null?_b2:"none",expression.overrideLookAt=(_c=schemaExpression.overrideLookAt)!=null?_c:"none",expression.overrideMouth=(_d=schemaExpression.overrideMouth)!=null?_d:"none",(_e=schemaExpression.morphTargetBinds)==null||_e.forEach((bind)=>__async2(this,null,function*(){var _a3;if(bind.node===void 0||bind.index===void 0)return;let primitives=yield gltfExtractPrimitivesFromNode(gltf,bind.node),morphTargetIndex=bind.index;if(!primitives.every((primitive)=>Array.isArray(primitive.morphTargetInfluences)&&morphTargetIndex<primitive.morphTargetInfluences.length)){console.warn(`VRMExpressionLoaderPlugin: ${schemaExpression.name} attempts to index morph #${morphTargetIndex} but not found.`);return}expression.addBind(new VRMExpressionMorphTargetBind({primitives,index:morphTargetIndex,weight:(_a3=bind.weight)!=null?_a3:1}))})),schemaExpression.materialColorBinds||schemaExpression.textureTransformBinds){let gltfMaterials=[];gltf.scene.traverse((object)=>{let material=object.material;if(material)if(Array.isArray(material))gltfMaterials.push(...material);else gltfMaterials.push(material)}),(_f=schemaExpression.materialColorBinds)==null||_f.forEach((bind)=>__async2(this,null,function*(){gltfMaterials.filter((material)=>{var _a3;let materialIndex=(_a3=this.parser.associations.get(material))==null?void 0:_a3.materials;return bind.material===materialIndex}).forEach((material)=>{expression.addBind(new VRMExpressionMaterialColorBind({material,type:bind.type,targetValue:new Color().fromArray(bind.targetValue),targetAlpha:bind.targetValue[3]}))})})),(_g=schemaExpression.textureTransformBinds)==null||_g.forEach((bind)=>__async2(this,null,function*(){gltfMaterials.filter((material)=>{var _a3;let materialIndex=(_a3=this.parser.associations.get(material))==null?void 0:_a3.materials;return bind.material===materialIndex}).forEach((material)=>{var _a3,_b3;expression.addBind(new VRMExpressionTextureTransformBind({material,offset:new Vector2().fromArray((_a3=bind.offset)!=null?_a3:[0,0]),scale:new Vector2().fromArray((_b3=bind.scale)!=null?_b3:[1,1])}))})}))}manager.registerExpression(expression)}))),manager})}_v0Import(gltf){return __async2(this,null,function*(){var _a;let json=this.parser.json,vrmExt=(_a=json.extensions)==null?void 0:_a.VRM;if(!vrmExt)return null;let schemaBlendShape=vrmExt.blendShapeMaster;if(!schemaBlendShape)return null;let manager=new VRMExpressionManager,schemaBlendShapeGroups=schemaBlendShape.blendShapeGroups;if(!schemaBlendShapeGroups)return manager;let blendShapeNameSet=new Set;return yield Promise.all(schemaBlendShapeGroups.map((schemaGroup)=>__async2(this,null,function*(){var _a2;let v0PresetName=schemaGroup.presetName,v1PresetName=v0PresetName!=null&&_VRMExpressionLoaderPlugin2.v0v1PresetNameMap[v0PresetName]||null,name=v1PresetName!=null?v1PresetName:schemaGroup.name;if(name==null){console.warn("VRMExpressionLoaderPlugin: One of custom expressions has no name. Ignoring the expression");return}if(blendShapeNameSet.has(name)){console.warn(`VRMExpressionLoaderPlugin: An expression preset ${v0PresetName} has duplicated entries. Ignoring the expression`);return}blendShapeNameSet.add(name);let expression=new VRMExpression(name);if(gltf.scene.add(expression),expression.isBinary=(_a2=schemaGroup.isBinary)!=null?_a2:!1,schemaGroup.binds)schemaGroup.binds.forEach((bind)=>__async2(this,null,function*(){var _a3;if(bind.mesh===void 0||bind.index===void 0)return;let nodesUsingMesh=[];if((_a3=json.nodes)==null||_a3.forEach((node,i)=>{if(node.mesh===bind.mesh)nodesUsingMesh.push(i)}),nodesUsingMesh.length===0){console.warn(`VRMExpressionLoaderPlugin: ${schemaGroup.name} attempts to bind a morph target to the mesh #${bind.mesh} but the mesh is not found or not used in the scene. Ignoring the bind.`);return}let morphTargetIndex=bind.index;yield Promise.all(nodesUsingMesh.map((nodeIndex)=>__async2(this,null,function*(){var _a4;let primitives=yield gltfExtractPrimitivesFromNode(gltf,nodeIndex);if(!primitives.every((primitive)=>Array.isArray(primitive.morphTargetInfluences)&&morphTargetIndex<primitive.morphTargetInfluences.length)){console.warn(`VRMExpressionLoaderPlugin: ${schemaGroup.name} attempts to index ${morphTargetIndex}th morph but not found.`);return}expression.addBind(new VRMExpressionMorphTargetBind({primitives,index:morphTargetIndex,weight:0.01*((_a4=bind.weight)!=null?_a4:100)}))})))}));let materialValues=schemaGroup.materialValues;if(materialValues&&materialValues.length!==0)materialValues.forEach((materialValue)=>{if(materialValue.materialName===void 0||materialValue.propertyName===void 0||materialValue.targetValue===void 0)return;let materials=[];gltf.scene.traverse((object)=>{if(object.material){let material=object.material;if(Array.isArray(material))materials.push(...material.filter((mtl)=>(mtl.name===materialValue.materialName||mtl.name===materialValue.materialName+" (Outline)")&&materials.indexOf(mtl)===-1));else if(material.name===materialValue.materialName&&materials.indexOf(material)===-1)materials.push(material)}});let materialPropertyName=materialValue.propertyName;materials.forEach((material)=>{if(materialPropertyName==="_MainTex_ST"){let scale=new Vector2(materialValue.targetValue[0],materialValue.targetValue[1]),offset=new Vector2(materialValue.targetValue[2],materialValue.targetValue[3]);offset.y=1-offset.y-scale.y,expression.addBind(new VRMExpressionTextureTransformBind({material,scale,offset}));return}let materialColorType=v0ExpressionMaterialColorMap[materialPropertyName];if(materialColorType){expression.addBind(new VRMExpressionMaterialColorBind({material,type:materialColorType,targetValue:new Color().fromArray(materialValue.targetValue),targetAlpha:materialValue.targetValue[3]}));return}console.warn(materialPropertyName+" is not supported")})});manager.registerExpression(expression)}))),manager})}};_VRMExpressionLoaderPlugin.v0v1PresetNameMap={a:"aa",e:"ee",i:"ih",o:"oh",u:"ou",blink:"blink",joy:"happy",angry:"angry",sorrow:"sad",fun:"relaxed",lookup:"lookUp",lookdown:"lookDown",lookleft:"lookLeft",lookright:"lookRight",blink_l:"blinkLeft",blink_r:"blinkRight",neutral:"neutral"};var _VRMFirstPerson=class _VRMFirstPerson2{constructor(humanoid,meshAnnotations){this._firstPersonOnlyLayer=_VRMFirstPerson2.DEFAULT_FIRSTPERSON_ONLY_LAYER,this._thirdPersonOnlyLayer=_VRMFirstPerson2.DEFAULT_THIRDPERSON_ONLY_LAYER,this._initializedLayers=!1,this.humanoid=humanoid,this.meshAnnotations=meshAnnotations}copy(source){if(this.humanoid!==source.humanoid)throw Error("VRMFirstPerson: humanoid must be same in order to copy");return this.meshAnnotations=source.meshAnnotations.map((annotation)=>({meshes:annotation.meshes.concat(),type:annotation.type})),this}clone(){return new _VRMFirstPerson2(this.humanoid,this.meshAnnotations).copy(this)}get firstPersonOnlyLayer(){return this._firstPersonOnlyLayer}get thirdPersonOnlyLayer(){return this._thirdPersonOnlyLayer}setup({firstPersonOnlyLayer=_VRMFirstPerson2.DEFAULT_FIRSTPERSON_ONLY_LAYER,thirdPersonOnlyLayer=_VRMFirstPerson2.DEFAULT_THIRDPERSON_ONLY_LAYER}={}){if(this._initializedLayers)return;this._firstPersonOnlyLayer=firstPersonOnlyLayer,this._thirdPersonOnlyLayer=thirdPersonOnlyLayer,this.meshAnnotations.forEach((item)=>{item.meshes.forEach((mesh)=>{if(item.type==="firstPersonOnly")mesh.layers.set(this._firstPersonOnlyLayer),mesh.traverse((child)=>child.layers.set(this._firstPersonOnlyLayer));else if(item.type==="thirdPersonOnly")mesh.layers.set(this._thirdPersonOnlyLayer),mesh.traverse((child)=>child.layers.set(this._thirdPersonOnlyLayer));else if(item.type==="auto")this._createHeadlessModel(mesh)})}),this._initializedLayers=!0}_excludeTriangles(triangles,bws,skinIndex,exclude){let count=0;if(bws!=null&&bws.length>0)for(let i=0;i<triangles.length;i+=3){let a=triangles[i],b=triangles[i+1],c=triangles[i+2],bw0=bws[a],skin0=skinIndex[a];if(bw0[0]>0&&exclude.includes(skin0[0]))continue;if(bw0[1]>0&&exclude.includes(skin0[1]))continue;if(bw0[2]>0&&exclude.includes(skin0[2]))continue;if(bw0[3]>0&&exclude.includes(skin0[3]))continue;let bw1=bws[b],skin1=skinIndex[b];if(bw1[0]>0&&exclude.includes(skin1[0]))continue;if(bw1[1]>0&&exclude.includes(skin1[1]))continue;if(bw1[2]>0&&exclude.includes(skin1[2]))continue;if(bw1[3]>0&&exclude.includes(skin1[3]))continue;let bw2=bws[c],skin2=skinIndex[c];if(bw2[0]>0&&exclude.includes(skin2[0]))continue;if(bw2[1]>0&&exclude.includes(skin2[1]))continue;if(bw2[2]>0&&exclude.includes(skin2[2]))continue;if(bw2[3]>0&&exclude.includes(skin2[3]))continue;triangles[count++]=a,triangles[count++]=b,triangles[count++]=c}return count}_createErasedMesh(src,erasingBonesIndex){let dst=new SkinnedMesh(src.geometry.clone(),src.material);dst.name=`${src.name}(erase)`,dst.frustumCulled=src.frustumCulled,dst.layers.set(this._firstPersonOnlyLayer);let geometry=dst.geometry,skinIndexAttr=geometry.getAttribute("skinIndex"),skinIndexAttrArray=skinIndexAttr instanceof GLBufferAttribute?[]:skinIndexAttr.array,skinIndex=[];for(let i=0;i<skinIndexAttrArray.length;i+=4)skinIndex.push([skinIndexAttrArray[i],skinIndexAttrArray[i+1],skinIndexAttrArray[i+2],skinIndexAttrArray[i+3]]);let skinWeightAttr=geometry.getAttribute("skinWeight"),skinWeightAttrArray=skinWeightAttr instanceof GLBufferAttribute?[]:skinWeightAttr.array,skinWeight=[];for(let i=0;i<skinWeightAttrArray.length;i+=4)skinWeight.push([skinWeightAttrArray[i],skinWeightAttrArray[i+1],skinWeightAttrArray[i+2],skinWeightAttrArray[i+3]]);let index=geometry.getIndex();if(!index)throw Error("The geometry doesn't have an index buffer");let oldTriangles=Array.from(index.array),count=this._excludeTriangles(oldTriangles,skinWeight,skinIndex,erasingBonesIndex),newTriangle=[];for(let i=0;i<count;i++)newTriangle[i]=oldTriangles[i];if(geometry.setIndex(newTriangle),src.onBeforeRender)dst.onBeforeRender=src.onBeforeRender;return dst.bind(new Skeleton(src.skeleton.bones,src.skeleton.boneInverses),new Matrix4),dst}_createHeadlessModelForSkinnedMesh(parent,mesh){let eraseBoneIndexes=[];if(mesh.skeleton.bones.forEach((bone,index)=>{if(this._isEraseTarget(bone))eraseBoneIndexes.push(index)}),!eraseBoneIndexes.length){mesh.layers.enable(this._thirdPersonOnlyLayer),mesh.layers.enable(this._firstPersonOnlyLayer);return}mesh.layers.set(this._thirdPersonOnlyLayer);let newMesh=this._createErasedMesh(mesh,eraseBoneIndexes);parent.add(newMesh)}_createHeadlessModel(node){if(node.type==="Group")if(node.layers.set(this._thirdPersonOnlyLayer),this._isEraseTarget(node))node.traverse((child)=>child.layers.set(this._thirdPersonOnlyLayer));else{let parent=new Group;parent.name=`_headless_${node.name}`,parent.layers.set(this._firstPersonOnlyLayer),node.parent.add(parent),node.children.filter((child)=>child.type==="SkinnedMesh").forEach((child)=>{let skinnedMesh=child;this._createHeadlessModelForSkinnedMesh(parent,skinnedMesh)})}else if(node.type==="SkinnedMesh"){let skinnedMesh=node;this._createHeadlessModelForSkinnedMesh(node.parent,skinnedMesh)}else if(this._isEraseTarget(node))node.layers.set(this._thirdPersonOnlyLayer),node.traverse((child)=>child.layers.set(this._thirdPersonOnlyLayer))}_isEraseTarget(bone){if(bone===this.humanoid.getRawBoneNode("head"))return!0;else if(!bone.parent)return!1;else return this._isEraseTarget(bone.parent)}};_VRMFirstPerson.DEFAULT_FIRSTPERSON_ONLY_LAYER=9;_VRMFirstPerson.DEFAULT_THIRDPERSON_ONLY_LAYER=10;var _v3A=new Vector3,_v3B=new Vector3,_quatA=new Quaternion;function quatInvertCompat(target){if(target.invert)target.invert();else target.inverse();return target}var _v3A2=new Vector3,_quatA2=new Quaternion;var _v3A3=new Vector3,_quatA3=new Quaternion,_boneWorldPos=new Vector3;var _quatA4=new Quaternion,_quatB=new Quaternion,_v3A4=new Vector3,_v3B2=new Vector3,SQRT_2_OVER_2=Math.sqrt(2)/2,QUAT_XY_CW90=new Quaternion(0,0,-SQRT_2_OVER_2,SQRT_2_OVER_2),VEC3_POSITIVE_Y=new Vector3(0,1,0);var _position=new Vector3,_scale=new Vector3;function getWorldQuaternionLite(object,out){return object.matrixWorld.decompose(_position,out,_scale),out}function calcAzimuthAltitude(vector){return[Math.atan2(-vector.z,vector.x),Math.atan2(vector.y,Math.sqrt(vector.x*vector.x+vector.z*vector.z))]}function sanitizeAngle(angle){let roundTurn=Math.round(angle/2/Math.PI);return angle-2*Math.PI*roundTurn}var VEC3_POSITIVE_Z=new Vector3(0,0,1),_v3A5=new Vector3,_v3B3=new Vector3,_v3C=new Vector3,_quatA5=new Quaternion,_quatB2=new Quaternion,_quatC=new Quaternion,_quatD=new Quaternion,_eulerA=new Euler,_VRMLookAt=class _VRMLookAt2{constructor(humanoid,applier){this.offsetFromHeadBone=new Vector3,this.autoUpdate=!0,this.faceFront=new Vector3(0,0,1),this.humanoid=humanoid,this.applier=applier,this._yaw=0,this._pitch=0,this._needsUpdate=!0,this._restHeadWorldQuaternion=this.getLookAtWorldQuaternion(new Quaternion)}get yaw(){return this._yaw}set yaw(value){this._yaw=value,this._needsUpdate=!0}get pitch(){return this._pitch}set pitch(value){this._pitch=value,this._needsUpdate=!0}get euler(){return console.warn("VRMLookAt: euler is deprecated. use getEuler() instead."),this.getEuler(new Euler)}getEuler(target){return target.set(MathUtils.DEG2RAD*this._pitch,MathUtils.DEG2RAD*this._yaw,0,"YXZ")}copy(source){if(this.humanoid!==source.humanoid)throw Error("VRMLookAt: humanoid must be same in order to copy");return this.offsetFromHeadBone.copy(source.offsetFromHeadBone),this.applier=source.applier,this.autoUpdate=source.autoUpdate,this.target=source.target,this.faceFront.copy(source.faceFront),this}clone(){return new _VRMLookAt2(this.humanoid,this.applier).copy(this)}reset(){this._yaw=0,this._pitch=0,this._needsUpdate=!0}getLookAtWorldPosition(target){let head=this.humanoid.getRawBoneNode("head");return target.copy(this.offsetFromHeadBone).applyMatrix4(head.matrixWorld)}getLookAtWorldQuaternion(target){let head=this.humanoid.getRawBoneNode("head");return getWorldQuaternionLite(head,target)}getFaceFrontQuaternion(target){if(this.faceFront.distanceToSquared(VEC3_POSITIVE_Z)<0.01)return target.copy(this._restHeadWorldQuaternion).invert();let[faceFrontAzimuth,faceFrontAltitude]=calcAzimuthAltitude(this.faceFront);return _eulerA.set(0,0.5*Math.PI+faceFrontAzimuth,faceFrontAltitude,"YZX"),target.setFromEuler(_eulerA).premultiply(_quatD.copy(this._restHeadWorldQuaternion).invert())}getLookAtWorldDirection(target){return this.getLookAtWorldQuaternion(_quatB2),this.getFaceFrontQuaternion(_quatC),target.copy(VEC3_POSITIVE_Z).applyQuaternion(_quatB2).applyQuaternion(_quatC).applyEuler(this.getEuler(_eulerA))}lookAt(position){let headRotDiffInv=_quatA5.copy(this._restHeadWorldQuaternion).multiply(quatInvertCompat(this.getLookAtWorldQuaternion(_quatB2))),headPos=this.getLookAtWorldPosition(_v3B3),lookAtDir=_v3C.copy(position).sub(headPos).applyQuaternion(headRotDiffInv).normalize(),[azimuthFrom,altitudeFrom]=calcAzimuthAltitude(this.faceFront),[azimuthTo,altitudeTo]=calcAzimuthAltitude(lookAtDir),yaw=sanitizeAngle(azimuthTo-azimuthFrom),pitch=sanitizeAngle(altitudeFrom-altitudeTo);this._yaw=MathUtils.RAD2DEG*yaw,this._pitch=MathUtils.RAD2DEG*pitch,this._needsUpdate=!0}update(delta){if(this.target!=null&&this.autoUpdate)this.lookAt(this.target.getWorldPosition(_v3A5));if(this._needsUpdate)this._needsUpdate=!1,this.applier.applyYawPitch(this._yaw,this._pitch)}};_VRMLookAt.EULER_ORDER="YXZ";var VEC3_POSITIVE_Z2=new Vector3(0,0,1),_quatA6=new Quaternion,_quatB3=new Quaternion,_eulerA2=new Euler(0,0,0,"YXZ"),VRMLookAtBoneApplier=class{constructor(humanoid,rangeMapHorizontalInner,rangeMapHorizontalOuter,rangeMapVerticalDown,rangeMapVerticalUp){this.humanoid=humanoid,this.rangeMapHorizontalInner=rangeMapHorizontalInner,this.rangeMapHorizontalOuter=rangeMapHorizontalOuter,this.rangeMapVerticalDown=rangeMapVerticalDown,this.rangeMapVerticalUp=rangeMapVerticalUp,this.faceFront=new Vector3(0,0,1),this._restQuatLeftEye=new Quaternion,this._restQuatRightEye=new Quaternion,this._restLeftEyeParentWorldQuat=new Quaternion,this._restRightEyeParentWorldQuat=new Quaternion;let leftEye=this.humanoid.getRawBoneNode("leftEye"),rightEye=this.humanoid.getRawBoneNode("rightEye");if(leftEye)this._restQuatLeftEye.copy(leftEye.quaternion),getWorldQuaternionLite(leftEye.parent,this._restLeftEyeParentWorldQuat);if(rightEye)this._restQuatRightEye.copy(rightEye.quaternion),getWorldQuaternionLite(rightEye.parent,this._restRightEyeParentWorldQuat)}applyYawPitch(yaw,pitch){let leftEye=this.humanoid.getRawBoneNode("leftEye"),rightEye=this.humanoid.getRawBoneNode("rightEye"),leftEyeNormalized=this.humanoid.getNormalizedBoneNode("leftEye"),rightEyeNormalized=this.humanoid.getNormalizedBoneNode("rightEye");if(leftEye){if(pitch<0)_eulerA2.x=-MathUtils.DEG2RAD*this.rangeMapVerticalDown.map(-pitch);else _eulerA2.x=MathUtils.DEG2RAD*this.rangeMapVerticalUp.map(pitch);if(yaw<0)_eulerA2.y=-MathUtils.DEG2RAD*this.rangeMapHorizontalInner.map(-yaw);else _eulerA2.y=MathUtils.DEG2RAD*this.rangeMapHorizontalOuter.map(yaw);_quatA6.setFromEuler(_eulerA2),this._getWorldFaceFrontQuat(_quatB3),leftEyeNormalized.quaternion.copy(_quatB3).multiply(_quatA6).multiply(_quatB3.invert()),_quatA6.copy(this._restLeftEyeParentWorldQuat),leftEye.quaternion.copy(leftEyeNormalized.quaternion).multiply(_quatA6).premultiply(_quatA6.invert()).multiply(this._restQuatLeftEye)}if(rightEye){if(pitch<0)_eulerA2.x=-MathUtils.DEG2RAD*this.rangeMapVerticalDown.map(-pitch);else _eulerA2.x=MathUtils.DEG2RAD*this.rangeMapVerticalUp.map(pitch);if(yaw<0)_eulerA2.y=-MathUtils.DEG2RAD*this.rangeMapHorizontalOuter.map(-yaw);else _eulerA2.y=MathUtils.DEG2RAD*this.rangeMapHorizontalInner.map(yaw);_quatA6.setFromEuler(_eulerA2),this._getWorldFaceFrontQuat(_quatB3),rightEyeNormalized.quaternion.copy(_quatB3).multiply(_quatA6).multiply(_quatB3.invert()),_quatA6.copy(this._restRightEyeParentWorldQuat),rightEye.quaternion.copy(rightEyeNormalized.quaternion).multiply(_quatA6).premultiply(_quatA6.invert()).multiply(this._restQuatRightEye)}}lookAt(euler){console.warn("VRMLookAtBoneApplier: lookAt() is deprecated. use apply() instead.");let yaw=MathUtils.RAD2DEG*euler.y,pitch=MathUtils.RAD2DEG*euler.x;this.applyYawPitch(yaw,pitch)}_getWorldFaceFrontQuat(target){if(this.faceFront.distanceToSquared(VEC3_POSITIVE_Z2)<0.01)return target.identity();let[faceFrontAzimuth,faceFrontAltitude]=calcAzimuthAltitude(this.faceFront);return _eulerA2.set(0,0.5*Math.PI+faceFrontAzimuth,faceFrontAltitude,"YZX"),target.setFromEuler(_eulerA2)}};VRMLookAtBoneApplier.type="bone";var VRMLookAtExpressionApplier=class{constructor(expressions,rangeMapHorizontalInner,rangeMapHorizontalOuter,rangeMapVerticalDown,rangeMapVerticalUp){this.expressions=expressions,this.rangeMapHorizontalInner=rangeMapHorizontalInner,this.rangeMapHorizontalOuter=rangeMapHorizontalOuter,this.rangeMapVerticalDown=rangeMapVerticalDown,this.rangeMapVerticalUp=rangeMapVerticalUp}applyYawPitch(yaw,pitch){if(pitch<0)this.expressions.setValue("lookDown",0),this.expressions.setValue("lookUp",this.rangeMapVerticalUp.map(-pitch));else this.expressions.setValue("lookUp",0),this.expressions.setValue("lookDown",this.rangeMapVerticalDown.map(pitch));if(yaw<0)this.expressions.setValue("lookLeft",0),this.expressions.setValue("lookRight",this.rangeMapHorizontalOuter.map(-yaw));else this.expressions.setValue("lookRight",0),this.expressions.setValue("lookLeft",this.rangeMapHorizontalOuter.map(yaw))}lookAt(euler){console.warn("VRMLookAtBoneApplier: lookAt() is deprecated. use apply() instead.");let yaw=MathUtils.RAD2DEG*euler.y,pitch=MathUtils.RAD2DEG*euler.x;this.applyYawPitch(yaw,pitch)}};VRMLookAtExpressionApplier.type="expression";var{defineProperty:__defProp,getOwnPropertySymbols:__getOwnPropSymbols}=Object,__hasOwnProp=Object.prototype.hasOwnProperty,__propIsEnum=Object.prototype.propertyIsEnumerable,__defNormalProp=(obj,key,value)=>(key in obj)?__defProp(obj,key,{enumerable:!0,configurable:!0,writable:!0,value}):obj[key]=value,__spreadValues=(a,b)=>{for(var prop in b||(b={}))if(__hasOwnProp.call(b,prop))__defNormalProp(a,prop,b[prop]);if(__getOwnPropSymbols){for(var prop of __getOwnPropSymbols(b))if(__propIsEnum.call(b,prop))__defNormalProp(a,prop,b[prop])}return a},__async3=(__this,__arguments,generator)=>{return new Promise((resolve,reject)=>{var fulfilled=(value)=>{try{step(generator.next(value))}catch(e){reject(e)}},rejected=(value)=>{try{step(generator.throw(value))}catch(e){reject(e)}},step=(x)=>x.done?resolve(x.value):Promise.resolve(x.value).then(fulfilled,rejected);step((generator=generator.apply(__this,__arguments)).next())})},colorSpaceEncodingMap={"":3000,srgb:3001};function setTextureColorSpace(texture,colorSpace){if(parseInt(REVISION,10)>=152)texture.colorSpace=colorSpace;else texture.encoding=colorSpaceEncodingMap[colorSpace]}var GLTFMToonMaterialParamsAssignHelper=class{get pending(){return Promise.all(this._pendings)}constructor(parser,materialParams){this._parser=parser,this._materialParams=materialParams,this._pendings=[]}assignPrimitive(key,value){if(value!=null)this._materialParams[key]=value}assignColor(key,value,convertSRGBToLinear){if(value!=null){let color=new Color().fromArray(value);if(convertSRGBToLinear)color.convertSRGBToLinear();this._materialParams[key]=color}}assignTexture(key,schemaTexture,isColorTexture){return __async3(this,null,function*(){let promise=(()=>__async3(this,null,function*(){if(schemaTexture!=null){let texture=yield this._parser.assignTexture(this._materialParams,key,schemaTexture);if(texture==null){console.warn("GLTFMToonMaterialParamsAssignHelper: Failed to load texture. The rendering result may be wrong");return}if(isColorTexture)setTextureColorSpace(texture,"srgb")}}))();return this._pendings.push(promise),promise})}assignTextureByIndex(key,textureIndex,isColorTexture){return __async3(this,null,function*(){return this.assignTexture(key,textureIndex!=null?{index:textureIndex}:void 0,isColorTexture)})}},mtoon_default=`// #define PHONG

varying vec3 vViewPosition;

#ifndef FLAT_SHADED
  varying vec3 vNormal;
#endif

#include <common>

// #include <uv_pars_vertex>
#ifdef MTOON_USE_UV
  varying vec2 vUv;

  // COMPAT: pre-r151 uses a common uvTransform
  #if THREE_VRM_THREE_REVISION < 151
    uniform mat3 uvTransform;
  #endif
#endif

// #include <uv2_pars_vertex>
// COMAPT: pre-r151 uses uv2 for lightMap and aoMap
#if THREE_VRM_THREE_REVISION < 151
  #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
    attribute vec2 uv2;
    varying vec2 vUv2;
    uniform mat3 uv2Transform;
  #endif
#endif

// #include <displacementmap_pars_vertex>
// #include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

#ifdef USE_OUTLINEWIDTHMULTIPLYTEXTURE
  uniform sampler2D outlineWidthMultiplyTexture;
  uniform mat3 outlineWidthMultiplyTextureUvTransform;
#endif

uniform float outlineWidthFactor;

void main() {

  // #include <uv_vertex>
  #ifdef MTOON_USE_UV
    // COMPAT: pre-r151 uses a common uvTransform
    #if THREE_VRM_THREE_REVISION >= 151
      vUv = uv;
    #else
      vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
    #endif
  #endif

  // #include <uv2_vertex>
  // COMAPT: pre-r151 uses uv2 for lightMap and aoMap
  #if THREE_VRM_THREE_REVISION < 151
    #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
      vUv2 = ( uv2Transform * vec3( uv2, 1 ) ).xy;
    #endif
  #endif

  #include <color_vertex>

  #include <beginnormal_vertex>
  #include <morphnormal_vertex>
  #include <skinbase_vertex>
  #include <skinnormal_vertex>

  // we need this to compute the outline properly
  objectNormal = normalize( objectNormal );

  #include <defaultnormal_vertex>

  #ifndef FLAT_SHADED // Normal computed with derivatives when FLAT_SHADED
    vNormal = normalize( transformedNormal );
  #endif

  #include <begin_vertex>

  #include <morphtarget_vertex>
  #include <skinning_vertex>
  // #include <displacementmap_vertex>
  #include <project_vertex>
  #include <logdepthbuf_vertex>
  #include <clipping_planes_vertex>

  vViewPosition = - mvPosition.xyz;

  #ifdef OUTLINE
    float worldNormalLength = length( transformedNormal );
    vec3 outlineOffset = outlineWidthFactor * worldNormalLength * objectNormal;

    #ifdef USE_OUTLINEWIDTHMULTIPLYTEXTURE
      vec2 outlineWidthMultiplyTextureUv = ( outlineWidthMultiplyTextureUvTransform * vec3( vUv, 1 ) ).xy;
      float outlineTex = texture2D( outlineWidthMultiplyTexture, outlineWidthMultiplyTextureUv ).g;
      outlineOffset *= outlineTex;
    #endif

    #ifdef OUTLINE_WIDTH_SCREEN
      outlineOffset *= vViewPosition.z / projectionMatrix[ 1 ].y;
    #endif

    gl_Position = projectionMatrix * modelViewMatrix * vec4( outlineOffset + transformed, 1.0 );

    gl_Position.z += 1E-6 * gl_Position.w; // anti-artifact magic
  #endif

  #include <worldpos_vertex>
  // #include <envmap_vertex>
  #include <shadowmap_vertex>
  #include <fog_vertex>

}`,mtoon_default2=`// #define PHONG

uniform vec3 litFactor;

uniform float opacity;

uniform vec3 shadeColorFactor;
#ifdef USE_SHADEMULTIPLYTEXTURE
  uniform sampler2D shadeMultiplyTexture;
  uniform mat3 shadeMultiplyTextureUvTransform;
#endif

uniform float shadingShiftFactor;
uniform float shadingToonyFactor;

#ifdef USE_SHADINGSHIFTTEXTURE
  uniform sampler2D shadingShiftTexture;
  uniform mat3 shadingShiftTextureUvTransform;
  uniform float shadingShiftTextureScale;
#endif

uniform float giEqualizationFactor;

uniform vec3 parametricRimColorFactor;
#ifdef USE_RIMMULTIPLYTEXTURE
  uniform sampler2D rimMultiplyTexture;
  uniform mat3 rimMultiplyTextureUvTransform;
#endif
uniform float rimLightingMixFactor;
uniform float parametricRimFresnelPowerFactor;
uniform float parametricRimLiftFactor;

#ifdef USE_MATCAPTEXTURE
  uniform vec3 matcapFactor;
  uniform sampler2D matcapTexture;
  uniform mat3 matcapTextureUvTransform;
#endif

uniform vec3 emissive;
uniform float emissiveIntensity;

uniform vec3 outlineColorFactor;
uniform float outlineLightingMixFactor;

#ifdef USE_UVANIMATIONMASKTEXTURE
  uniform sampler2D uvAnimationMaskTexture;
  uniform mat3 uvAnimationMaskTextureUvTransform;
#endif

uniform float uvAnimationScrollXOffset;
uniform float uvAnimationScrollYOffset;
uniform float uvAnimationRotationPhase;

#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>

// #include <uv_pars_fragment>
#if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )
  varying vec2 vUv;
#endif

// #include <uv2_pars_fragment>
// COMAPT: pre-r151 uses uv2 for lightMap and aoMap
#if THREE_VRM_THREE_REVISION < 151
  #if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
    varying vec2 vUv2;
  #endif
#endif

#include <map_pars_fragment>

#ifdef USE_MAP
  uniform mat3 mapUvTransform;
#endif

// #include <alphamap_pars_fragment>

#include <alphatest_pars_fragment>

#include <aomap_pars_fragment>
// #include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>

#ifdef USE_EMISSIVEMAP
  uniform mat3 emissiveMapUvTransform;
#endif

// #include <envmap_common_pars_fragment>
// #include <envmap_pars_fragment>
// #include <cube_uv_reflection_fragment>
#include <fog_pars_fragment>

// #include <bsdfs>
// COMPAT: pre-r151 doesn't have BRDF_Lambert in <common>
#if THREE_VRM_THREE_REVISION < 151
  vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
    return RECIPROCAL_PI * diffuseColor;
  }
#endif

#include <lights_pars_begin>

#include <normal_pars_fragment>

// #include <lights_phong_pars_fragment>
varying vec3 vViewPosition;

struct MToonMaterial {
  vec3 diffuseColor;
  vec3 shadeColor;
  float shadingShift;
};

float linearstep( float a, float b, float t ) {
  return clamp( ( t - a ) / ( b - a ), 0.0, 1.0 );
}

/**
 * Convert NdotL into toon shading factor using shadingShift and shadingToony
 */
float getShading(
  const in float dotNL,
  const in float shadow,
  const in float shadingShift
) {
  float shading = dotNL;
  shading = shading + shadingShift;
  shading = linearstep( -1.0 + shadingToonyFactor, 1.0 - shadingToonyFactor, shading );
  shading *= shadow;
  return shading;
}

/**
 * Mix diffuseColor and shadeColor using shading factor and light color
 */
vec3 getDiffuse(
  const in MToonMaterial material,
  const in float shading,
  in vec3 lightColor
) {
  #ifdef DEBUG_LITSHADERATE
    return vec3( BRDF_Lambert( shading * lightColor ) );
  #endif

  vec3 col = lightColor * BRDF_Lambert( mix( material.shadeColor, material.diffuseColor, shading ) );

  // The "comment out if you want to PBR absolutely" line
  #ifdef V0_COMPAT_SHADE
    col = min( col, material.diffuseColor );
  #endif

  return col;
}

// COMPAT: pre-r156 uses a struct GeometricContext
#if THREE_VRM_THREE_REVISION >= 157
  void RE_Direct_MToon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in MToonMaterial material, const in float shadow, inout ReflectedLight reflectedLight ) {
    float dotNL = clamp( dot( geometryNormal, directLight.direction ), -1.0, 1.0 );
    vec3 irradiance = directLight.color;

    // directSpecular will be used for rim lighting, not an actual specular
    reflectedLight.directSpecular += irradiance;

    irradiance *= dotNL;

    float shading = getShading( dotNL, shadow, material.shadingShift );

    // toon shaded diffuse
    reflectedLight.directDiffuse += getDiffuse( material, shading, directLight.color );
  }

  void RE_IndirectDiffuse_MToon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in MToonMaterial material, inout ReflectedLight reflectedLight ) {
    // indirect diffuse will use diffuseColor, no shadeColor involved
    reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

    // directSpecular will be used for rim lighting, not an actual specular
    reflectedLight.directSpecular += irradiance;
  }
#else
  void RE_Direct_MToon( const in IncidentLight directLight, const in GeometricContext geometry, const in MToonMaterial material, const in float shadow, inout ReflectedLight reflectedLight ) {
    float dotNL = clamp( dot( geometry.normal, directLight.direction ), -1.0, 1.0 );
    vec3 irradiance = directLight.color;

    // directSpecular will be used for rim lighting, not an actual specular
    reflectedLight.directSpecular += irradiance;

    irradiance *= dotNL;

    float shading = getShading( dotNL, shadow, material.shadingShift );

    // toon shaded diffuse
    reflectedLight.directDiffuse += getDiffuse( material, shading, directLight.color );
  }

  void RE_IndirectDiffuse_MToon( const in vec3 irradiance, const in GeometricContext geometry, const in MToonMaterial material, inout ReflectedLight reflectedLight ) {
    // indirect diffuse will use diffuseColor, no shadeColor involved
    reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

    // directSpecular will be used for rim lighting, not an actual specular
    reflectedLight.directSpecular += irradiance;
  }
#endif

#define RE_Direct RE_Direct_MToon
#define RE_IndirectDiffuse RE_IndirectDiffuse_MToon
#define Material_LightProbeLOD( material ) (0)

#include <shadowmap_pars_fragment>
// #include <bumpmap_pars_fragment>

// #include <normalmap_pars_fragment>
#ifdef USE_NORMALMAP

  uniform sampler2D normalMap;
  uniform mat3 normalMapUvTransform;
  uniform vec2 normalScale;

#endif

// COMPAT: pre-r151
// USE_NORMALMAP_OBJECTSPACE used to be OBJECTSPACE_NORMALMAP in pre-r151
#if defined( USE_NORMALMAP_OBJECTSPACE ) || defined( OBJECTSPACE_NORMALMAP )

  uniform mat3 normalMatrix;

#endif

// COMPAT: pre-r151
// USE_NORMALMAP_TANGENTSPACE used to be TANGENTSPACE_NORMALMAP in pre-r151
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( TANGENTSPACE_NORMALMAP ) )

  // Per-Pixel Tangent Space Normal Mapping
  // http://hacksoflife.blogspot.ch/2009/11/per-pixel-tangent-space-normal-mapping.html

  // three-vrm specific change: it requires \`uv\` as an input in order to support uv scrolls

  // Temporary compat against shader change @ Three.js r126, r151
  #if THREE_VRM_THREE_REVISION >= 151

    mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {

      vec3 q0 = dFdx( eye_pos.xyz );
      vec3 q1 = dFdy( eye_pos.xyz );
      vec2 st0 = dFdx( uv.st );
      vec2 st1 = dFdy( uv.st );

      vec3 N = surf_norm;

      vec3 q1perp = cross( q1, N );
      vec3 q0perp = cross( N, q0 );

      vec3 T = q1perp * st0.x + q0perp * st1.x;
      vec3 B = q1perp * st0.y + q0perp * st1.y;

      float det = max( dot( T, T ), dot( B, B ) );
      float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );

      return mat3( T * scale, B * scale, N );

    }

  #else

    vec3 perturbNormal2Arb( vec2 uv, vec3 eye_pos, vec3 surf_norm, vec3 mapN, float faceDirection ) {

      vec3 q0 = vec3( dFdx( eye_pos.x ), dFdx( eye_pos.y ), dFdx( eye_pos.z ) );
      vec3 q1 = vec3( dFdy( eye_pos.x ), dFdy( eye_pos.y ), dFdy( eye_pos.z ) );
      vec2 st0 = dFdx( uv.st );
      vec2 st1 = dFdy( uv.st );

      vec3 N = normalize( surf_norm );

      vec3 q1perp = cross( q1, N );
      vec3 q0perp = cross( N, q0 );

      vec3 T = q1perp * st0.x + q0perp * st1.x;
      vec3 B = q1perp * st0.y + q0perp * st1.y;

      // three-vrm specific change: Workaround for the issue that happens when delta of uv = 0.0
      // TODO: Is this still required? Or shall I make a PR about it?
      if ( length( T ) == 0.0 || length( B ) == 0.0 ) {
        return surf_norm;
      }

      float det = max( dot( T, T ), dot( B, B ) );
      float scale = ( det == 0.0 ) ? 0.0 : faceDirection * inversesqrt( det );

      return normalize( T * ( mapN.x * scale ) + B * ( mapN.y * scale ) + N * mapN.z );

    }

  #endif

#endif

// #include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

// == post correction ==========================================================
void postCorrection() {
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
  #include <fog_fragment>
  #include <premultiplied_alpha_fragment>
  #include <dithering_fragment>
}

// == main procedure ===========================================================
void main() {
  #include <clipping_planes_fragment>

  vec2 uv = vec2(0.5, 0.5);

  #if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )
    uv = vUv;

    float uvAnimMask = 1.0;
    #ifdef USE_UVANIMATIONMASKTEXTURE
      vec2 uvAnimationMaskTextureUv = ( uvAnimationMaskTextureUvTransform * vec3( uv, 1 ) ).xy;
      uvAnimMask = texture2D( uvAnimationMaskTexture, uvAnimationMaskTextureUv ).b;
    #endif

    float uvRotCos = cos( uvAnimationRotationPhase * uvAnimMask );
    float uvRotSin = sin( uvAnimationRotationPhase * uvAnimMask );
    uv = mat2( uvRotCos, -uvRotSin, uvRotSin, uvRotCos ) * ( uv - 0.5 ) + 0.5;
    uv = uv + vec2( uvAnimationScrollXOffset, uvAnimationScrollYOffset ) * uvAnimMask;
  #endif

  #ifdef DEBUG_UV
    gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
    #if ( defined( MTOON_USE_UV ) && !defined( MTOON_UVS_VERTEX_ONLY ) )
      gl_FragColor = vec4( uv, 0.0, 1.0 );
    #endif
    return;
  #endif

  vec4 diffuseColor = vec4( litFactor, opacity );
  ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
  vec3 totalEmissiveRadiance = emissive * emissiveIntensity;

  #include <logdepthbuf_fragment>

  // #include <map_fragment>
  #ifdef USE_MAP
    vec2 mapUv = ( mapUvTransform * vec3( uv, 1 ) ).xy;
    vec4 sampledDiffuseColor = texture2D( map, mapUv );
    #ifdef DECODE_VIDEO_TEXTURE
      sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
    #endif
    diffuseColor *= sampledDiffuseColor;
  #endif

  // #include <color_fragment>
  #if ( defined( USE_COLOR ) && !defined( IGNORE_VERTEX_COLOR ) )
    diffuseColor.rgb *= vColor;
  #endif

  // #include <alphamap_fragment>

  #include <alphatest_fragment>

  // #include <specularmap_fragment>

  // #include <normal_fragment_begin>
  float faceDirection = gl_FrontFacing ? 1.0 : -1.0;

  #ifdef FLAT_SHADED

    vec3 fdx = dFdx( vViewPosition );
    vec3 fdy = dFdy( vViewPosition );
    vec3 normal = normalize( cross( fdx, fdy ) );

  #else

    vec3 normal = normalize( vNormal );

    #ifdef DOUBLE_SIDED

      normal *= faceDirection;

    #endif

  #endif

  #ifdef USE_NORMALMAP

    vec2 normalMapUv = ( normalMapUvTransform * vec3( uv, 1 ) ).xy;

  #endif

  #ifdef USE_NORMALMAP_TANGENTSPACE

    #ifdef USE_TANGENT

      mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );

    #else

      mat3 tbn = getTangentFrame( - vViewPosition, normal, normalMapUv );

    #endif

    #if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )

      tbn[0] *= faceDirection;
      tbn[1] *= faceDirection;

    #endif

  #endif

  #ifdef USE_CLEARCOAT_NORMALMAP

    #ifdef USE_TANGENT

      mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );

    #else

      mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );

    #endif

    #if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )

      tbn2[0] *= faceDirection;
      tbn2[1] *= faceDirection;

    #endif

  #endif

  // non perturbed normal for clearcoat among others

  vec3 nonPerturbedNormal = normal;

  #ifdef OUTLINE
    normal *= -1.0;
  #endif

  // #include <normal_fragment_maps>

  // COMPAT: pre-r151
  // USE_NORMALMAP_OBJECTSPACE used to be OBJECTSPACE_NORMALMAP in pre-r151
  #if defined( USE_NORMALMAP_OBJECTSPACE ) || defined( OBJECTSPACE_NORMALMAP )

    normal = texture2D( normalMap, normalMapUv ).xyz * 2.0 - 1.0; // overrides both flatShading and attribute normals

    #ifdef FLIP_SIDED

      normal = - normal;

    #endif

    #ifdef DOUBLE_SIDED

      normal = normal * faceDirection;

    #endif

    normal = normalize( normalMatrix * normal );

  // COMPAT: pre-r151
  // USE_NORMALMAP_TANGENTSPACE used to be TANGENTSPACE_NORMALMAP in pre-r151
  #elif defined( USE_NORMALMAP_TANGENTSPACE ) || defined( TANGENTSPACE_NORMALMAP )

    vec3 mapN = texture2D( normalMap, normalMapUv ).xyz * 2.0 - 1.0;
    mapN.xy *= normalScale;

    // COMPAT: pre-r151
    #if THREE_VRM_THREE_REVISION >= 151 || defined( USE_TANGENT )

      normal = normalize( tbn * mapN );

    #else

      normal = perturbNormal2Arb( uv, -vViewPosition, normal, mapN, faceDirection );

    #endif

  #endif

  // #include <emissivemap_fragment>
  #ifdef USE_EMISSIVEMAP
    vec2 emissiveMapUv = ( emissiveMapUvTransform * vec3( uv, 1 ) ).xy;
    totalEmissiveRadiance *= texture2D( emissiveMap, emissiveMapUv ).rgb;
  #endif

  #ifdef DEBUG_NORMAL
    gl_FragColor = vec4( 0.5 + 0.5 * normal, 1.0 );
    return;
  #endif

  // -- MToon: lighting --------------------------------------------------------
  // accumulation
  // #include <lights_phong_fragment>
  MToonMaterial material;

  material.diffuseColor = diffuseColor.rgb;

  material.shadeColor = shadeColorFactor;
  #ifdef USE_SHADEMULTIPLYTEXTURE
    vec2 shadeMultiplyTextureUv = ( shadeMultiplyTextureUvTransform * vec3( uv, 1 ) ).xy;
    material.shadeColor *= texture2D( shadeMultiplyTexture, shadeMultiplyTextureUv ).rgb;
  #endif

  #if ( defined( USE_COLOR ) && !defined( IGNORE_VERTEX_COLOR ) )
    material.shadeColor.rgb *= vColor;
  #endif

  material.shadingShift = shadingShiftFactor;
  #ifdef USE_SHADINGSHIFTTEXTURE
    vec2 shadingShiftTextureUv = ( shadingShiftTextureUvTransform * vec3( uv, 1 ) ).xy;
    material.shadingShift += texture2D( shadingShiftTexture, shadingShiftTextureUv ).r * shadingShiftTextureScale;
  #endif

  // #include <lights_fragment_begin>

  // MToon Specific changes:
  // Since we want to take shadows into account of shading instead of irradiance,
  // we had to modify the codes that multiplies the results of shadowmap into color of direct lights.

  // COMPAT: pre-r156 uses a struct GeometricContext
  #if THREE_VRM_THREE_REVISION >= 157
    vec3 geometryPosition = - vViewPosition;
    vec3 geometryNormal = normal;
    vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );

    vec3 geometryClearcoatNormal;

    #ifdef USE_CLEARCOAT

      geometryClearcoatNormal = clearcoatNormal;

    #endif
  #else
    GeometricContext geometry;

    geometry.position = - vViewPosition;
    geometry.normal = normal;
    geometry.viewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );

    #ifdef USE_CLEARCOAT

      geometry.clearcoatNormal = clearcoatNormal;

    #endif
  #endif

  IncidentLight directLight;

  // since these variables will be used in unrolled loop, we have to define in prior
  float shadow;

  #if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )

    PointLight pointLight;
    #if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
    PointLightShadow pointLightShadow;
    #endif

    #pragma unroll_loop_start
    for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {

      pointLight = pointLights[ i ];

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        getPointLightInfo( pointLight, geometryPosition, directLight );
      #else
        getPointLightInfo( pointLight, geometry, directLight );
      #endif

      shadow = 1.0;
      #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
      pointLightShadow = pointLightShadows[ i ];
      // COMPAT: pre-r166
      // r166 introduced shadowIntensity
      #if THREE_VRM_THREE_REVISION >= 166
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
      #else
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
      #endif
      #endif

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );
      #else
        RE_Direct( directLight, geometry, material, shadow, reflectedLight );
      #endif

    }
    #pragma unroll_loop_end

  #endif

  #if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )

    SpotLight spotLight;
    // COMPAT: pre-r144 uses NUM_SPOT_LIGHT_SHADOWS, r144+ uses NUM_SPOT_LIGHT_COORDS
    #if THREE_VRM_THREE_REVISION >= 144
      #if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_COORDS > 0
      SpotLightShadow spotLightShadow;
      #endif
    #elif defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
    SpotLightShadow spotLightShadow;
    #endif

    #pragma unroll_loop_start
    for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {

      spotLight = spotLights[ i ];

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        getSpotLightInfo( spotLight, geometryPosition, directLight );
      #else
        getSpotLightInfo( spotLight, geometry, directLight );
      #endif

      shadow = 1.0;
      // COMPAT: pre-r144 uses NUM_SPOT_LIGHT_SHADOWS and vSpotShadowCoord, r144+ uses NUM_SPOT_LIGHT_COORDS and vSpotLightCoord
      // COMPAT: pre-r166 does not have shadowIntensity, r166+ has shadowIntensity
      #if THREE_VRM_THREE_REVISION >= 166
        #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_COORDS )
        spotLightShadow = spotLightShadows[ i ];
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
        #endif
      #elif THREE_VRM_THREE_REVISION >= 144
        #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_COORDS )
        spotLightShadow = spotLightShadows[ i ];
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
        #endif
      #elif defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
      spotLightShadow = spotLightShadows[ i ];
      shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotShadowCoord[ i ] ) : 1.0;
      #endif

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );
      #else
        RE_Direct( directLight, geometry, material, shadow, reflectedLight );
      #endif

    }
    #pragma unroll_loop_end

  #endif

  #if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )

    DirectionalLight directionalLight;
    #if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
    DirectionalLightShadow directionalLightShadow;
    #endif

    #pragma unroll_loop_start
    for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {

      directionalLight = directionalLights[ i ];

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        getDirectionalLightInfo( directionalLight, directLight );
      #else
        getDirectionalLightInfo( directionalLight, geometry, directLight );
      #endif

      shadow = 1.0;
      #if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
      directionalLightShadow = directionalLightShadows[ i ];
      // COMPAT: pre-r166
      // r166 introduced shadowIntensity
      #if THREE_VRM_THREE_REVISION >= 166
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
      #else
        shadow = all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
      #endif
      #endif

      // COMPAT: pre-r156 uses a struct GeometricContext
      #if THREE_VRM_THREE_REVISION >= 157
        RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, shadow, reflectedLight );
      #else
        RE_Direct( directLight, geometry, material, shadow, reflectedLight );
      #endif

    }
    #pragma unroll_loop_end

  #endif

  // #if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )

  //   RectAreaLight rectAreaLight;

  //   #pragma unroll_loop_start
  //   for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {

  //     rectAreaLight = rectAreaLights[ i ];
  //     RE_Direct_RectArea( rectAreaLight, geometry, material, reflectedLight );

  //   }
  //   #pragma unroll_loop_end

  // #endif

  #if defined( RE_IndirectDiffuse )

    vec3 iblIrradiance = vec3( 0.0 );

    vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );

    // COMPAT: pre-r156 uses a struct GeometricContext
    // COMPAT: pre-r156 doesn't have a define USE_LIGHT_PROBES
    #if THREE_VRM_THREE_REVISION >= 157
      #if defined( USE_LIGHT_PROBES )
        irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
      #endif
    #else
      irradiance += getLightProbeIrradiance( lightProbe, geometry.normal );
    #endif

    #if ( NUM_HEMI_LIGHTS > 0 )

      #pragma unroll_loop_start
      for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {

        // COMPAT: pre-r156 uses a struct GeometricContext
        #if THREE_VRM_THREE_REVISION >= 157
          irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
        #else
          irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometry.normal );
        #endif

      }
      #pragma unroll_loop_end

    #endif

  #endif

  // #if defined( RE_IndirectSpecular )

  //   vec3 radiance = vec3( 0.0 );
  //   vec3 clearcoatRadiance = vec3( 0.0 );

  // #endif

  #include <lights_fragment_maps>
  #include <lights_fragment_end>

  // modulation
  #include <aomap_fragment>

  vec3 col = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;

  #ifdef DEBUG_LITSHADERATE
    gl_FragColor = vec4( col, diffuseColor.a );
    postCorrection();
    return;
  #endif

  // -- MToon: rim lighting -----------------------------------------
  vec3 viewDir = normalize( vViewPosition );

  #ifndef PHYSICALLY_CORRECT_LIGHTS
    reflectedLight.directSpecular /= PI;
  #endif
  vec3 rimMix = mix( vec3( 1.0 ), reflectedLight.directSpecular, rimLightingMixFactor );

  vec3 rim = parametricRimColorFactor * pow( saturate( 1.0 - dot( viewDir, normal ) + parametricRimLiftFactor ), parametricRimFresnelPowerFactor );

  #ifdef USE_MATCAPTEXTURE
    {
      vec3 x = normalize( vec3( viewDir.z, 0.0, -viewDir.x ) );
      vec3 y = cross( viewDir, x ); // guaranteed to be normalized
      vec2 sphereUv = 0.5 + 0.5 * vec2( dot( x, normal ), -dot( y, normal ) );
      sphereUv = ( matcapTextureUvTransform * vec3( sphereUv, 1 ) ).xy;
      vec3 matcap = texture2D( matcapTexture, sphereUv ).rgb;
      rim += matcapFactor * matcap;
    }
  #endif

  #ifdef USE_RIMMULTIPLYTEXTURE
    vec2 rimMultiplyTextureUv = ( rimMultiplyTextureUvTransform * vec3( uv, 1 ) ).xy;
    rim *= texture2D( rimMultiplyTexture, rimMultiplyTextureUv ).rgb;
  #endif

  col += rimMix * rim;

  // -- MToon: Emission --------------------------------------------------------
  col += totalEmissiveRadiance;

  // #include <envmap_fragment>

  // -- Almost done! -----------------------------------------------------------
  #if defined( OUTLINE )
    col = outlineColorFactor.rgb * mix( vec3( 1.0 ), col, outlineLightingMixFactor );
  #endif

  #ifdef OPAQUE
    diffuseColor.a = 1.0;
  #endif

  gl_FragColor = vec4( col, diffuseColor.a );
  postCorrection();
}
`,MToonMaterialDebugMode={None:"none",Normal:"normal",LitShadeRate:"litShadeRate",UV:"uv"},MToonMaterialOutlineWidthMode={None:"none",WorldCoordinates:"worldCoordinates",ScreenCoordinates:"screenCoordinates"},encodingColorSpaceMap={3000:"",3001:"srgb"};function getTextureColorSpace(texture){if(parseInt(REVISION,10)>=152)return texture.colorSpace;else return encodingColorSpaceMap[texture.encoding]}var MToonMaterial=class extends ShaderMaterial{constructor(parameters={}){var _a;super({vertexShader:mtoon_default,fragmentShader:mtoon_default2});if(this.uvAnimationScrollXSpeedFactor=0,this.uvAnimationScrollYSpeedFactor=0,this.uvAnimationRotationSpeedFactor=0,this.fog=!0,this.normalMapType=TangentSpaceNormalMap,this._ignoreVertexColor=!0,this._v0CompatShade=!1,this._debugMode=MToonMaterialDebugMode.None,this._outlineWidthMode=MToonMaterialOutlineWidthMode.None,this._isOutline=!1,parameters.transparentWithZWrite)parameters.depthWrite=!0;delete parameters.transparentWithZWrite,parameters.fog=!0,parameters.lights=!0,parameters.clipping=!0,this.uniforms=UniformsUtils.merge([UniformsLib.common,UniformsLib.normalmap,UniformsLib.emissivemap,UniformsLib.fog,UniformsLib.lights,{litFactor:{value:new Color(1,1,1)},mapUvTransform:{value:new Matrix3},colorAlpha:{value:1},normalMapUvTransform:{value:new Matrix3},shadeColorFactor:{value:new Color(0,0,0)},shadeMultiplyTexture:{value:null},shadeMultiplyTextureUvTransform:{value:new Matrix3},shadingShiftFactor:{value:0},shadingShiftTexture:{value:null},shadingShiftTextureUvTransform:{value:new Matrix3},shadingShiftTextureScale:{value:1},shadingToonyFactor:{value:0.9},giEqualizationFactor:{value:0.9},matcapFactor:{value:new Color(1,1,1)},matcapTexture:{value:null},matcapTextureUvTransform:{value:new Matrix3},parametricRimColorFactor:{value:new Color(0,0,0)},rimMultiplyTexture:{value:null},rimMultiplyTextureUvTransform:{value:new Matrix3},rimLightingMixFactor:{value:1},parametricRimFresnelPowerFactor:{value:5},parametricRimLiftFactor:{value:0},emissive:{value:new Color(0,0,0)},emissiveIntensity:{value:1},emissiveMapUvTransform:{value:new Matrix3},outlineWidthMultiplyTexture:{value:null},outlineWidthMultiplyTextureUvTransform:{value:new Matrix3},outlineWidthFactor:{value:0},outlineColorFactor:{value:new Color(0,0,0)},outlineLightingMixFactor:{value:1},uvAnimationMaskTexture:{value:null},uvAnimationMaskTextureUvTransform:{value:new Matrix3},uvAnimationScrollXOffset:{value:0},uvAnimationScrollYOffset:{value:0},uvAnimationRotationPhase:{value:0}},(_a=parameters.uniforms)!=null?_a:{}]),this.setValues(parameters),this._uploadUniformsWorkaround(),this.customProgramCacheKey=()=>[...Object.entries(this._generateDefines()).map(([token,macro])=>`${token}:${macro}`),this.matcapTexture?`matcapTextureColorSpace:${getTextureColorSpace(this.matcapTexture)}`:"",this.shadeMultiplyTexture?`shadeMultiplyTextureColorSpace:${getTextureColorSpace(this.shadeMultiplyTexture)}`:"",this.rimMultiplyTexture?`rimMultiplyTextureColorSpace:${getTextureColorSpace(this.rimMultiplyTexture)}`:""].join(","),this.onBeforeCompile=(shader)=>{let threeRevision=parseInt(REVISION,10),defines=Object.entries(__spreadValues(__spreadValues({},this._generateDefines()),this.defines)).filter(([token,macro])=>!!macro).map(([token,macro])=>`#define ${token} ${macro}`).join(`
`)+`
`;if(shader.vertexShader=defines+shader.vertexShader,shader.fragmentShader=defines+shader.fragmentShader,threeRevision<154)shader.fragmentShader=shader.fragmentShader.replace("#include <colorspace_fragment>","#include <encodings_fragment>")}}get color(){return this.uniforms.litFactor.value}set color(value){this.uniforms.litFactor.value=value}get map(){return this.uniforms.map.value}set map(value){this.uniforms.map.value=value}get normalMap(){return this.uniforms.normalMap.value}set normalMap(value){this.uniforms.normalMap.value=value}get normalScale(){return this.uniforms.normalScale.value}set normalScale(value){this.uniforms.normalScale.value=value}get emissive(){return this.uniforms.emissive.value}set emissive(value){this.uniforms.emissive.value=value}get emissiveIntensity(){return this.uniforms.emissiveIntensity.value}set emissiveIntensity(value){this.uniforms.emissiveIntensity.value=value}get emissiveMap(){return this.uniforms.emissiveMap.value}set emissiveMap(value){this.uniforms.emissiveMap.value=value}get shadeColorFactor(){return this.uniforms.shadeColorFactor.value}set shadeColorFactor(value){this.uniforms.shadeColorFactor.value=value}get shadeMultiplyTexture(){return this.uniforms.shadeMultiplyTexture.value}set shadeMultiplyTexture(value){this.uniforms.shadeMultiplyTexture.value=value}get shadingShiftFactor(){return this.uniforms.shadingShiftFactor.value}set shadingShiftFactor(value){this.uniforms.shadingShiftFactor.value=value}get shadingShiftTexture(){return this.uniforms.shadingShiftTexture.value}set shadingShiftTexture(value){this.uniforms.shadingShiftTexture.value=value}get shadingShiftTextureScale(){return this.uniforms.shadingShiftTextureScale.value}set shadingShiftTextureScale(value){this.uniforms.shadingShiftTextureScale.value=value}get shadingToonyFactor(){return this.uniforms.shadingToonyFactor.value}set shadingToonyFactor(value){this.uniforms.shadingToonyFactor.value=value}get giEqualizationFactor(){return this.uniforms.giEqualizationFactor.value}set giEqualizationFactor(value){this.uniforms.giEqualizationFactor.value=value}get matcapFactor(){return this.uniforms.matcapFactor.value}set matcapFactor(value){this.uniforms.matcapFactor.value=value}get matcapTexture(){return this.uniforms.matcapTexture.value}set matcapTexture(value){this.uniforms.matcapTexture.value=value}get parametricRimColorFactor(){return this.uniforms.parametricRimColorFactor.value}set parametricRimColorFactor(value){this.uniforms.parametricRimColorFactor.value=value}get rimMultiplyTexture(){return this.uniforms.rimMultiplyTexture.value}set rimMultiplyTexture(value){this.uniforms.rimMultiplyTexture.value=value}get rimLightingMixFactor(){return this.uniforms.rimLightingMixFactor.value}set rimLightingMixFactor(value){this.uniforms.rimLightingMixFactor.value=value}get parametricRimFresnelPowerFactor(){return this.uniforms.parametricRimFresnelPowerFactor.value}set parametricRimFresnelPowerFactor(value){this.uniforms.parametricRimFresnelPowerFactor.value=value}get parametricRimLiftFactor(){return this.uniforms.parametricRimLiftFactor.value}set parametricRimLiftFactor(value){this.uniforms.parametricRimLiftFactor.value=value}get outlineWidthMultiplyTexture(){return this.uniforms.outlineWidthMultiplyTexture.value}set outlineWidthMultiplyTexture(value){this.uniforms.outlineWidthMultiplyTexture.value=value}get outlineWidthFactor(){return this.uniforms.outlineWidthFactor.value}set outlineWidthFactor(value){this.uniforms.outlineWidthFactor.value=value}get outlineColorFactor(){return this.uniforms.outlineColorFactor.value}set outlineColorFactor(value){this.uniforms.outlineColorFactor.value=value}get outlineLightingMixFactor(){return this.uniforms.outlineLightingMixFactor.value}set outlineLightingMixFactor(value){this.uniforms.outlineLightingMixFactor.value=value}get uvAnimationMaskTexture(){return this.uniforms.uvAnimationMaskTexture.value}set uvAnimationMaskTexture(value){this.uniforms.uvAnimationMaskTexture.value=value}get uvAnimationScrollXOffset(){return this.uniforms.uvAnimationScrollXOffset.value}set uvAnimationScrollXOffset(value){this.uniforms.uvAnimationScrollXOffset.value=value}get uvAnimationScrollYOffset(){return this.uniforms.uvAnimationScrollYOffset.value}set uvAnimationScrollYOffset(value){this.uniforms.uvAnimationScrollYOffset.value=value}get uvAnimationRotationPhase(){return this.uniforms.uvAnimationRotationPhase.value}set uvAnimationRotationPhase(value){this.uniforms.uvAnimationRotationPhase.value=value}get ignoreVertexColor(){return this._ignoreVertexColor}set ignoreVertexColor(value){this._ignoreVertexColor=value,this.needsUpdate=!0}get v0CompatShade(){return this._v0CompatShade}set v0CompatShade(v){this._v0CompatShade=v,this.needsUpdate=!0}get debugMode(){return this._debugMode}set debugMode(m){this._debugMode=m,this.needsUpdate=!0}get outlineWidthMode(){return this._outlineWidthMode}set outlineWidthMode(m){this._outlineWidthMode=m,this.needsUpdate=!0}get isOutline(){return this._isOutline}set isOutline(b){this._isOutline=b,this.needsUpdate=!0}get isMToonMaterial(){return!0}update(delta){this._uploadUniformsWorkaround(),this._updateUVAnimation(delta)}copy(source){return super.copy(source),this.map=source.map,this.normalMap=source.normalMap,this.emissiveMap=source.emissiveMap,this.shadeMultiplyTexture=source.shadeMultiplyTexture,this.shadingShiftTexture=source.shadingShiftTexture,this.matcapTexture=source.matcapTexture,this.rimMultiplyTexture=source.rimMultiplyTexture,this.outlineWidthMultiplyTexture=source.outlineWidthMultiplyTexture,this.uvAnimationMaskTexture=source.uvAnimationMaskTexture,this.normalMapType=source.normalMapType,this.uvAnimationScrollXSpeedFactor=source.uvAnimationScrollXSpeedFactor,this.uvAnimationScrollYSpeedFactor=source.uvAnimationScrollYSpeedFactor,this.uvAnimationRotationSpeedFactor=source.uvAnimationRotationSpeedFactor,this.ignoreVertexColor=source.ignoreVertexColor,this.v0CompatShade=source.v0CompatShade,this.debugMode=source.debugMode,this.outlineWidthMode=source.outlineWidthMode,this.isOutline=source.isOutline,this.needsUpdate=!0,this}_updateUVAnimation(delta){this.uniforms.uvAnimationScrollXOffset.value+=delta*this.uvAnimationScrollXSpeedFactor,this.uniforms.uvAnimationScrollYOffset.value+=delta*this.uvAnimationScrollYSpeedFactor,this.uniforms.uvAnimationRotationPhase.value+=delta*this.uvAnimationRotationSpeedFactor,this.uniforms.alphaTest.value=this.alphaTest,this.uniformsNeedUpdate=!0}_uploadUniformsWorkaround(){this.uniforms.opacity.value=this.opacity,this._updateTextureMatrix(this.uniforms.map,this.uniforms.mapUvTransform),this._updateTextureMatrix(this.uniforms.normalMap,this.uniforms.normalMapUvTransform),this._updateTextureMatrix(this.uniforms.emissiveMap,this.uniforms.emissiveMapUvTransform),this._updateTextureMatrix(this.uniforms.shadeMultiplyTexture,this.uniforms.shadeMultiplyTextureUvTransform),this._updateTextureMatrix(this.uniforms.shadingShiftTexture,this.uniforms.shadingShiftTextureUvTransform),this._updateTextureMatrix(this.uniforms.matcapTexture,this.uniforms.matcapTextureUvTransform),this._updateTextureMatrix(this.uniforms.rimMultiplyTexture,this.uniforms.rimMultiplyTextureUvTransform),this._updateTextureMatrix(this.uniforms.outlineWidthMultiplyTexture,this.uniforms.outlineWidthMultiplyTextureUvTransform),this._updateTextureMatrix(this.uniforms.uvAnimationMaskTexture,this.uniforms.uvAnimationMaskTextureUvTransform),this.uniformsNeedUpdate=!0}_generateDefines(){let threeRevision=parseInt(REVISION,10),useUvInVert=this.outlineWidthMultiplyTexture!==null,useUvInFrag=this.map!==null||this.normalMap!==null||this.emissiveMap!==null||this.shadeMultiplyTexture!==null||this.shadingShiftTexture!==null||this.rimMultiplyTexture!==null||this.uvAnimationMaskTexture!==null;return{THREE_VRM_THREE_REVISION:threeRevision,OUTLINE:this._isOutline,MTOON_USE_UV:useUvInVert||useUvInFrag,MTOON_UVS_VERTEX_ONLY:useUvInVert&&!useUvInFrag,V0_COMPAT_SHADE:this._v0CompatShade,USE_SHADEMULTIPLYTEXTURE:this.shadeMultiplyTexture!==null,USE_SHADINGSHIFTTEXTURE:this.shadingShiftTexture!==null,USE_MATCAPTEXTURE:this.matcapTexture!==null,USE_RIMMULTIPLYTEXTURE:this.rimMultiplyTexture!==null,USE_OUTLINEWIDTHMULTIPLYTEXTURE:this._isOutline&&this.outlineWidthMultiplyTexture!==null,USE_UVANIMATIONMASKTEXTURE:this.uvAnimationMaskTexture!==null,IGNORE_VERTEX_COLOR:this._ignoreVertexColor===!0,DEBUG_NORMAL:this._debugMode==="normal",DEBUG_LITSHADERATE:this._debugMode==="litShadeRate",DEBUG_UV:this._debugMode==="uv",OUTLINE_WIDTH_SCREEN:this._isOutline&&this._outlineWidthMode===MToonMaterialOutlineWidthMode.ScreenCoordinates}}_updateTextureMatrix(src,dst){if(src.value){if(src.value.matrixAutoUpdate)src.value.updateMatrix();dst.value.copy(src.value.matrix)}}},POSSIBLE_SPEC_VERSIONS6=new Set(["1.0","1.0-beta"]),_MToonMaterialLoaderPlugin=class _MToonMaterialLoaderPlugin2{get name(){return _MToonMaterialLoaderPlugin2.EXTENSION_NAME}constructor(parser,options={}){var _a,_b,_c,_d;this.parser=parser,this.materialType=(_a=options.materialType)!=null?_a:MToonMaterial,this.renderOrderOffset=(_b=options.renderOrderOffset)!=null?_b:0,this.v0CompatShade=(_c=options.v0CompatShade)!=null?_c:!1,this.debugMode=(_d=options.debugMode)!=null?_d:"none",this._mToonMaterialSet=new Set}beforeRoot(){return __async3(this,null,function*(){this._removeUnlitExtensionIfMToonExists()})}afterRoot(gltf){return __async3(this,null,function*(){gltf.userData.vrmMToonMaterials=Array.from(this._mToonMaterialSet)})}getMaterialType(materialIndex){if(this._getMToonExtension(materialIndex))return this.materialType;return null}extendMaterialParams(materialIndex,materialParams){let extension=this._getMToonExtension(materialIndex);if(extension)return this._extendMaterialParams(extension,materialParams);return null}loadMesh(meshIndex){return __async3(this,null,function*(){var _a;let parser=this.parser,meshDef=(_a=parser.json.meshes)==null?void 0:_a[meshIndex];if(meshDef==null)throw Error(`MToonMaterialLoaderPlugin: Attempt to use meshes[${meshIndex}] of glTF but the mesh doesn't exist`);let primitivesDef=meshDef.primitives,meshOrGroup=yield parser.loadMesh(meshIndex);if(primitivesDef.length===1){let mesh=meshOrGroup,materialIndex=primitivesDef[0].material;if(materialIndex!=null)this._setupPrimitive(mesh,materialIndex)}else{let group=meshOrGroup;for(let i=0;i<primitivesDef.length;i++){let mesh=group.children[i],materialIndex=primitivesDef[i].material;if(materialIndex!=null)this._setupPrimitive(mesh,materialIndex)}}return meshOrGroup})}_removeUnlitExtensionIfMToonExists(){let materialDefs=this.parser.json.materials;materialDefs==null||materialDefs.map((materialDef,iMaterial)=>{var _a;if(this._getMToonExtension(iMaterial)&&((_a=materialDef.extensions)==null?void 0:_a.KHR_materials_unlit))delete materialDef.extensions.KHR_materials_unlit})}_getMToonExtension(materialIndex){var _a,_b;let materialDef=(_a=this.parser.json.materials)==null?void 0:_a[materialIndex];if(materialDef==null){console.warn(`MToonMaterialLoaderPlugin: Attempt to use materials[${materialIndex}] of glTF but the material doesn't exist`);return}let extension=(_b=materialDef.extensions)==null?void 0:_b[_MToonMaterialLoaderPlugin2.EXTENSION_NAME];if(extension==null)return;let specVersion=extension.specVersion;if(!POSSIBLE_SPEC_VERSIONS6.has(specVersion)){console.warn(`MToonMaterialLoaderPlugin: Unknown ${_MToonMaterialLoaderPlugin2.EXTENSION_NAME} specVersion "${specVersion}"`);return}return extension}_extendMaterialParams(extension,materialParams){return __async3(this,null,function*(){var _a;delete materialParams.metalness,delete materialParams.roughness;let assignHelper=new GLTFMToonMaterialParamsAssignHelper(this.parser,materialParams);assignHelper.assignPrimitive("transparentWithZWrite",extension.transparentWithZWrite),assignHelper.assignColor("shadeColorFactor",extension.shadeColorFactor),assignHelper.assignTexture("shadeMultiplyTexture",extension.shadeMultiplyTexture,!0),assignHelper.assignPrimitive("shadingShiftFactor",extension.shadingShiftFactor),assignHelper.assignTexture("shadingShiftTexture",extension.shadingShiftTexture,!0),assignHelper.assignPrimitive("shadingShiftTextureScale",(_a=extension.shadingShiftTexture)==null?void 0:_a.scale),assignHelper.assignPrimitive("shadingToonyFactor",extension.shadingToonyFactor),assignHelper.assignPrimitive("giEqualizationFactor",extension.giEqualizationFactor),assignHelper.assignColor("matcapFactor",extension.matcapFactor),assignHelper.assignTexture("matcapTexture",extension.matcapTexture,!0),assignHelper.assignColor("parametricRimColorFactor",extension.parametricRimColorFactor),assignHelper.assignTexture("rimMultiplyTexture",extension.rimMultiplyTexture,!0),assignHelper.assignPrimitive("rimLightingMixFactor",extension.rimLightingMixFactor),assignHelper.assignPrimitive("parametricRimFresnelPowerFactor",extension.parametricRimFresnelPowerFactor),assignHelper.assignPrimitive("parametricRimLiftFactor",extension.parametricRimLiftFactor),assignHelper.assignPrimitive("outlineWidthMode",extension.outlineWidthMode),assignHelper.assignPrimitive("outlineWidthFactor",extension.outlineWidthFactor),assignHelper.assignTexture("outlineWidthMultiplyTexture",extension.outlineWidthMultiplyTexture,!1),assignHelper.assignColor("outlineColorFactor",extension.outlineColorFactor),assignHelper.assignPrimitive("outlineLightingMixFactor",extension.outlineLightingMixFactor),assignHelper.assignTexture("uvAnimationMaskTexture",extension.uvAnimationMaskTexture,!1),assignHelper.assignPrimitive("uvAnimationScrollXSpeedFactor",extension.uvAnimationScrollXSpeedFactor),assignHelper.assignPrimitive("uvAnimationScrollYSpeedFactor",extension.uvAnimationScrollYSpeedFactor),assignHelper.assignPrimitive("uvAnimationRotationSpeedFactor",extension.uvAnimationRotationSpeedFactor),assignHelper.assignPrimitive("v0CompatShade",this.v0CompatShade),assignHelper.assignPrimitive("debugMode",this.debugMode),yield assignHelper.pending})}_setupPrimitive(mesh,materialIndex){let extension=this._getMToonExtension(materialIndex);if(extension){let renderOrder=this._parseRenderOrder(extension);mesh.renderOrder=renderOrder+this.renderOrderOffset,this._generateOutline(mesh),this._addToMaterialSet(mesh);return}}_shouldGenerateOutline(surfaceMaterial){return typeof surfaceMaterial.outlineWidthMode==="string"&&surfaceMaterial.outlineWidthMode!=="none"&&typeof surfaceMaterial.outlineWidthFactor==="number"&&surfaceMaterial.outlineWidthFactor>0}_generateOutline(mesh){let surfaceMaterial=mesh.material;if(!(surfaceMaterial instanceof Material))return;if(!this._shouldGenerateOutline(surfaceMaterial))return;mesh.material=[surfaceMaterial];let outlineMaterial=surfaceMaterial.clone();outlineMaterial.name+=" (Outline)",outlineMaterial.isOutline=!0,outlineMaterial.side=BackSide,mesh.material.push(outlineMaterial);let geometry=mesh.geometry,primitiveVertices=geometry.index?geometry.index.count:geometry.attributes.position.count/3;geometry.addGroup(0,primitiveVertices,0),geometry.addGroup(0,primitiveVertices,1)}_addToMaterialSet(mesh){let materialOrMaterials=mesh.material,materialSet=new Set;if(Array.isArray(materialOrMaterials))materialOrMaterials.forEach((material)=>materialSet.add(material));else materialSet.add(materialOrMaterials);for(let material of materialSet)this._mToonMaterialSet.add(material)}_parseRenderOrder(extension){var _a;return(extension.transparentWithZWrite?0:19)+((_a=extension.renderQueueOffsetNumber)!=null?_a:0)}};_MToonMaterialLoaderPlugin.EXTENSION_NAME="VRMC_materials_mtoon";var __async4=(__this,__arguments,generator)=>{return new Promise((resolve,reject)=>{var fulfilled=(value)=>{try{step(generator.next(value))}catch(e){reject(e)}},rejected=(value)=>{try{step(generator.throw(value))}catch(e){reject(e)}},step=(x)=>x.done?resolve(x.value):Promise.resolve(x.value).then(fulfilled,rejected);step((generator=generator.apply(__this,__arguments)).next())})},_VRMMaterialsHDREmissiveMultiplierLoaderPlugin=class _VRMMaterialsHDREmissiveMultiplierLoaderPlugin2{get name(){return _VRMMaterialsHDREmissiveMultiplierLoaderPlugin2.EXTENSION_NAME}constructor(parser){this.parser=parser}extendMaterialParams(materialIndex,materialParams){return __async4(this,null,function*(){let extension=this._getHDREmissiveMultiplierExtension(materialIndex);if(extension==null)return;console.warn("VRMMaterialsHDREmissiveMultiplierLoaderPlugin: `VRMC_materials_hdr_emissiveMultiplier` is archived. Use `KHR_materials_emissive_strength` instead.");let emissiveMultiplier=extension.emissiveMultiplier;materialParams.emissiveIntensity=emissiveMultiplier})}_getHDREmissiveMultiplierExtension(materialIndex){var _a,_b;let materialDef=(_a=this.parser.json.materials)==null?void 0:_a[materialIndex];if(materialDef==null){console.warn(`VRMMaterialsHDREmissiveMultiplierLoaderPlugin: Attempt to use materials[${materialIndex}] of glTF but the material doesn't exist`);return}let extension=(_b=materialDef.extensions)==null?void 0:_b[_VRMMaterialsHDREmissiveMultiplierLoaderPlugin2.EXTENSION_NAME];if(extension==null)return;return extension}};_VRMMaterialsHDREmissiveMultiplierLoaderPlugin.EXTENSION_NAME="VRMC_materials_hdr_emissiveMultiplier";var __async6=(__this,__arguments,generator)=>{return new Promise((resolve,reject)=>{var fulfilled=(value)=>{try{step(generator.next(value))}catch(e){reject(e)}},rejected=(value)=>{try{step(generator.throw(value))}catch(e){reject(e)}},step=(x)=>x.done?resolve(x.value):Promise.resolve(x.value).then(fulfilled,rejected);step((generator=generator.apply(__this,__arguments)).next())})},_v3A6=new Vector3,VRMNodeConstraintHelper=class extends Group{constructor(constraint){super();this._attrPosition=new BufferAttribute(new Float32Array([0,0,0,0,0,0]),3),this._attrPosition.setUsage(DynamicDrawUsage);let geometry=new BufferGeometry;geometry.setAttribute("position",this._attrPosition);let material=new LineBasicMaterial({color:16711935,depthTest:!1,depthWrite:!1});this._line=new Line(geometry,material),this.add(this._line),this.constraint=constraint}updateMatrixWorld(force){if(_v3A6.setFromMatrixPosition(this.constraint.destination.matrixWorld),this._attrPosition.setXYZ(0,_v3A6.x,_v3A6.y,_v3A6.z),this.constraint.source)_v3A6.setFromMatrixPosition(this.constraint.source.matrixWorld);this._attrPosition.setXYZ(1,_v3A6.x,_v3A6.y,_v3A6.z),this._attrPosition.needsUpdate=!0,super.updateMatrixWorld(force)}};function decomposePosition(matrix,target){return target.set(matrix.elements[12],matrix.elements[13],matrix.elements[14])}var _v3A22=new Vector3,_v3B4=new Vector3;function decomposeRotation(matrix,target){return matrix.decompose(_v3A22,target,_v3B4),target}function quatInvertCompat2(target){if(target.invert)target.invert();else target.inverse();return target}var VRMNodeConstraint=class{constructor(destination,source){this.destination=destination,this.source=source,this.weight=1}},_v3A32=new Vector3,_v3B22=new Vector3,_v3C2=new Vector3,_quatA7=new Quaternion,_quatB4=new Quaternion,_quatC2=new Quaternion,VRMAimConstraint=class extends VRMNodeConstraint{get aimAxis(){return this._aimAxis}set aimAxis(aimAxis){this._aimAxis=aimAxis,this._v3AimAxis.set(aimAxis==="PositiveX"?1:aimAxis==="NegativeX"?-1:0,aimAxis==="PositiveY"?1:aimAxis==="NegativeY"?-1:0,aimAxis==="PositiveZ"?1:aimAxis==="NegativeZ"?-1:0)}get dependencies(){let set=new Set([this.source]);if(this.destination.parent)set.add(this.destination.parent);return set}constructor(destination,source){super(destination,source);this._aimAxis="PositiveX",this._v3AimAxis=new Vector3(1,0,0),this._dstRestQuat=new Quaternion}setInitState(){this._dstRestQuat.copy(this.destination.quaternion)}update(){this.destination.updateWorldMatrix(!0,!1),this.source.updateWorldMatrix(!0,!1);let dstParentWorldQuat=_quatA7.identity(),invDstParentWorldQuat=_quatB4.identity();if(this.destination.parent)decomposeRotation(this.destination.parent.matrixWorld,dstParentWorldQuat),quatInvertCompat2(invDstParentWorldQuat.copy(dstParentWorldQuat));let a0=_v3A32.copy(this._v3AimAxis).applyQuaternion(this._dstRestQuat).applyQuaternion(dstParentWorldQuat),a1=decomposePosition(this.source.matrixWorld,_v3B22).sub(decomposePosition(this.destination.matrixWorld,_v3C2)).normalize(),targetQuat=_quatC2.setFromUnitVectors(a0,a1).premultiply(invDstParentWorldQuat).multiply(dstParentWorldQuat).multiply(this._dstRestQuat);this.destination.quaternion.copy(this._dstRestQuat).slerp(targetQuat,this.weight)}};function traverseAncestorsFromRoot(object,callback){let ancestors=[object],head=object.parent;while(head!==null)ancestors.unshift(head),head=head.parent;ancestors.forEach((ancestor)=>{callback(ancestor)})}var VRMNodeConstraintManager=class{constructor(){this._constraints=new Set,this._objectConstraintsMap=new Map}get constraints(){return this._constraints}addConstraint(constraint){this._constraints.add(constraint);let objectSet=this._objectConstraintsMap.get(constraint.destination);if(objectSet==null)objectSet=new Set,this._objectConstraintsMap.set(constraint.destination,objectSet);objectSet.add(constraint)}deleteConstraint(constraint){this._constraints.delete(constraint),this._objectConstraintsMap.get(constraint.destination).delete(constraint)}setInitState(){let constraintsTried=new Set,constraintsDone=new Set;for(let constraint of this._constraints)this._processConstraint(constraint,constraintsTried,constraintsDone,(constraint2)=>constraint2.setInitState())}update(){let constraintsTried=new Set,constraintsDone=new Set;for(let constraint of this._constraints)this._processConstraint(constraint,constraintsTried,constraintsDone,(constraint2)=>constraint2.update())}_processConstraint(constraint,constraintsTried,constraintsDone,callback){if(constraintsDone.has(constraint))return;if(constraintsTried.has(constraint))throw Error("VRMNodeConstraintManager: Circular dependency detected while updating constraints");constraintsTried.add(constraint);let depObjects=constraint.dependencies;for(let depObject of depObjects)traverseAncestorsFromRoot(depObject,(depObjectAncestor)=>{let objectSet=this._objectConstraintsMap.get(depObjectAncestor);if(objectSet)for(let depConstraint of objectSet)this._processConstraint(depConstraint,constraintsTried,constraintsDone,callback)});callback(constraint),constraintsDone.add(constraint)}},_quatA22=new Quaternion,_quatB22=new Quaternion,VRMRotationConstraint=class extends VRMNodeConstraint{get dependencies(){return new Set([this.source])}constructor(destination,source){super(destination,source);this._dstRestQuat=new Quaternion,this._invSrcRestQuat=new Quaternion}setInitState(){this._dstRestQuat.copy(this.destination.quaternion),quatInvertCompat2(this._invSrcRestQuat.copy(this.source.quaternion))}update(){let srcDeltaQuat=_quatA22.copy(this._invSrcRestQuat).multiply(this.source.quaternion),targetQuat=_quatB22.copy(this._dstRestQuat).multiply(srcDeltaQuat);this.destination.quaternion.copy(this._dstRestQuat).slerp(targetQuat,this.weight)}},_v3A42=new Vector3,_quatA32=new Quaternion,_quatB32=new Quaternion,VRMRollConstraint=class extends VRMNodeConstraint{get rollAxis(){return this._rollAxis}set rollAxis(rollAxis){this._rollAxis=rollAxis,this._v3RollAxis.set(rollAxis==="X"?1:0,rollAxis==="Y"?1:0,rollAxis==="Z"?1:0)}get dependencies(){return new Set([this.source])}constructor(destination,source){super(destination,source);this._rollAxis="X",this._v3RollAxis=new Vector3(1,0,0),this._dstRestQuat=new Quaternion,this._invDstRestQuat=new Quaternion,this._invSrcRestQuatMulDstRestQuat=new Quaternion}setInitState(){this._dstRestQuat.copy(this.destination.quaternion),quatInvertCompat2(this._invDstRestQuat.copy(this._dstRestQuat)),quatInvertCompat2(this._invSrcRestQuatMulDstRestQuat.copy(this.source.quaternion)).multiply(this._dstRestQuat)}update(){let quatDelta=_quatA32.copy(this._invDstRestQuat).multiply(this.source.quaternion).multiply(this._invSrcRestQuatMulDstRestQuat),n1=_v3A42.copy(this._v3RollAxis).applyQuaternion(quatDelta),targetQuat=_quatB32.setFromUnitVectors(n1,this._v3RollAxis).premultiply(this._dstRestQuat).multiply(quatDelta);this.destination.quaternion.copy(this._dstRestQuat).slerp(targetQuat,this.weight)}},POSSIBLE_SPEC_VERSIONS7=new Set(["1.0","1.0-beta"]),_VRMNodeConstraintLoaderPlugin=class _VRMNodeConstraintLoaderPlugin2{get name(){return _VRMNodeConstraintLoaderPlugin2.EXTENSION_NAME}constructor(parser,options){this.parser=parser,this.helperRoot=options==null?void 0:options.helperRoot}afterRoot(gltf){return __async6(this,null,function*(){gltf.userData.vrmNodeConstraintManager=yield this.___v2Import(gltf)})}___v2Import(gltf){return __async6(this,null,function*(){var _a;let json=this.parser.json;if(((_a=json.extensionsUsed)==null?void 0:_a.indexOf(_VRMNodeConstraintLoaderPlugin2.EXTENSION_NAME))===-1)return null;let manager=new VRMNodeConstraintManager,threeNodes=yield this.parser.getDependencies("node");return threeNodes.forEach((node,nodeIndex)=>{var _a2;let schemaNode=json.nodes[nodeIndex],extension=(_a2=schemaNode==null?void 0:schemaNode.extensions)==null?void 0:_a2[_VRMNodeConstraintLoaderPlugin2.EXTENSION_NAME];if(extension==null)return;let specVersion=extension.specVersion;if(!POSSIBLE_SPEC_VERSIONS7.has(specVersion)){console.warn(`VRMNodeConstraintLoaderPlugin: Unknown ${_VRMNodeConstraintLoaderPlugin2.EXTENSION_NAME} specVersion "${specVersion}"`);return}let constraintDef=extension.constraint;if(constraintDef.roll!=null){let constraint=this._importRollConstraint(node,threeNodes,constraintDef.roll);manager.addConstraint(constraint)}else if(constraintDef.aim!=null){let constraint=this._importAimConstraint(node,threeNodes,constraintDef.aim);manager.addConstraint(constraint)}else if(constraintDef.rotation!=null){let constraint=this._importRotationConstraint(node,threeNodes,constraintDef.rotation);manager.addConstraint(constraint)}}),gltf.scene.updateMatrixWorld(),manager.setInitState(),manager})}_importRollConstraint(destination,nodes,rollConstraintDef){let{source:sourceIndex,rollAxis,weight}=rollConstraintDef,source=nodes[sourceIndex],constraint=new VRMRollConstraint(destination,source);if(rollAxis!=null)constraint.rollAxis=rollAxis;if(weight!=null)constraint.weight=weight;if(this.helperRoot){let helper=new VRMNodeConstraintHelper(constraint);this.helperRoot.add(helper)}return constraint}_importAimConstraint(destination,nodes,aimConstraintDef){let{source:sourceIndex,aimAxis,weight}=aimConstraintDef,source=nodes[sourceIndex],constraint=new VRMAimConstraint(destination,source);if(aimAxis!=null)constraint.aimAxis=aimAxis;if(weight!=null)constraint.weight=weight;if(this.helperRoot){let helper=new VRMNodeConstraintHelper(constraint);this.helperRoot.add(helper)}return constraint}_importRotationConstraint(destination,nodes,rotationConstraintDef){let{source:sourceIndex,weight}=rotationConstraintDef,source=nodes[sourceIndex],constraint=new VRMRotationConstraint(destination,source);if(weight!=null)constraint.weight=weight;if(this.helperRoot){let helper=new VRMNodeConstraintHelper(constraint);this.helperRoot.add(helper)}return constraint}};_VRMNodeConstraintLoaderPlugin.EXTENSION_NAME="VRMC_node_constraint";var __async7=(__this,__arguments,generator)=>{return new Promise((resolve,reject)=>{var fulfilled=(value)=>{try{step(generator.next(value))}catch(e){reject(e)}},rejected=(value)=>{try{step(generator.throw(value))}catch(e){reject(e)}},step=(x)=>x.done?resolve(x.value):Promise.resolve(x.value).then(fulfilled,rejected);step((generator=generator.apply(__this,__arguments)).next())})},VRMSpringBoneColliderShape=class{},_v3A7=new Vector3,_v3B5=new Vector3,VRMSpringBoneColliderShapeCapsule=class extends VRMSpringBoneColliderShape{get type(){return"capsule"}constructor(params){var _a,_b,_c,_d;super();this.offset=(_a=params==null?void 0:params.offset)!=null?_a:new Vector3(0,0,0),this.tail=(_b=params==null?void 0:params.tail)!=null?_b:new Vector3(0,0,0),this.radius=(_c=params==null?void 0:params.radius)!=null?_c:0,this.inside=(_d=params==null?void 0:params.inside)!=null?_d:!1}calculateCollision(colliderMatrix,objectPosition,objectRadius,target){_v3A7.setFromMatrixPosition(colliderMatrix),_v3B5.subVectors(this.tail,this.offset).applyMatrix4(colliderMatrix),_v3B5.sub(_v3A7);let lengthSqCapsule=_v3B5.lengthSq();target.copy(objectPosition).sub(_v3A7);let dot=_v3B5.dot(target);if(dot<=0);else if(lengthSqCapsule<=dot)target.sub(_v3B5);else _v3B5.multiplyScalar(dot/lengthSqCapsule),target.sub(_v3B5);let length=target.length(),distance=this.inside?this.radius-objectRadius-length:length-objectRadius-this.radius;if(distance<0){if(target.multiplyScalar(1/length),this.inside)target.negate()}return distance}},_v3A23=new Vector3,_mat3A=new Matrix3,VRMSpringBoneColliderShapePlane=class extends VRMSpringBoneColliderShape{get type(){return"plane"}constructor(params){var _a,_b;super();this.offset=(_a=params==null?void 0:params.offset)!=null?_a:new Vector3(0,0,0),this.normal=(_b=params==null?void 0:params.normal)!=null?_b:new Vector3(0,0,1)}calculateCollision(colliderMatrix,objectPosition,objectRadius,target){target.setFromMatrixPosition(colliderMatrix),target.negate().add(objectPosition),_mat3A.getNormalMatrix(colliderMatrix),_v3A23.copy(this.normal).applyNormalMatrix(_mat3A).normalize();let distance=target.dot(_v3A23)-objectRadius;return target.copy(_v3A23),distance}},_v3A33=new Vector3,VRMSpringBoneColliderShapeSphere=class extends VRMSpringBoneColliderShape{get type(){return"sphere"}constructor(params){var _a,_b,_c;super();this.offset=(_a=params==null?void 0:params.offset)!=null?_a:new Vector3(0,0,0),this.radius=(_b=params==null?void 0:params.radius)!=null?_b:0,this.inside=(_c=params==null?void 0:params.inside)!=null?_c:!1}calculateCollision(colliderMatrix,objectPosition,objectRadius,target){target.subVectors(objectPosition,_v3A33.setFromMatrixPosition(colliderMatrix));let length=target.length(),distance=this.inside?this.radius-objectRadius-length:length-objectRadius-this.radius;if(distance<0){if(target.multiplyScalar(1/length),this.inside)target.negate()}return distance}},_v3A43=new Vector3,ColliderShapeCapsuleBufferGeometry=class extends BufferGeometry{constructor(shape){super();this.worldScale=1,this._currentRadius=0,this._currentOffset=new Vector3,this._currentTail=new Vector3,this._shape=shape,this._attrPos=new BufferAttribute(new Float32Array(396),3),this.setAttribute("position",this._attrPos),this._attrIndex=new BufferAttribute(new Uint16Array(264),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let shouldUpdateGeometry=!1,radius=this._shape.radius/this.worldScale;if(this._currentRadius!==radius)this._currentRadius=radius,shouldUpdateGeometry=!0;if(!this._currentOffset.equals(this._shape.offset))this._currentOffset.copy(this._shape.offset),shouldUpdateGeometry=!0;let tail=_v3A43.copy(this._shape.tail).divideScalar(this.worldScale);if(this._currentTail.distanceToSquared(tail)>0.0000000001)this._currentTail.copy(tail),shouldUpdateGeometry=!0;if(shouldUpdateGeometry)this._buildPosition()}_buildPosition(){_v3A43.copy(this._currentTail).sub(this._currentOffset);let l=_v3A43.length()/this._currentRadius;for(let i=0;i<=16;i++){let t=i/16*Math.PI;this._attrPos.setXYZ(i,-Math.sin(t),-Math.cos(t),0),this._attrPos.setXYZ(17+i,l+Math.sin(t),Math.cos(t),0),this._attrPos.setXYZ(34+i,-Math.sin(t),0,-Math.cos(t)),this._attrPos.setXYZ(51+i,l+Math.sin(t),0,Math.cos(t))}for(let i=0;i<32;i++){let t=i/16*Math.PI;this._attrPos.setXYZ(68+i,0,Math.sin(t),Math.cos(t)),this._attrPos.setXYZ(100+i,l,Math.sin(t),Math.cos(t))}let theta=Math.atan2(_v3A43.y,Math.sqrt(_v3A43.x*_v3A43.x+_v3A43.z*_v3A43.z)),phi=-Math.atan2(_v3A43.z,_v3A43.x);this.rotateZ(theta),this.rotateY(phi),this.scale(this._currentRadius,this._currentRadius,this._currentRadius),this.translate(this._currentOffset.x,this._currentOffset.y,this._currentOffset.z),this._attrPos.needsUpdate=!0}_buildIndex(){for(let i=0;i<34;i++){let i1=(i+1)%34;this._attrIndex.setXY(i*2,i,i1),this._attrIndex.setXY(68+i*2,34+i,34+i1)}for(let i=0;i<32;i++){let i1=(i+1)%32;this._attrIndex.setXY(136+i*2,68+i,68+i1),this._attrIndex.setXY(200+i*2,100+i,100+i1)}this._attrIndex.needsUpdate=!0}},ColliderShapePlaneBufferGeometry=class extends BufferGeometry{constructor(shape){super();this.worldScale=1,this._currentOffset=new Vector3,this._currentNormal=new Vector3,this._shape=shape,this._attrPos=new BufferAttribute(new Float32Array(18),3),this.setAttribute("position",this._attrPos),this._attrIndex=new BufferAttribute(new Uint16Array(10),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let shouldUpdateGeometry=!1;if(!this._currentOffset.equals(this._shape.offset))this._currentOffset.copy(this._shape.offset),shouldUpdateGeometry=!0;if(!this._currentNormal.equals(this._shape.normal))this._currentNormal.copy(this._shape.normal),shouldUpdateGeometry=!0;if(shouldUpdateGeometry)this._buildPosition()}_buildPosition(){this._attrPos.setXYZ(0,-0.5,-0.5,0),this._attrPos.setXYZ(1,0.5,-0.5,0),this._attrPos.setXYZ(2,0.5,0.5,0),this._attrPos.setXYZ(3,-0.5,0.5,0),this._attrPos.setXYZ(4,0,0,0),this._attrPos.setXYZ(5,0,0,0.25),this.translate(this._currentOffset.x,this._currentOffset.y,this._currentOffset.z),this.lookAt(this._currentNormal),this._attrPos.needsUpdate=!0}_buildIndex(){this._attrIndex.setXY(0,0,1),this._attrIndex.setXY(2,1,2),this._attrIndex.setXY(4,2,3),this._attrIndex.setXY(6,3,0),this._attrIndex.setXY(8,4,5),this._attrIndex.needsUpdate=!0}},ColliderShapeSphereBufferGeometry=class extends BufferGeometry{constructor(shape){super();this.worldScale=1,this._currentRadius=0,this._currentOffset=new Vector3,this._shape=shape,this._attrPos=new BufferAttribute(new Float32Array(288),3),this.setAttribute("position",this._attrPos),this._attrIndex=new BufferAttribute(new Uint16Array(192),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let shouldUpdateGeometry=!1,radius=this._shape.radius/this.worldScale;if(this._currentRadius!==radius)this._currentRadius=radius,shouldUpdateGeometry=!0;if(!this._currentOffset.equals(this._shape.offset))this._currentOffset.copy(this._shape.offset),shouldUpdateGeometry=!0;if(shouldUpdateGeometry)this._buildPosition()}_buildPosition(){for(let i=0;i<32;i++){let t=i/16*Math.PI;this._attrPos.setXYZ(i,Math.cos(t),Math.sin(t),0),this._attrPos.setXYZ(32+i,0,Math.cos(t),Math.sin(t)),this._attrPos.setXYZ(64+i,Math.sin(t),0,Math.cos(t))}this.scale(this._currentRadius,this._currentRadius,this._currentRadius),this.translate(this._currentOffset.x,this._currentOffset.y,this._currentOffset.z),this._attrPos.needsUpdate=!0}_buildIndex(){for(let i=0;i<32;i++){let i1=(i+1)%32;this._attrIndex.setXY(i*2,i,i1),this._attrIndex.setXY(64+i*2,32+i,32+i1),this._attrIndex.setXY(128+i*2,64+i,64+i1)}this._attrIndex.needsUpdate=!0}},_v3A52=new Vector3,VRMSpringBoneColliderHelper=class extends Group{constructor(collider){super();if(this.matrixAutoUpdate=!1,this.collider=collider,this.collider.shape instanceof VRMSpringBoneColliderShapeSphere)this._geometry=new ColliderShapeSphereBufferGeometry(this.collider.shape);else if(this.collider.shape instanceof VRMSpringBoneColliderShapeCapsule)this._geometry=new ColliderShapeCapsuleBufferGeometry(this.collider.shape);else if(this.collider.shape instanceof VRMSpringBoneColliderShapePlane)this._geometry=new ColliderShapePlaneBufferGeometry(this.collider.shape);else throw Error("VRMSpringBoneColliderHelper: Unknown collider shape type detected");let material=new LineBasicMaterial({color:16711935,depthTest:!1,depthWrite:!1});this._line=new LineSegments(this._geometry,material),this.add(this._line)}dispose(){this._geometry.dispose()}updateMatrixWorld(force){this.collider.updateWorldMatrix(!0,!1),this.matrix.copy(this.collider.matrixWorld);let matrixWorldElements=this.matrix.elements;this._geometry.worldScale=_v3A52.set(matrixWorldElements[0],matrixWorldElements[1],matrixWorldElements[2]).length(),this._geometry.update(),super.updateMatrixWorld(force)}},SpringBoneBufferGeometry=class extends BufferGeometry{constructor(springBone){super();this.worldScale=1,this._currentRadius=0,this._currentTail=new Vector3,this._springBone=springBone,this._attrPos=new BufferAttribute(new Float32Array(294),3),this.setAttribute("position",this._attrPos),this._attrIndex=new BufferAttribute(new Uint16Array(194),1),this.setIndex(this._attrIndex),this._buildIndex(),this.update()}update(){let shouldUpdateGeometry=!1,radius=this._springBone.settings.hitRadius/this.worldScale;if(this._currentRadius!==radius)this._currentRadius=radius,shouldUpdateGeometry=!0;if(!this._currentTail.equals(this._springBone.initialLocalChildPosition))this._currentTail.copy(this._springBone.initialLocalChildPosition),shouldUpdateGeometry=!0;if(shouldUpdateGeometry)this._buildPosition()}_buildPosition(){for(let i=0;i<32;i++){let t=i/16*Math.PI;this._attrPos.setXYZ(i,Math.cos(t),Math.sin(t),0),this._attrPos.setXYZ(32+i,0,Math.cos(t),Math.sin(t)),this._attrPos.setXYZ(64+i,Math.sin(t),0,Math.cos(t))}this.scale(this._currentRadius,this._currentRadius,this._currentRadius),this.translate(this._currentTail.x,this._currentTail.y,this._currentTail.z),this._attrPos.setXYZ(96,0,0,0),this._attrPos.setXYZ(97,this._currentTail.x,this._currentTail.y,this._currentTail.z),this._attrPos.needsUpdate=!0}_buildIndex(){for(let i=0;i<32;i++){let i1=(i+1)%32;this._attrIndex.setXY(i*2,i,i1),this._attrIndex.setXY(64+i*2,32+i,32+i1),this._attrIndex.setXY(128+i*2,64+i,64+i1)}this._attrIndex.setXY(192,96,97),this._attrIndex.needsUpdate=!0}},_v3A62=new Vector3,VRMSpringBoneJointHelper=class extends Group{constructor(springBone){super();this.matrixAutoUpdate=!1,this.springBone=springBone,this._geometry=new SpringBoneBufferGeometry(this.springBone);let material=new LineBasicMaterial({color:16776960,depthTest:!1,depthWrite:!1});this._line=new LineSegments(this._geometry,material),this.add(this._line)}dispose(){this._geometry.dispose()}updateMatrixWorld(force){this.springBone.bone.updateWorldMatrix(!0,!1),this.matrix.copy(this.springBone.bone.matrixWorld);let matrixWorldElements=this.matrix.elements;this._geometry.worldScale=_v3A62.set(matrixWorldElements[0],matrixWorldElements[1],matrixWorldElements[2]).length(),this._geometry.update(),super.updateMatrixWorld(force)}},VRMSpringBoneCollider=class extends Object3D{constructor(shape){super();this.colliderMatrix=new Matrix4,this.shape=shape}updateWorldMatrix(updateParents,updateChildren){super.updateWorldMatrix(updateParents,updateChildren),updateColliderMatrix(this.colliderMatrix,this.matrixWorld,this.shape.offset)}};function updateColliderMatrix(colliderMatrix,matrixWorld,offset){let me=matrixWorld.elements;if(colliderMatrix.copy(matrixWorld),offset)colliderMatrix.elements[12]=me[0]*offset.x+me[4]*offset.y+me[8]*offset.z+me[12],colliderMatrix.elements[13]=me[1]*offset.x+me[5]*offset.y+me[9]*offset.z+me[13],colliderMatrix.elements[14]=me[2]*offset.x+me[6]*offset.y+me[10]*offset.z+me[14]}var _matA=new Matrix4;function mat4InvertCompat(target){if(target.invert)target.invert();else target.getInverse(_matA.copy(target));return target}var Matrix4InverseCache=class{constructor(matrix){this._inverseCache=new Matrix4,this._shouldUpdateInverse=!0,this.matrix=matrix;let handler={set:(obj,prop,newVal)=>{return this._shouldUpdateInverse=!0,obj[prop]=newVal,!0}};this._originalElements=matrix.elements,matrix.elements=new Proxy(matrix.elements,handler)}get inverse(){if(this._shouldUpdateInverse)mat4InvertCompat(this._inverseCache.copy(this.matrix)),this._shouldUpdateInverse=!1;return this._inverseCache}revert(){this.matrix.elements=this._originalElements}},IDENTITY_MATRIX4=new Matrix4,_v3A72=new Vector3,_v3B23=new Vector3,_worldSpacePosition=new Vector3,_nextTail=new Vector3,_matA2=new Matrix4,VRMSpringBoneJoint=class{constructor(bone,child,settings={},colliderGroups=[]){this._currentTail=new Vector3,this._prevTail=new Vector3,this._boneAxis=new Vector3,this._worldSpaceBoneLength=0,this._center=null,this._initialLocalMatrix=new Matrix4,this._initialLocalRotation=new Quaternion,this._initialLocalChildPosition=new Vector3;var _a,_b,_c,_d,_e,_f;this.bone=bone,this.bone.matrixAutoUpdate=!1,this.child=child,this.settings={hitRadius:(_a=settings.hitRadius)!=null?_a:0,stiffness:(_b=settings.stiffness)!=null?_b:1,gravityPower:(_c=settings.gravityPower)!=null?_c:0,gravityDir:(_e=(_d=settings.gravityDir)==null?void 0:_d.clone())!=null?_e:new Vector3(0,-1,0),dragForce:(_f=settings.dragForce)!=null?_f:0.4},this.colliderGroups=colliderGroups}get dependencies(){let set=new Set,parent=this.bone.parent;if(parent)set.add(parent);for(let cg=0;cg<this.colliderGroups.length;cg++)for(let c=0;c<this.colliderGroups[cg].colliders.length;c++)set.add(this.colliderGroups[cg].colliders[c]);return set}get center(){return this._center}set center(center){var _a;if((_a=this._center)==null?void 0:_a.userData.inverseCacheProxy)this._center.userData.inverseCacheProxy.revert(),delete this._center.userData.inverseCacheProxy;if(this._center=center,this._center){if(!this._center.userData.inverseCacheProxy)this._center.userData.inverseCacheProxy=new Matrix4InverseCache(this._center.matrixWorld)}}get initialLocalChildPosition(){return this._initialLocalChildPosition}get _parentMatrixWorld(){return this.bone.parent?this.bone.parent.matrixWorld:IDENTITY_MATRIX4}setInitState(){if(this._initialLocalMatrix.copy(this.bone.matrix),this._initialLocalRotation.copy(this.bone.quaternion),this.child)this._initialLocalChildPosition.copy(this.child.position);else this._initialLocalChildPosition.copy(this.bone.position).normalize().multiplyScalar(0.07);let matrixWorldToCenter=this._getMatrixWorldToCenter();this.bone.localToWorld(this._currentTail.copy(this._initialLocalChildPosition)).applyMatrix4(matrixWorldToCenter),this._prevTail.copy(this._currentTail),this._boneAxis.copy(this._initialLocalChildPosition).normalize()}reset(){this.bone.quaternion.copy(this._initialLocalRotation),this.bone.updateMatrix(),this.bone.matrixWorld.multiplyMatrices(this._parentMatrixWorld,this.bone.matrix);let matrixWorldToCenter=this._getMatrixWorldToCenter();this.bone.localToWorld(this._currentTail.copy(this._initialLocalChildPosition)).applyMatrix4(matrixWorldToCenter),this._prevTail.copy(this._currentTail)}update(delta){if(delta<=0)return;this._calcWorldSpaceBoneLength();let worldSpaceBoneAxis=_v3B23.copy(this._boneAxis).transformDirection(this._initialLocalMatrix).transformDirection(this._parentMatrixWorld);_nextTail.copy(this._currentTail).add(_v3A72.subVectors(this._currentTail,this._prevTail).multiplyScalar(1-this.settings.dragForce)).applyMatrix4(this._getMatrixCenterToWorld()).addScaledVector(worldSpaceBoneAxis,this.settings.stiffness*delta).addScaledVector(this.settings.gravityDir,this.settings.gravityPower*delta),_worldSpacePosition.setFromMatrixPosition(this.bone.matrixWorld),_nextTail.sub(_worldSpacePosition).normalize().multiplyScalar(this._worldSpaceBoneLength).add(_worldSpacePosition),this._collision(_nextTail),this._prevTail.copy(this._currentTail),this._currentTail.copy(_nextTail).applyMatrix4(this._getMatrixWorldToCenter());let worldSpaceInitialMatrixInv=_matA2.multiplyMatrices(this._parentMatrixWorld,this._initialLocalMatrix).invert();this.bone.quaternion.setFromUnitVectors(this._boneAxis,_v3A72.copy(_nextTail).applyMatrix4(worldSpaceInitialMatrixInv).normalize()).premultiply(this._initialLocalRotation),this.bone.updateMatrix(),this.bone.matrixWorld.multiplyMatrices(this._parentMatrixWorld,this.bone.matrix)}_collision(tail){for(let cg=0;cg<this.colliderGroups.length;cg++)for(let c=0;c<this.colliderGroups[cg].colliders.length;c++){let collider=this.colliderGroups[cg].colliders[c],dist=collider.shape.calculateCollision(collider.colliderMatrix,tail,this.settings.hitRadius,_v3A72);if(dist<0){tail.addScaledVector(_v3A72,-dist),tail.sub(_worldSpacePosition);let length=tail.length();tail.multiplyScalar(this._worldSpaceBoneLength/length).add(_worldSpacePosition)}}}_calcWorldSpaceBoneLength(){if(_v3A72.setFromMatrixPosition(this.bone.matrixWorld),this.child)_v3B23.setFromMatrixPosition(this.child.matrixWorld);else _v3B23.copy(this._initialLocalChildPosition),_v3B23.applyMatrix4(this.bone.matrixWorld);this._worldSpaceBoneLength=_v3A72.sub(_v3B23).length()}_getMatrixCenterToWorld(){return this._center?this._center.matrixWorld:IDENTITY_MATRIX4}_getMatrixWorldToCenter(){return this._center?this._center.userData.inverseCacheProxy.inverse:IDENTITY_MATRIX4}};function traverseAncestorsFromRoot2(object,callback){let ancestors=[],head=object;while(head!==null)ancestors.unshift(head),head=head.parent;ancestors.forEach((ancestor)=>{callback(ancestor)})}function traverseChildrenUntilConditionMet(object,callback){object.children.forEach((child)=>{if(!callback(child))traverseChildrenUntilConditionMet(child,callback)})}function lowestCommonAncestor(objects){var _a;let sharedAncestors=new Map;for(let object of objects){let current=object;do{let newValue=((_a=sharedAncestors.get(current))!=null?_a:0)+1;if(newValue===objects.size)return current;sharedAncestors.set(current,newValue),current=current.parent}while(current!==null)}return null}var VRMSpringBoneManager=class{constructor(){this._joints=new Set,this._sortedJoints=[],this._hasWarnedCircularDependency=!1,this._ancestors=[],this._objectSpringBonesMap=new Map,this._isSortedJointsDirty=!1,this._relevantChildrenUpdated=this._relevantChildrenUpdated.bind(this)}get joints(){return this._joints}get springBones(){return console.warn("VRMSpringBoneManager: springBones is deprecated. use joints instead."),this._joints}get colliderGroups(){let set=new Set;return this._joints.forEach((springBone)=>{springBone.colliderGroups.forEach((colliderGroup)=>{set.add(colliderGroup)})}),Array.from(set)}get colliders(){let set=new Set;return this.colliderGroups.forEach((colliderGroup)=>{colliderGroup.colliders.forEach((collider)=>{set.add(collider)})}),Array.from(set)}addJoint(joint){this._joints.add(joint);let objectSet=this._objectSpringBonesMap.get(joint.bone);if(objectSet==null)objectSet=new Set,this._objectSpringBonesMap.set(joint.bone,objectSet);objectSet.add(joint),this._isSortedJointsDirty=!0}addSpringBone(joint){console.warn("VRMSpringBoneManager: addSpringBone() is deprecated. use addJoint() instead."),this.addJoint(joint)}deleteJoint(joint){this._joints.delete(joint),this._objectSpringBonesMap.get(joint.bone).delete(joint),this._isSortedJointsDirty=!0}deleteSpringBone(joint){console.warn("VRMSpringBoneManager: deleteSpringBone() is deprecated. use deleteJoint() instead."),this.deleteJoint(joint)}setInitState(){this._sortJoints();for(let i=0;i<this._sortedJoints.length;i++){let springBone=this._sortedJoints[i];springBone.bone.updateMatrix(),springBone.bone.updateWorldMatrix(!1,!1),springBone.setInitState()}}reset(){this._sortJoints();for(let i=0;i<this._sortedJoints.length;i++){let springBone=this._sortedJoints[i];springBone.bone.updateMatrix(),springBone.bone.updateWorldMatrix(!1,!1),springBone.reset()}}update(delta){this._sortJoints();for(let i=0;i<this._ancestors.length;i++)this._ancestors[i].updateWorldMatrix(i===0,!1);for(let i=0;i<this._sortedJoints.length;i++){let springBone=this._sortedJoints[i];springBone.bone.updateMatrix(),springBone.bone.updateWorldMatrix(!1,!1),springBone.update(delta),traverseChildrenUntilConditionMet(springBone.bone,this._relevantChildrenUpdated)}}_sortJoints(){if(!this._isSortedJointsDirty)return;let springBoneOrder=[],springBonesTried=new Set,springBonesDone=new Set,ancestors=new Set;for(let springBone of this._joints)this._insertJointSort(springBone,springBonesTried,springBonesDone,springBoneOrder,ancestors);this._sortedJoints=springBoneOrder;let lca=lowestCommonAncestor(ancestors);if(this._ancestors=[],lca)this._ancestors.push(lca),traverseChildrenUntilConditionMet(lca,(object)=>{var _a,_b;if(((_b=(_a=this._objectSpringBonesMap.get(object))==null?void 0:_a.size)!=null?_b:0)>0)return!0;return this._ancestors.push(object),!1});this._isSortedJointsDirty=!1}_insertJointSort(springBone,springBonesTried,springBonesDone,springBoneOrder,ancestors){if(springBonesDone.has(springBone))return;if(springBonesTried.has(springBone)){if(!this._hasWarnedCircularDependency)console.warn("VRMSpringBoneManager: Circular dependency detected"),this._hasWarnedCircularDependency=!0;return}springBonesTried.add(springBone);let depObjects=springBone.dependencies;for(let depObject of depObjects){let encounteredSpringBone=!1,ancestor=null;if(traverseAncestorsFromRoot2(depObject,(depObjectAncestor)=>{let objectSet=this._objectSpringBonesMap.get(depObjectAncestor);if(objectSet)for(let depSpringBone of objectSet)encounteredSpringBone=!0,this._insertJointSort(depSpringBone,springBonesTried,springBonesDone,springBoneOrder,ancestors);else if(!encounteredSpringBone)ancestor=depObjectAncestor}),ancestor)ancestors.add(ancestor)}springBoneOrder.push(springBone),springBonesDone.add(springBone)}_relevantChildrenUpdated(object){var _a,_b;if(((_b=(_a=this._objectSpringBonesMap.get(object))==null?void 0:_a.size)!=null?_b:0)>0)return!0;return object.updateWorldMatrix(!1,!1),!1}},EXTENSION_NAME_EXTENDED_COLLIDER="VRMC_springBone_extended_collider",POSSIBLE_SPEC_VERSIONS8=new Set(["1.0","1.0-beta"]),POSSIBLE_SPEC_VERSIONS_EXTENDED_COLLIDERS=new Set(["1.0"]),_VRMSpringBoneLoaderPlugin=class _VRMSpringBoneLoaderPlugin2{get name(){return _VRMSpringBoneLoaderPlugin2.EXTENSION_NAME}constructor(parser,options){var _a;this.parser=parser,this.jointHelperRoot=options==null?void 0:options.jointHelperRoot,this.colliderHelperRoot=options==null?void 0:options.colliderHelperRoot,this.useExtendedColliders=(_a=options==null?void 0:options.useExtendedColliders)!=null?_a:!0}afterRoot(gltf){return __async7(this,null,function*(){gltf.userData.vrmSpringBoneManager=yield this.___v2Import(gltf)})}___v2Import(gltf){return __async7(this,null,function*(){let v1Result=yield this._v1Import(gltf);if(v1Result!=null)return v1Result;let v0Result=yield this._v0Import(gltf);if(v0Result!=null)return v0Result;return null})}_v1Import(gltf){return __async7(this,null,function*(){var _a,_b,_c,_d,_e;let json=gltf.parser.json;if(((_a=json.extensionsUsed)==null?void 0:_a.indexOf(_VRMSpringBoneLoaderPlugin2.EXTENSION_NAME))===-1)return null;let manager=new VRMSpringBoneManager,threeNodes=yield gltf.parser.getDependencies("node"),extension=(_b=json.extensions)==null?void 0:_b[_VRMSpringBoneLoaderPlugin2.EXTENSION_NAME];if(!extension)return null;let specVersion=extension.specVersion;if(!POSSIBLE_SPEC_VERSIONS8.has(specVersion))return console.warn(`VRMSpringBoneLoaderPlugin: Unknown ${_VRMSpringBoneLoaderPlugin2.EXTENSION_NAME} specVersion "${specVersion}"`),null;let colliders=(_c=extension.colliders)==null?void 0:_c.map((schemaCollider,iCollider)=>{var _a2,_b2,_c2,_d2,_e2,_f,_g,_h,_i,_j,_k,_l,_m,_n,_o;let node=threeNodes[schemaCollider.node];if(node==null)return console.warn(`VRMSpringBoneLoaderPlugin: The collider #${iCollider} attempted to reference a node #${schemaCollider.node} but not found. Skipping the collider`),null;let schemaShape=schemaCollider.shape,schemaExCollider=(_a2=schemaCollider.extensions)==null?void 0:_a2[EXTENSION_NAME_EXTENDED_COLLIDER];if(this.useExtendedColliders&&schemaExCollider!=null){let specVersionExCollider=schemaExCollider.specVersion;if(!POSSIBLE_SPEC_VERSIONS_EXTENDED_COLLIDERS.has(specVersionExCollider))console.warn(`VRMSpringBoneLoaderPlugin: Unknown ${EXTENSION_NAME_EXTENDED_COLLIDER} specVersion "${specVersionExCollider}". Fallbacking to the ${_VRMSpringBoneLoaderPlugin2.EXTENSION_NAME} definition`);else{let schemaExShape=schemaExCollider.shape;if(schemaExShape.sphere)return this._importSphereCollider(node,{offset:new Vector3().fromArray((_b2=schemaExShape.sphere.offset)!=null?_b2:[0,0,0]),radius:(_c2=schemaExShape.sphere.radius)!=null?_c2:0,inside:(_d2=schemaExShape.sphere.inside)!=null?_d2:!1});else if(schemaExShape.capsule)return this._importCapsuleCollider(node,{offset:new Vector3().fromArray((_e2=schemaExShape.capsule.offset)!=null?_e2:[0,0,0]),radius:(_f=schemaExShape.capsule.radius)!=null?_f:0,tail:new Vector3().fromArray((_g=schemaExShape.capsule.tail)!=null?_g:[0,0,0]),inside:(_h=schemaExShape.capsule.inside)!=null?_h:!1});else if(schemaExShape.plane)return this._importPlaneCollider(node,{offset:new Vector3().fromArray((_i=schemaExShape.plane.offset)!=null?_i:[0,0,0]),normal:new Vector3().fromArray((_j=schemaExShape.plane.normal)!=null?_j:[0,0,1])})}}if(schemaShape.sphere)return this._importSphereCollider(node,{offset:new Vector3().fromArray((_k=schemaShape.sphere.offset)!=null?_k:[0,0,0]),radius:(_l=schemaShape.sphere.radius)!=null?_l:0,inside:!1});else if(schemaShape.capsule)return this._importCapsuleCollider(node,{offset:new Vector3().fromArray((_m=schemaShape.capsule.offset)!=null?_m:[0,0,0]),radius:(_n=schemaShape.capsule.radius)!=null?_n:0,tail:new Vector3().fromArray((_o=schemaShape.capsule.tail)!=null?_o:[0,0,0]),inside:!1});console.warn(`VRMSpringBoneLoaderPlugin: The collider #${iCollider} has no valid shape. Skipping the collider`)}),colliderGroups=(_d=extension.colliderGroups)==null?void 0:_d.map((schemaColliderGroup,iColliderGroup)=>{var _a2;return{colliders:((_a2=schemaColliderGroup.colliders)!=null?_a2:[]).map((iCollider)=>{let col=colliders==null?void 0:colliders[iCollider];if(col==null)return console.warn(`VRMSpringBoneLoaderPlugin: The collider group #${iColliderGroup} attempted to reference a collider #${iCollider} but not found. Skipping the collider`),null;return col}).filter((col)=>col!=null),name:schemaColliderGroup.name}});return(_e=extension.springs)==null||_e.forEach((schemaSpring,iSpring)=>{var _a2;let schemaJoints=schemaSpring.joints,colliderGroupsForSpring=(_a2=schemaSpring.colliderGroups)==null?void 0:_a2.map((iColliderGroup)=>{let group=colliderGroups==null?void 0:colliderGroups[iColliderGroup];if(group==null)return console.warn(`VRMSpringBoneLoaderPlugin: The spring #${iSpring} attempted to reference a collider group #${iColliderGroup} but not found. Skipping the collider group`),null;return group}).filter((group)=>group!=null),center=schemaSpring.center!=null?threeNodes[schemaSpring.center]:void 0,prevSchemaJoint;schemaJoints.forEach((schemaJoint)=>{if(prevSchemaJoint){let nodeIndex=prevSchemaJoint.node,node=threeNodes[nodeIndex],childIndex=schemaJoint.node,child=threeNodes[childIndex],setting={hitRadius:prevSchemaJoint.hitRadius,dragForce:prevSchemaJoint.dragForce,gravityPower:prevSchemaJoint.gravityPower,stiffness:prevSchemaJoint.stiffness,gravityDir:prevSchemaJoint.gravityDir!=null?new Vector3().fromArray(prevSchemaJoint.gravityDir):void 0},joint=this._importJoint(node,child,setting,colliderGroupsForSpring);if(center)joint.center=center;manager.addJoint(joint)}prevSchemaJoint=schemaJoint})}),manager.setInitState(),manager})}_v0Import(gltf){return __async7(this,null,function*(){var _a,_b,_c;let json=gltf.parser.json;if(((_a=json.extensionsUsed)==null?void 0:_a.indexOf("VRM"))===-1)return null;let extension=(_b=json.extensions)==null?void 0:_b.VRM,schemaSecondaryAnimation=extension==null?void 0:extension.secondaryAnimation;if(!schemaSecondaryAnimation)return null;let schemaBoneGroups=schemaSecondaryAnimation==null?void 0:schemaSecondaryAnimation.boneGroups;if(!schemaBoneGroups)return null;let manager=new VRMSpringBoneManager,threeNodes=yield gltf.parser.getDependencies("node"),colliderGroups=(_c=schemaSecondaryAnimation.colliderGroups)==null?void 0:_c.map((schemaColliderGroup,iColliderGroup)=>{var _a2;let node=threeNodes[schemaColliderGroup.node];if(node==null)return console.warn(`VRMSpringBoneLoaderPlugin: The collider group #${iColliderGroup} attempted to reference a node #${schemaColliderGroup.node} but not found. Skipping the collider group`),null;return{colliders:((_a2=schemaColliderGroup.colliders)!=null?_a2:[]).map((schemaCollider,iCollider)=>{var _a3,_b2,_c2;let offset=new Vector3(0,0,0);if(schemaCollider.offset)offset.set((_a3=schemaCollider.offset.x)!=null?_a3:0,(_b2=schemaCollider.offset.y)!=null?_b2:0,schemaCollider.offset.z?-schemaCollider.offset.z:0);return this._importSphereCollider(node,{offset,radius:(_c2=schemaCollider.radius)!=null?_c2:0,inside:!1})})}});return schemaBoneGroups==null||schemaBoneGroups.forEach((schemaBoneGroup,iBoneGroup)=>{let rootIndices=schemaBoneGroup.bones;if(!rootIndices)return;rootIndices.forEach((rootIndex)=>{var _a2,_b2,_c2,_d;let root=threeNodes[rootIndex];if(root==null){console.warn(`VRMSpringBoneLoaderPlugin: The spring bone group #${iBoneGroup} attempted to reference a node #${rootIndex} but not found. Skipping the node`);return}let gravityDir=new Vector3;if(schemaBoneGroup.gravityDir)gravityDir.set((_a2=schemaBoneGroup.gravityDir.x)!=null?_a2:0,(_b2=schemaBoneGroup.gravityDir.y)!=null?_b2:0,(_c2=schemaBoneGroup.gravityDir.z)!=null?_c2:0);else gravityDir.set(0,-1,0);let center=schemaBoneGroup.center!=null?threeNodes[schemaBoneGroup.center]:void 0,setting={hitRadius:schemaBoneGroup.hitRadius,dragForce:schemaBoneGroup.dragForce,gravityPower:schemaBoneGroup.gravityPower,stiffness:schemaBoneGroup.stiffiness,gravityDir},colliderGroupsForSpring=(_d=schemaBoneGroup.colliderGroups)==null?void 0:_d.map((iColliderGroup)=>{let group=colliderGroups==null?void 0:colliderGroups[iColliderGroup];if(group==null)return console.warn(`VRMSpringBoneLoaderPlugin: The spring #${iBoneGroup} attempted to reference a collider group #${iColliderGroup} but not found. Skipping the collider group`),null;return group}).filter((group)=>group!=null);root.traverse((node)=>{var _a3;let child=(_a3=node.children[0])!=null?_a3:null,joint=this._importJoint(node,child,setting,colliderGroupsForSpring);if(center)joint.center=center;manager.addJoint(joint)})})}),gltf.scene.updateMatrixWorld(),manager.setInitState(),manager})}_importJoint(node,child,setting,colliderGroupsForSpring){let springBone=new VRMSpringBoneJoint(node,child,setting,colliderGroupsForSpring);if(this.jointHelperRoot){let helper=new VRMSpringBoneJointHelper(springBone);this.jointHelperRoot.add(helper),helper.renderOrder=this.jointHelperRoot.renderOrder}return springBone}_importSphereCollider(destination,params){let shape=new VRMSpringBoneColliderShapeSphere(params),collider=new VRMSpringBoneCollider(shape);if(destination.add(collider),this.colliderHelperRoot){let helper=new VRMSpringBoneColliderHelper(collider);this.colliderHelperRoot.add(helper),helper.renderOrder=this.colliderHelperRoot.renderOrder}return collider}_importCapsuleCollider(destination,params){let shape=new VRMSpringBoneColliderShapeCapsule(params),collider=new VRMSpringBoneCollider(shape);if(destination.add(collider),this.colliderHelperRoot){let helper=new VRMSpringBoneColliderHelper(collider);this.colliderHelperRoot.add(helper),helper.renderOrder=this.colliderHelperRoot.renderOrder}return collider}_importPlaneCollider(destination,params){let shape=new VRMSpringBoneColliderShapePlane(params),collider=new VRMSpringBoneCollider(shape);if(destination.add(collider),this.colliderHelperRoot){let helper=new VRMSpringBoneColliderHelper(collider);this.colliderHelperRoot.add(helper),helper.renderOrder=this.colliderHelperRoot.renderOrder}return collider}};_VRMSpringBoneLoaderPlugin.EXTENSION_NAME="VRMC_springBone";function collectMeshes(scene){let meshes=new Set;return scene.traverse((obj)=>{if(!obj.isMesh)return;let mesh=obj;meshes.add(mesh)}),meshes}function combineMorph(positionAttributes,binds,morphTargetsRelative){if(binds.size===1){let bind=binds.values().next().value;if(bind.weight===1)return positionAttributes[bind.index]}let newArray=new Float32Array(positionAttributes[0].count*3),weightSum=0;if(morphTargetsRelative)weightSum=1;else for(let bind of binds)weightSum+=bind.weight;for(let bind of binds){let src=positionAttributes[bind.index],weight=bind.weight/weightSum;for(let i=0;i<src.count;i++)newArray[i*3+0]+=src.getX(i)*weight,newArray[i*3+1]+=src.getY(i)*weight,newArray[i*3+2]+=src.getZ(i)*weight}return new BufferAttribute(newArray,3)}function combineMorphs(vrm){var _a;let meshes=collectMeshes(vrm.scene),meshNameBindSetMapMap=new Map,expressionMap=(_a=vrm.expressionManager)==null?void 0:_a.expressionMap;if(expressionMap!=null)for(let[expressionName,expression]of Object.entries(expressionMap)){let bindsToDeleteSet=new Set;for(let bind of expression.binds)if(bind instanceof VRMExpressionMorphTargetBind){if(bind.weight!==0)for(let mesh of bind.primitives){let nameBindSetMap=meshNameBindSetMapMap.get(mesh);if(nameBindSetMap==null)nameBindSetMap=new Map,meshNameBindSetMapMap.set(mesh,nameBindSetMap);let bindSet=nameBindSetMap.get(expressionName);if(bindSet==null)bindSet=new Set,nameBindSetMap.set(expressionName,bindSet);bindSet.add(bind)}bindsToDeleteSet.add(bind)}for(let bind of bindsToDeleteSet)expression.deleteBind(bind)}for(let mesh of meshes){let nameBindSetMap=meshNameBindSetMapMap.get(mesh);if(nameBindSetMap==null)continue;let originalMorphAttributes=mesh.geometry.morphAttributes;mesh.geometry.morphAttributes={};let geometry=mesh.geometry.clone();mesh.geometry=geometry;let morphTargetsRelative=geometry.morphTargetsRelative,hasPMorph=originalMorphAttributes.position!=null,hasNMorph=originalMorphAttributes.normal!=null,morphAttributes={},morphTargetDictionary={},morphTargetInfluences=[];if(hasPMorph||hasNMorph){if(hasPMorph)morphAttributes.position=[];if(hasNMorph)morphAttributes.normal=[];let i=0;for(let[name,bindSet]of nameBindSetMap){if(hasPMorph)morphAttributes.position[i]=combineMorph(originalMorphAttributes.position,bindSet,morphTargetsRelative);if(hasNMorph)morphAttributes.normal[i]=combineMorph(originalMorphAttributes.normal,bindSet,morphTargetsRelative);expressionMap==null||expressionMap[name].addBind(new VRMExpressionMorphTargetBind({index:i,weight:1,primitives:[mesh]})),morphTargetDictionary[name]=i,morphTargetInfluences.push(0),i++}}geometry.morphAttributes=morphAttributes,mesh.morphTargetDictionary=morphTargetDictionary,mesh.morphTargetInfluences=morphTargetInfluences}}function attributeGetComponentCompat(attribute,index,component){if(attribute.getComponent)return attribute.getComponent(index,component);else{let value=attribute.array[index*attribute.itemSize+component];if(attribute.normalized)value=MathUtils.denormalize(value,attribute.array);return value}}function attributeSetComponentCompat(attribute,index,component,value){if(attribute.setComponent)attribute.setComponent(index,component,value);else{if(attribute.normalized)value=MathUtils.normalize(value,attribute.array);attribute.array[index*attribute.itemSize+component]=value}}function combineSkeletons(root){var _a;let skinnedMeshes=collectSkinnedMeshes(root),geometries=new Set;for(let mesh of skinnedMeshes){if(geometries.has(mesh.geometry))mesh.geometry=shallowCloneBufferGeometry(mesh.geometry);geometries.add(mesh.geometry)}let attributeUsedIndexSetMap=new Map;for(let geometry of geometries){let skinIndexAttr=geometry.getAttribute("skinIndex"),skinIndexMap=(_a=attributeUsedIndexSetMap.get(skinIndexAttr))!=null?_a:new Map;attributeUsedIndexSetMap.set(skinIndexAttr,skinIndexMap);let skinWeightAttr=geometry.getAttribute("skinWeight"),usedIndicesSet=listUsedIndices(skinIndexAttr,skinWeightAttr);skinIndexMap.set(skinWeightAttr,usedIndicesSet)}let meshBoneInverseMapMap=new Map;for(let mesh of skinnedMeshes){let boneInverseMap=listUsedBones(mesh,attributeUsedIndexSetMap);meshBoneInverseMapMap.set(mesh,boneInverseMap)}let groups=[];for(let[mesh,boneInverseMap]of meshBoneInverseMapMap){let foundMergeableGroup=!1;for(let candidate of groups)if(boneInverseMapIsMergeable(boneInverseMap,candidate.boneInverseMap)){foundMergeableGroup=!0,candidate.meshes.add(mesh);for(let[bone,boneInverse]of boneInverseMap)candidate.boneInverseMap.set(bone,boneInverse);break}if(!foundMergeableGroup)groups.push({boneInverseMap,meshes:new Set([mesh])})}let cache=new Map,skinIndexDispatcher=new ObjectIndexDispatcher,skeletonDispatcher=new ObjectIndexDispatcher,boneDispatcher=new ObjectIndexDispatcher;for(let group of groups){let{boneInverseMap,meshes}=group,newBones=Array.from(boneInverseMap.keys()),newBoneInverses=Array.from(boneInverseMap.values()),newSkeleton=new Skeleton(newBones,newBoneInverses),skeletonKey=skeletonDispatcher.getOrCreate(newSkeleton);for(let mesh of meshes){let skinIndexAttr=mesh.geometry.getAttribute("skinIndex"),skinIndexKey=skinIndexDispatcher.getOrCreate(skinIndexAttr),bones=mesh.skeleton.bones,bonesKey=bones.map((bone)=>boneDispatcher.getOrCreate(bone)).join(","),key=`${skinIndexKey};${skeletonKey};${bonesKey}`,newSkinIndexAttr=cache.get(key);if(newSkinIndexAttr==null)newSkinIndexAttr=skinIndexAttr.clone(),remapSkinIndexAttribute(newSkinIndexAttr,bones,newBones),cache.set(key,newSkinIndexAttr);mesh.geometry.setAttribute("skinIndex",newSkinIndexAttr)}for(let mesh of meshes)mesh.bind(newSkeleton,new Matrix4)}}function collectSkinnedMeshes(scene){let skinnedMeshes=new Set;return scene.traverse((obj)=>{if(!obj.isSkinnedMesh)return;let skinnedMesh=obj;skinnedMeshes.add(skinnedMesh)}),skinnedMeshes}function listUsedIndices(skinIndexAttr,skinWeightAttr){let usedIndices=new Set;for(let i=0;i<skinIndexAttr.count;i++)for(let j=0;j<skinIndexAttr.itemSize;j++){let index=attributeGetComponentCompat(skinIndexAttr,i,j);if(attributeGetComponentCompat(skinWeightAttr,i,j)!==0)usedIndices.add(index)}return usedIndices}function listUsedBones(mesh,attributeUsedIndexSetMap){let boneInverseMap=new Map,skeleton=mesh.skeleton,geometry=mesh.geometry,skinIndexAttr=geometry.getAttribute("skinIndex"),skinWeightAttr=geometry.getAttribute("skinWeight"),skinIndexMap=attributeUsedIndexSetMap.get(skinIndexAttr),usedIndicesSet=skinIndexMap==null?void 0:skinIndexMap.get(skinWeightAttr);if(!usedIndicesSet)throw Error("Unreachable. attributeUsedIndexSetMap does not know the skin index attribute or the skin weight attribute.");for(let index of usedIndicesSet)boneInverseMap.set(skeleton.bones[index],skeleton.boneInverses[index]);return boneInverseMap}function boneInverseMapIsMergeable(toCheck,candidate){for(let[bone,boneInverse]of toCheck.entries()){let candidateBoneInverse=candidate.get(bone);if(candidateBoneInverse!=null){if(!matrixEquals(boneInverse,candidateBoneInverse))return!1}}return!0}function remapSkinIndexAttribute(attribute,oldBones,newBones){let boneOldIndexMap=new Map;for(let bone of oldBones)boneOldIndexMap.set(bone,boneOldIndexMap.size);let oldToNew=new Map;for(let[i,bone]of newBones.entries()){let oldIndex=boneOldIndexMap.get(bone);oldToNew.set(oldIndex,i)}for(let i=0;i<attribute.count;i++)for(let j=0;j<attribute.itemSize;j++){let oldIndex=attributeGetComponentCompat(attribute,i,j),newIndex=oldToNew.get(oldIndex);attributeSetComponentCompat(attribute,i,j,newIndex)}attribute.needsUpdate=!0}function matrixEquals(a,b,tolerance){if(tolerance=tolerance||0.0001,a.elements.length!=b.elements.length)return!1;for(let i=0,il=a.elements.length;i<il;i++)if(Math.abs(a.elements[i]-b.elements[i])>tolerance)return!1;return!0}var ObjectIndexDispatcher=class{constructor(){this._objectIndexMap=new Map,this._index=0}get(obj){return this._objectIndexMap.get(obj)}getOrCreate(obj){let index=this._objectIndexMap.get(obj);if(index==null)index=this._index,this._objectIndexMap.set(obj,index),this._index++;return index}};function shallowCloneBufferGeometry(geometry){var _a,_b,_c,_d;let clone=new BufferGeometry;clone.name=geometry.name,clone.setIndex(geometry.index);for(let[name,attribute]of Object.entries(geometry.attributes))clone.setAttribute(name,attribute);for(let[key,morphAttributes]of Object.entries(geometry.morphAttributes)){let attributeName=key;clone.morphAttributes[attributeName]=morphAttributes.concat()}clone.morphTargetsRelative=geometry.morphTargetsRelative,clone.groups=[];for(let group of geometry.groups)clone.addGroup(group.start,group.count,group.materialIndex);return clone.boundingSphere=(_b=(_a=geometry.boundingSphere)==null?void 0:_a.clone())!=null?_b:null,clone.boundingBox=(_d=(_c=geometry.boundingBox)==null?void 0:_c.clone())!=null?_d:null,clone.drawRange.start=geometry.drawRange.start,clone.drawRange.count=geometry.drawRange.count,clone.userData=geometry.userData,clone}function disposeMaterial(material){if(Object.values(material).forEach((value)=>{if(value==null?void 0:value.isTexture)value.dispose()}),material.isShaderMaterial){let uniforms=material.uniforms;if(uniforms)Object.values(uniforms).forEach((uniform)=>{let value=uniform.value;if(value==null?void 0:value.isTexture)value.dispose()})}material.dispose()}function dispose(object3D){let geometry=object3D.geometry;if(geometry)geometry.dispose();let skeleton=object3D.skeleton;if(skeleton)skeleton.dispose();let material=object3D.material;if(material){if(Array.isArray(material))material.forEach((material2)=>disposeMaterial(material2));else if(material)disposeMaterial(material)}}function deepDispose(object3D){object3D.traverse(dispose)}function removeUnnecessaryJoints(root,options){var _a,_b;console.warn("VRMUtils.removeUnnecessaryJoints: removeUnnecessaryJoints is deprecated. Use combineSkeletons instead. combineSkeletons contributes more to the performance improvement. This function will be removed in the next major version.");let experimentalSameBoneCounts=(_a=options==null?void 0:options.experimentalSameBoneCounts)!=null?_a:!1,skinnedMeshes=[];root.traverse((obj)=>{if(obj.type!=="SkinnedMesh")return;skinnedMeshes.push(obj)});let attributeToBoneIndexMapMap=new Map,maxBones=0;for(let mesh of skinnedMeshes){let attribute=mesh.geometry.getAttribute("skinIndex");if(attributeToBoneIndexMapMap.has(attribute))continue;let oldToNew=new Map,newToOld=new Map;for(let i=0;i<attribute.count;i++)for(let j=0;j<attribute.itemSize;j++){let oldIndex=attributeGetComponentCompat(attribute,i,j),newIndex=oldToNew.get(oldIndex);if(newIndex==null)newIndex=oldToNew.size,oldToNew.set(oldIndex,newIndex),newToOld.set(newIndex,oldIndex);attributeSetComponentCompat(attribute,i,j,newIndex)}attribute.needsUpdate=!0,attributeToBoneIndexMapMap.set(attribute,newToOld),maxBones=Math.max(maxBones,oldToNew.size)}for(let mesh of skinnedMeshes){let attribute=mesh.geometry.getAttribute("skinIndex"),newToOld=attributeToBoneIndexMapMap.get(attribute),bones=[],boneInverses=[],nBones=experimentalSameBoneCounts?maxBones:newToOld.size;for(let newIndex=0;newIndex<nBones;newIndex++){let oldIndex=(_b=newToOld.get(newIndex))!=null?_b:0;bones.push(mesh.skeleton.bones[oldIndex]),boneInverses.push(mesh.skeleton.boneInverses[oldIndex])}let skeleton=new Skeleton(bones,boneInverses);mesh.bind(skeleton,new Matrix4)}}function checkIsVertexUsed(attributes,originalIndex){let vertexCount=attributes.position.count,isVertexUsed=Array(vertexCount),verticesUsed=0,originalIndexArray=originalIndex.array;for(let i=0;i<originalIndexArray.length;i++){let index=originalIndexArray[i];if(!isVertexUsed[index])isVertexUsed[index]=!0,verticesUsed++}return{isVertexUsed,vertexCount,verticesUsed}}function buildIndexMapsFromIsVertexUsed(isVertexUsed){let originalIndexNewIndexMap=[],newIndexOriginalIndexMap=[],indexHead=0;for(let i=0;i<isVertexUsed.length;i++)if(isVertexUsed[i]){let newIndex=indexHead++;originalIndexNewIndexMap[i]=newIndex,newIndexOriginalIndexMap[newIndex]=i}return{originalIndexNewIndexMap,newIndexOriginalIndexMap}}function copyGeometryProperties(source,target){var _a,_b,_c,_d;target.name=source.name,target.morphTargetsRelative=source.morphTargetsRelative,source.groups.forEach((group)=>{target.addGroup(group.start,group.count,group.materialIndex)}),target.boundingBox=(_b=(_a=source.boundingBox)==null?void 0:_a.clone())!=null?_b:null,target.boundingSphere=(_d=(_c=source.boundingSphere)==null?void 0:_c.clone())!=null?_d:null,target.setDrawRange(source.drawRange.start,source.drawRange.count),target.userData=source.userData}function reorganizeIndexAttribute(newGeometry,originalIndex,originalIndexNewIndexMap){let originalIndexArray=originalIndex.array,newIndexArray=new originalIndexArray.constructor(originalIndexArray.length);for(let i=0;i<originalIndexArray.length;i++){let index=originalIndexArray[i];newIndexArray[i]=originalIndexNewIndexMap[index]}newGeometry.setIndex(new BufferAttribute(newIndexArray,originalIndex.itemSize,originalIndex.normalized))}function remapAttributeArray(originalArray,newIndexOriginalIndexMap,stride){let newArray=new originalArray.constructor(newIndexOriginalIndexMap.length*stride),isAllZero=!0;for(let i=0;i<newIndexOriginalIndexMap.length;i++){let srcBase=newIndexOriginalIndexMap[i]*stride,dstBase=i*stride;for(let j=0;j<stride;j++){let v=originalArray[srcBase+j];newArray[dstBase+j]=v,isAllZero=isAllZero&&v===0}}return[newArray,isAllZero]}function collectGeometryAttributeGroups(attributes){var _a;let interleavedBufferAttributeMap=new Map,nonInterleavedAttributes=[];for(let[attributeName,originalAttribute]of Object.entries(attributes))if(originalAttribute.isInterleavedBufferAttribute){let interleavedAttribute=originalAttribute,interleavedBuffer=interleavedAttribute.data,group=(_a=interleavedBufferAttributeMap.get(interleavedBuffer))!=null?_a:[];interleavedBufferAttributeMap.set(interleavedBuffer,group),group.push([attributeName,interleavedAttribute])}else{let attribute=originalAttribute;nonInterleavedAttributes.push([attributeName,attribute])}return[interleavedBufferAttributeMap,nonInterleavedAttributes]}function reorganizeGeometryAttributes(newGeometry,attributes,newIndexOriginalIndexMap){let[interleavedBufferAttributeMap,nonInterleavedAttributes]=collectGeometryAttributeGroups(attributes);for(let[interleavedBuffer,attributesInGroup]of interleavedBufferAttributeMap){let originalInterleavedBufferArray=interleavedBuffer.array,{stride}=interleavedBuffer,[newInterleavedArray,_]=remapAttributeArray(originalInterleavedBufferArray,newIndexOriginalIndexMap,stride),newInterleavedBuffer=new InterleavedBuffer(newInterleavedArray,stride);newInterleavedBuffer.setUsage(interleavedBuffer.usage);for(let[attributeName,originalAttribute]of attributesInGroup){let{itemSize,offset,normalized}=originalAttribute,newAttribute=new InterleavedBufferAttribute(newInterleavedBuffer,itemSize,offset,normalized);newGeometry.setAttribute(attributeName,newAttribute)}}for(let[attributeName,originalAttribute]of nonInterleavedAttributes){let originalAttributeArray=originalAttribute.array,{itemSize,normalized}=originalAttribute,[newAttributeArray,_]=remapAttributeArray(originalAttributeArray,newIndexOriginalIndexMap,itemSize);newGeometry.setAttribute(attributeName,new BufferAttribute(newAttributeArray,itemSize,normalized))}}function collectMorphAttributeGroups(morphAttributes){var _a;let interleavedBufferAttributeMap=new Map,nonInterleavedAttributes=[];for(let[key,attributes]of Object.entries(morphAttributes)){let attributeName=key;for(let iMorph=0;iMorph<attributes.length;iMorph++){let originalAttribute=attributes[iMorph];if(originalAttribute.isInterleavedBufferAttribute){let interleavedAttribute=originalAttribute,interleavedBuffer=interleavedAttribute.data,group=(_a=interleavedBufferAttributeMap.get(interleavedBuffer))!=null?_a:[];interleavedBufferAttributeMap.set(interleavedBuffer,group),group.push([attributeName,iMorph,interleavedAttribute])}else{let attribute=originalAttribute;nonInterleavedAttributes.push([attributeName,iMorph,attribute])}}}return[interleavedBufferAttributeMap,nonInterleavedAttributes]}function reorganizeMorphAttributes(newGeometry,morphAttributes,newIndexOriginalIndexMap){var _a,_b;let allMorphsAreZero=!0,[interleavedBufferAttributeMap,nonInterleavedAttributes]=collectMorphAttributeGroups(morphAttributes),newMorphAttributes={};for(let[interleavedBuffer,attributesInGroup]of interleavedBufferAttributeMap){let originalInterleavedBufferArray=interleavedBuffer.array,{stride}=interleavedBuffer,[newInterleavedArray,isAllZero]=remapAttributeArray(originalInterleavedBufferArray,newIndexOriginalIndexMap,stride);allMorphsAreZero=allMorphsAreZero&&isAllZero;let newInterleavedBuffer=new InterleavedBuffer(newInterleavedArray,stride);newInterleavedBuffer.setUsage(interleavedBuffer.usage);for(let[attributeName,morphIndex,attribute]of attributesInGroup){let{itemSize,offset,normalized}=attribute,newAttribute=new InterleavedBufferAttribute(newInterleavedBuffer,itemSize,offset,normalized);(_a=newMorphAttributes[attributeName])!=null||(newMorphAttributes[attributeName]=[]),newMorphAttributes[attributeName][morphIndex]=newAttribute}}for(let[attributeName,morphIndex,attribute]of nonInterleavedAttributes){let originalAttribute=attribute,originalAttributeArray=originalAttribute.array,{itemSize,normalized}=originalAttribute,[newAttributeArray,isAllZero]=remapAttributeArray(originalAttributeArray,newIndexOriginalIndexMap,itemSize);allMorphsAreZero=allMorphsAreZero&&isAllZero,(_b=newMorphAttributes[attributeName])!=null||(newMorphAttributes[attributeName]=[]),newMorphAttributes[attributeName][morphIndex]=new BufferAttribute(newAttributeArray,itemSize,normalized)}newGeometry.morphAttributes=allMorphsAreZero?{}:newMorphAttributes}function removeUnnecessaryVertices(root){let geometryMap=new Map;root.traverse((obj)=>{if(!obj.isMesh)return;let mesh=obj,geometry=mesh.geometry,originalIndex=geometry.index;if(originalIndex==null)return;let newGeometryAlreadyExisted=geometryMap.get(geometry);if(newGeometryAlreadyExisted!=null){mesh.geometry=newGeometryAlreadyExisted;return}let{isVertexUsed,vertexCount,verticesUsed}=checkIsVertexUsed(geometry.attributes,originalIndex);if(verticesUsed===vertexCount)return;let{originalIndexNewIndexMap,newIndexOriginalIndexMap}=buildIndexMapsFromIsVertexUsed(isVertexUsed),newGeometry=new BufferGeometry;copyGeometryProperties(geometry,newGeometry),geometryMap.set(geometry,newGeometry),reorganizeIndexAttribute(newGeometry,originalIndex,originalIndexNewIndexMap),reorganizeGeometryAttributes(newGeometry,geometry.attributes,newIndexOriginalIndexMap),reorganizeMorphAttributes(newGeometry,geometry.morphAttributes,newIndexOriginalIndexMap),mesh.geometry=newGeometry}),Array.from(geometryMap.keys()).forEach((originalGeometry)=>{originalGeometry.dispose()})}function rotateVRM0(vrm){var _a;if(((_a=vrm.meta)==null?void 0:_a.metaVersion)==="0")vrm.scene.rotation.y=Math.PI}var VRMUtils=class{constructor(){}};VRMUtils.combineMorphs=combineMorphs;VRMUtils.combineSkeletons=combineSkeletons;VRMUtils.deepDispose=deepDispose;VRMUtils.removeUnnecessaryJoints=removeUnnecessaryJoints;VRMUtils.removeUnnecessaryVertices=removeUnnecessaryVertices;VRMUtils.rotateVRM0=rotateVRM0;/*!
 * @pixiv/three-vrm-core v3.5.4
 * The implementation of core features of VRM, for @pixiv/three-vrm
 *
 * Copyright (c) 2019-2026 pixiv Inc.
 * @pixiv/three-vrm-core is distributed under MIT License
 * https://github.com/pixiv/three-vrm/blob/release/LICENSE
 *//*!
 * @pixiv/three-vrm-materials-mtoon v3.5.4
 * MToon (toon material) module for @pixiv/three-vrm
 *
 * Copyright (c) 2019-2026 pixiv Inc.
 * @pixiv/three-vrm-materials-mtoon is distributed under MIT License
 * https://github.com/pixiv/three-vrm/blob/release/LICENSE
 *//*!
 * @pixiv/three-vrm-materials-hdr-emissive-multiplier v3.5.4
 * Support VRMC_hdr_emissiveMultiplier for @pixiv/three-vrm
 *
 * Copyright (c) 2019-2026 pixiv Inc.
 * @pixiv/three-vrm-materials-hdr-emissive-multiplier is distributed under MIT License
 * https://github.com/pixiv/three-vrm/blob/release/LICENSE
 *//*!
 * @pixiv/three-vrm-materials-v0compat v3.5.4
 * VRM0.0 materials compatibility layer plugin for @pixiv/three-vrm
 *
 * Copyright (c) 2019-2026 pixiv Inc.
 * @pixiv/three-vrm-materials-v0compat is distributed under MIT License
 * https://github.com/pixiv/three-vrm/blob/release/LICENSE
 *//*!
 * @pixiv/three-vrm-node-constraint v3.5.4
 * Node constraint module for @pixiv/three-vrm
 *
 * Copyright (c) 2019-2026 pixiv Inc.
 * @pixiv/three-vrm-node-constraint is distributed under MIT License
 * https://github.com/pixiv/three-vrm/blob/release/LICENSE
 *//*!
 * @pixiv/three-vrm-springbone v3.5.4
 * Spring bone module for @pixiv/three-vrm
 *
 * Copyright (c) 2019-2026 pixiv Inc.
 * @pixiv/three-vrm-springbone is distributed under MIT License
 * https://github.com/pixiv/three-vrm/blob/release/LICENSE
 */function createHairPhysics(vrm,root,manifest,{THREE}){let manager=new VRMSpringBoneManager,owned=[],joints=[],scratch=new THREE.Vector3,inverseBinds=new Map;vrm.scene.traverse((o)=>{if(o.isSkinnedMesh){for(let i=0;i<o.skeleton.bones.length;i++)if(!inverseBinds.has(o.skeleton.bones[i]))inverseBinds.set(o.skeleton.bones[i],o.skeleton.boneInverses[i].clone())}});class Ellipsoid extends VRMSpringBoneColliderShape{constructor(radii){super();this.radii=new THREE.Vector3(...radii),this.base=this.radii.clone(),this.inverse=new THREE.Matrix4,this.local=new THREE.Vector3,this.normalMatrix=new THREE.Matrix3}calculateCollision(matrix,position,radius,target){this.local.copy(position).applyMatrix4(this.inverse.copy(matrix).invert());let r=this.radii,distance=(Math.hypot(this.local.x/r.x,this.local.y/r.y,this.local.z/r.z)-1)*Math.min(r.x,r.y,r.z)-radius;if(target.set(this.local.x/(r.x*r.x),this.local.y/(r.y*r.y),this.local.z/(r.z*r.z)),target.lengthSq()<0.0000000001)target.set(0,0,-1);return target.applyNormalMatrix(this.normalMatrix.getNormalMatrix(matrix)).normalize(),distance}}function collider(role,position,shape,name){let bone=vrm.humanoid.getRawBoneNode(role),inverse=inverseBinds.get(bone);if(!bone||!inverse)throw Error("Missing body bind for hair collider "+role);let c=new VRMSpringBoneCollider(shape);return c.name="DQ_HairCollider_"+name,c.matrix.copy(inverse).multiply(new THREE.Matrix4().makeTranslation(...position)),c.matrix.decompose(c.position,c.quaternion,c.scale),bone.add(c),owned.push(c),c}let ellipsoids=[collider("head",[0,1.67,-0.005],new Ellipsoid([0.088,0.123,0.102]),"head"),collider("neck",[0,1.5,-0.005],new Ellipsoid([0.067,0.095,0.074]),"neck"),collider("upperChest",[0,1.4,0.026],new Ellipsoid([0.21,0.225,0.205]),"chest"),collider("spine",[0,1.225,0.014],new Ellipsoid([0.17,0.185,0.16]),"waist"),collider("hips",[0,1.025,0.012],new Ellipsoid([0.25,0.22,0.215]),"pelvis"),collider("upperChest",[0,1.37,0.055],new Ellipsoid([0.19,0.145,0.21]),"front_chest")],backPlane=collider("upperChest",[0,1.38,-0.12],new VRMSpringBoneColliderShapePlane({normal:new THREE.Vector3(0,0,-1)}),"back_sidedness"),bodyGroup={name:"HumanFemale body collision",colliders:ellipsoids},frontGroup={name:"Front strands: neck and anatomical chest height",colliders:[ellipsoids[0],ellipsoids[1],ellipsoids[5],ellipsoids[3],ellipsoids[4]]},backGroup={name:"Posterior hair stays posterior to torso",colliders:[backPlane]};class ContactJoint extends VRMSpringBoneJoint{_collision(tail){for(let i=0;i<8;i++)super._collision(tail)}}for(let chain of manifest.chains||[]){let nodes=chain.bones.map((name)=>root.getObjectByName(name)||root.getObjectByName(THREE.PropertyBinding.sanitizeNodeName(name)));if(nodes.some((n)=>!n))throw Error("Missing native hair chain node "+chain.name);for(let i=0;i<nodes.length-1;i++){let name=chain.bones[i],back=chain.region==="back",parentHeight=chain.restHeads[name][1],childHeight=chain.restHeads[chain.bones[i+1]]?.[1]??parentHeight-0.05,height=back?parentHeight:Math.min(parentHeight,childHeight),groups=[back?bodyGroup:frontGroup];if(back&&height<1.62)groups.push(backGroup);let joint=new ContactJoint(nodes[i],nodes[i+1],{hitRadius:height>1.62?0.006:back?0.035:chain.region==="side"?0.045:0.015,stiffness:height>1.62?28:back?1.6:5,dragForce:0.92,gravityPower:height>1.62?0:back?2.8:1.8,gravityDir:new THREE.Vector3(0,-1,0)},groups);joint.center=vrm.scene,manager.addJoint(joint),joints.push({joint,chain:chain.name,region:chain.region,height})}}vrm.scene.updateMatrixWorld(!0),manager.setInitState();let composition=0,enabled=!0,updates=0,lastPose="";function poseSignature(){return composition+":"+owned.map((c)=>c.parent.matrixWorld.elements.join(",")).join("|")}function sizes(value){composition=Math.max(-1,Math.min(1,value||0));let full=Math.max(0,composition);for(let i=1;i<ellipsoids.length;i++){let shape=ellipsoids[i].shape;shape.radii.copy(shape.base),shape.radii.x*=1+full*0.19,shape.radii.z*=1+full*0.23}for(let item of joints)if(item.height<=1.62)item.joint.settings.hitRadius=(item.region==="back"?0.035:item.region==="side"?0.045:0.015)+full*(item.region==="back"?0.025:0.015)}function reset(){vrm.scene.updateMatrixWorld(!0),manager.reset();for(let i=0;i<18;i++)manager.update(0.016666666666666666);root.updateMatrixWorld(!0),lastPose=poseSignature()}function update(dt,options={}){enabled=options.enabled!==!1,sizes(options.composition??composition);let pose=poseSignature();if(dt<=0){if(pose!==lastPose)reset();return}if(!enabled)for(let i=0;i<4;i++){for(let{joint}of joints)joint._prevTail.copy(joint._currentTail);manager.update(0.016666666666666666)}else manager.update(Math.min(dt,0.03333333333333333));updates++,root.updateMatrixWorld(!0),lastPose=pose}function inspect(){return{joints:joints.length,colliders:owned.length,composition,enabled,updates,chains:(manifest.chains||[]).length,regions:joints.map(({joint,chain,region,height})=>({name:joint.bone.name,chain,region,height,position:joint.bone.getWorldPosition(scratch).toArray(),tail:joint.child.getWorldPosition(new THREE.Vector3).toArray(),rotation:joint.bone.quaternion.toArray()}))}}function dispose2(){for(let o of owned)o.removeFromParent();for(let{joint}of joints)manager.deleteJoint(joint),joint.center=null}return reset(),{update,reset,dispose:dispose2,inspect,manager}}
export{createHairPhysics};
