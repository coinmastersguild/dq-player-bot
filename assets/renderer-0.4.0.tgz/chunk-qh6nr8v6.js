var browserBuildId="f201d74a5e8c401991bb690719d1b74e",pending;function browserBuildEntries(){return pending??=fetch("/bundle/builds/f201d74a5e8c401991bb690719d1b74e/entrypoints.json").then(async(response)=>{if(!response.ok)throw Error("Browser build entrypoints unavailable");return response.json()})}
export{browserBuildId,browserBuildEntries};
