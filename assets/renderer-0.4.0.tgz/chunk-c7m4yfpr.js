import{OGRE_FEMALE_SURFACE_MARKS_GLSL}from"./chunk-gedq1zjm.js";var OGRE_FEMALE_SKIN_DEFAULTS=Object.freeze({mode:"source",color:"#6b5338"}),OGRE_FEMALE_SKIN_PRESETS=Object.freeze([Object.freeze({id:"source",label:"Original",mode:"source",color:"#6b5338"}),Object.freeze({id:"light",label:"Pearl",mode:"custom",color:"#baa47b"}),Object.freeze({id:"tan",label:"Warm tan",mode:"custom",color:"#947043"}),Object.freeze({id:"deep",label:"Umber",mode:"custom",color:"#443f2b"}),Object.freeze({id:"cool",label:"Cool ash",mode:"custom",color:"#738168"})]),OGRE_FEMALE_SKIN_REFERENCES=Object.freeze({"Female Ogre Body Runtime":"#695238","OgreFemale Head Runtime":"#705739"}),OGRE_FEMALE_SCAR_COLOR_DONORS=Object.freeze([{y:1.62298,uv:[0.1563274711,0.3141306639],rgb:[108,84,54]},{y:1.63168,uv:[0.1582517475,0.3169378638],rgb:[114,90,59]},{y:1.65553,uv:[0.7948476076,0.4968320131],rgb:[119,94,61]},{y:1.67505,uv:[0.7296755314,0.7066129446],rgb:[113,88,57]},{y:1.68357,uv:[0.4878966212,0.1045923829],rgb:[119,92,60]},{y:1.70443,uv:[0.8167705536,0.8502346277],rgb:[112,87,56]},{y:1.73097,uv:[0.7269241214,0.7266602516],rgb:[120,94,61]},{y:1.74975,uv:[0.7273609638,0.7334815264],rgb:[112,86,57]}].map((d)=>Object.freeze({...d,uv:Object.freeze(d.uv),rgb:Object.freeze(d.rgb)}))),scarDonorSample=(d)=>`texture2D(sourceMap,vec2(${d.uv.join(",")})).rgb`,SCAR_COLOR_GLSL=`
vec3 dqBrakkaScarLocalColor(float y,sampler2D sourceMap){
 ${OGRE_FEMALE_SCAR_COLOR_DONORS.slice(1).map((d,i)=>{let a=OGRE_FEMALE_SCAR_COLOR_DONORS[i];return`if(y<${d.y})return mix(${scarDonorSample(a)},${scarDonorSample(d)},smoothstep(${a.y},${d.y},y));`}).join(`
 `)}
 return ${scarDonorSample(OGRE_FEMALE_SCAR_COLOR_DONORS.at(-1))};
}
`,active=new WeakSet,own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);function validateOgreFemaleSkinTone(value,{current=OGRE_FEMALE_SKIN_DEFAULTS}={}){if(!value||typeof value!=="object"||Array.isArray(value))throw Error("Brakka skin tone must be an object.");for(let key of Object.keys(value))if(!["mode","color"].includes(key))throw Error("Unknown Brakka skin tone field: "+key);let next={...current};if(own(value,"mode")){if(!["source","custom"].includes(value.mode))throw Error("Invalid Brakka skin tone mode.");next.mode=value.mode}if(own(value,"color")){if(typeof value.color!=="string"||!/^#[0-9a-f]{6}$/i.test(value.color))throw Error("Brakka skin tone requires a six-digit hex color.");next.color=value.color.toLowerCase()}return next}var smooth=(a,b,x)=>{let t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)},linear=(rgb)=>rgb.map((x)=>x<=0.04045?x/12.92:((x+0.055)/1.055)**2.4);function ogreFemaleLipLuminanceScale(color,reference=linear([0.4392156862745098,0.3411764705882353,0.2235294117647059])){let lum=(c)=>0.2126*c[0]+0.7152*c[1]+0.0722*c[2];return Math.max(0.6,Math.min(1.12,Math.sqrt(Math.max(lum(color),0)/Math.max(lum(reference),0.0001))))}var lipWeight=([x,y,z],[r,g])=>(1-smooth(0.027,0.034,Math.abs(x)))*smooth(1.63,1.636,y)*(1-smooth(1.659,1.664,y))*smooth(0.072,0.084,z)*smooth(1.15,1.38,r/Math.max(g,0.005)/1.2873563218390804);function ogreFemaleSkinProtection([x,y,z],[r,g,b]){let ax=Math.abs(x),pigment=linear([r,g,b]),ref=linear([0.4392156862745098,0.3411764705882353,0.2235294117647059]),lum=(c)=>0.2126*c[0]+0.7152*c[1]+0.0722*c[2],brow=smooth(0.01,0.016,ax)*(1-smooth(0.061,0.07,ax))*smooth(1.724,1.731,y)*(1-smooth(1.748,1.755,y))*smooth(0.048,0.07,z),dark=1-smooth(0.24,0.37,lum(pigment)/lum(ref)),scalp=smooth(1.767,1.79,y)*(1-smooth(0.57,0.76,g/Math.max(r,0.005)));return Math.max(scalp,brow*dark,lipWeight([x,y,z],[r,g,b]))}function ogreFemalePaintCleanZone([x,y,z],[r,g,b],eligible=1){let ax=Math.abs(x),eye=smooth(0.01,0.016,ax)*(1-smooth(0.067,0.075,ax))*smooth(1.675,1.68,y)*(1-smooth(1.729,1.736,y))*smooth(0.02,0.035,z);eye*=1-(1-smooth(0.022,0.03,ax))*(1-smooth(1.697,1.705,y))*smooth(0.086,0.096,z);let neck=smooth(1.547,1.566,y)*(1-smooth(1.625,1.655,y))*(1-smooth(0.065,0.083,z)),black=1-smooth(0.38,0.45,Math.max(r,g,b)),scalp=Math.max(smooth(1.755,1.775,y),smooth(1.632,1.659,y)*(1-smooth(-0.04,-0.005,z)));return Math.max(eye*black,neck,scalp)*eligible}var GLSL=`
varying vec3 vDQBrakkaSkinPosition;
varying float vDQBrakkaPaintEligible;
vec3 dqBrakkaLinearToSrgb(vec3 c){return mix(c*12.92,1.055*pow(max(c,vec3(0.0)),vec3(1.0/2.4))-.055,step(vec3(.0031308),c));}
float dqBrakkaLipWeight(vec3 p,vec3 pigmentLinear){
 vec3 pigment=dqBrakkaLinearToSrgb(pigmentLinear);
 float lip=(1.0-smoothstep(.027,.034,abs(p.x)))*smoothstep(1.630,1.636,p.y)*(1.0-smoothstep(1.659,1.664,p.y))*smoothstep(.072,.084,p.z);
 return lip*smoothstep(1.15,1.38,(pigment.r/max(pigment.g,.005))/(112.0/87.0));
}
float dqBrakkaSkinProtection(vec3 p,vec3 pigmentLinear){
 vec3 pigment=dqBrakkaLinearToSrgb(pigmentLinear);float ax=abs(p.x);
 float brow=smoothstep(.010,.016,ax)*(1.0-smoothstep(.061,.070,ax))*smoothstep(1.724,1.731,p.y)*(1.0-smoothstep(1.748,1.755,p.y))*smoothstep(.048,.070,p.z);
 float relativeLight=dot(pigmentLinear,vec3(.2126,.7152,.0722))/max(dot(dqBrakkaSkinReference,vec3(.2126,.7152,.0722)),.005);
 float dark=1.0-smoothstep(.24,.37,relativeLight);
 float scalp=smoothstep(1.767,1.790,p.y)*(1.0-smoothstep(.57,.76,pigment.g/max(pigment.r,.005)));
 return max(max(scalp,brow*dark),dqBrakkaLipWeight(p,pigmentLinear));
}
`,PAINT_GLSL=`
float dqBrakkaPaintCleanZone(vec3 p,vec3 pigmentLinear,float eligible){
 vec3 pigment=dqBrakkaLinearToSrgb(pigmentLinear);
 float ax=abs(p.x);
 float eye=smoothstep(.010,.016,ax)*(1.0-smoothstep(.067,.075,ax))*smoothstep(1.675,1.680,p.y)*(1.0-smoothstep(1.729,1.736,p.y))*smoothstep(.020,.035,p.z);
 eye*=1.0-(1.0-smoothstep(.022,.030,ax))*(1.0-smoothstep(1.697,1.705,p.y))*smoothstep(.086,.096,p.z);
 float neck=smoothstep(1.547,1.566,p.y)*(1.0-smoothstep(1.625,1.655,p.y))*(1.0-smoothstep(.065,.083,p.z));
 float black=1.0-smoothstep(.38,.45,max(max(pigment.r,pigment.g),pigment.b));
 // Broad scalp/neck zones are independent of the painted silhouette.
 // The separate ear primitive has eligible=0, so this never clears ear pigment.
 float scalp=max(smoothstep(1.755,1.775,p.y),smoothstep(1.632,1.659,p.y)*(1.0-smoothstep(-.040,-.005,p.z)));
 return max(max(eye*black,neck),scalp)*eligible;
}
// Source overlay uses its actual pigment footprint, not the wider feathered
// cleanup zone; custom tattoo tint must never color the whole reconstructed neck.
float dqBrakkaNativePaintMask(vec3 p,vec3 pigmentLinear,float eligible){
 vec3 pigment=dqBrakkaLinearToSrgb(pigmentLinear);float ax=abs(p.x);
 float eye=smoothstep(.010,.016,ax)*(1.0-smoothstep(.067,.075,ax))*smoothstep(1.675,1.680,p.y)*(1.0-smoothstep(1.729,1.736,p.y))*smoothstep(.020,.035,p.z);
 eye*=1.0-(1.0-smoothstep(.022,.030,ax))*(1.0-smoothstep(1.697,1.705,p.y))*smoothstep(.086,.096,p.z);
 float neck=smoothstep(1.560,1.572,p.y)*(1.0-smoothstep(1.618,1.630,p.y));
 float black=1.0-smoothstep(.27,.39,max(max(pigment.r,pigment.g),pigment.b));
 float scalp=max(smoothstep(1.755,1.775,p.y),smoothstep(1.632,1.659,p.y)*(1.0-smoothstep(-.040,-.005,p.z)));
 float maroon=(1.0-smoothstep(.60,.76,pigment.g/max(pigment.r,.005)))*smoothstep(.50,.65,pigment.b/max(pigment.g,.005));
 return max(max(eye,neck)*black,scalp*maroon)*eligible;
}
vec3 dqBrakkaReconstructPaint(vec3 p,sampler2D sourceMap){
 // Unpainted central forehead sample measured from the exact repacked atlas:
 // native [0.0003807,1.7443813,0.097702] -> UV [.3983043,.2444575].
 // Reuse a tiny local patch for color grain; original tangent normal texture
 // supplies real source surface detail and is never flattened.
 vec2 donorUV=vec2(.3983043432,.2444574833)+vec2(p.x*.015,(p.y-1.720)*.007);
 vec3 donor=texture2D(sourceMap,donorUV).rgb;
 float neck=1.0-smoothstep(1.635,1.665,p.y);
 vec2 neckUV=vec2(.7088491917,.2381045818)+vec2(p.x*.004,(p.y-1.600)*.005);
 vec3 neckDonor=texture2D(sourceMap,neckUV).rgb;
 return mix(donor,neckDonor,neck);
}
`,MARKER="// DQ_SKIN_BASE_COLOR_TRANSFORM";function createOgreFemaleSkinTone(root,{THREE}={}){if(root=root?.scene??root,!root?.traverse||!THREE?.Color)throw Error("Brakka skin tone requires scene and THREE.");if(active.has(root))throw Error("Brakka skin tone is already attached.");let records=new Map,found=new Set,geometries=new Map;root.traverse((node)=>{if(!node.isMesh||node.userData.excludeFromSkinMarkings)return;for(let material of[].concat(node.material)){if(!own(OGRE_FEMALE_SKIN_REFERENCES,material?.name))continue;if(!material.map?.isTexture||!node.geometry.getAttribute("uv"))throw Error("Missing original Brakka skin map/UV.");if(!material.customProgramCacheKey.call(material).includes("|dq-skin-markings-v1"))throw Error("Create Brakka skin tone after skin markings.");if(!geometries.has(node.geometry)){let geometry=node.geometry,original=geometry.getAttribute("dqOgreFemaleSkinPosition");if(original||geometry.getAttribute("dqOgreFemalePaintEligible"))throw Error("Unexpected existing Brakka skin position attribute.");geometries.set(geometry,{original,position:geometry.attributes.position,paintEligible:material.name==="OgreFemale Head Runtime"&&geometry.attributes.position.count===24358})}if(found.add(material.name),records.has(material))continue;records.set(material,{material,head:material.name==="OgreFemale Head Runtime",compile:material.onBeforeCompile,key:material.customProgramCacheKey,map:material.map,normalMap:material.normalMap,color:material.color.clone(),reference:new THREE.Color(OGRE_FEMALE_SKIN_REFERENCES[material.name])})}});for(let name of Object.keys(OGRE_FEMALE_SKIN_REFERENCES))if(!found.has(name))throw Error("Missing Brakka skin role: "+name);for(let[geometry,r]of geometries)geometry.setAttribute("dqOgreFemaleSkinPosition",r.position.clone()),geometry.setAttribute("dqOgreFemalePaintEligible",new THREE.Float32BufferAttribute(new Float32Array(r.position.count).fill(r.paintEligible?1:0),1));let uniforms={dqBrakkaSkinAmount:{value:0},dqBrakkaSkinColor:{value:new THREE.Color(OGRE_FEMALE_SKIN_DEFAULTS.color)},dqBrakkaLipLuminanceScale:{value:1}};for(let r of records.values()){r.material.onBeforeCompile=function(shader,renderer){if(r.compile.call(this,shader,renderer),!shader.fragmentShader.includes(MARKER))throw Error("Missing Brakka skin base-color hook.");shader.vertexShader=`attribute vec3 dqOgreFemaleSkinPosition;
attribute float dqOgreFemalePaintEligible;
varying vec3 vDQBrakkaSkinPosition;
varying float vDQBrakkaPaintEligible;
`+shader.vertexShader.replace("#include <begin_vertex>",`vDQBrakkaSkinPosition=dqOgreFemaleSkinPosition;vDQBrakkaPaintEligible=dqOgreFemalePaintEligible;
#include <begin_vertex>`),Object.assign(shader.uniforms,uniforms,{dqBrakkaSkinReference:{value:r.reference}});let mask=r.head?"1.0-dqBrakkaSkinProtection(vDQBrakkaSkinPosition,dqSkinUntintedBase)":"1.0",transform=`
// Local clean reconstruction precedes tint and both source/custom marks.
${r.head?`float dqBrakkaProceduralPaint=dqBrakkaNativePaintMask(vDQBrakkaSkinPosition,texture2D(dqSkinSourceColor,vMapUv).rgb,vDQBrakkaPaintEligible);
float dqBrakkaPaintCleanup=dqBrakkaPaintCleanZone(vDQBrakkaSkinPosition,texture2D(dqSkinSourceColor,vMapUv).rgb,vDQBrakkaPaintEligible);
vec2 dqBrakkaSurfaceMasks=dqOgreSurfaceMarkMasks(vDQBrakkaSkinPosition,vDQBrakkaPaintEligible);
float dqBrakkaProceduralScarNormal=max(dqBrakkaSurfaceMasks.x,dqBrakkaSurfaceMasks.y);
// Preserve original lip pigment while treating bounded relief independently.
dqBrakkaSurfaceMasks*=1.0-dqBrakkaLipWeight(vDQBrakkaSkinPosition,texture2D(dqSkinSourceColor,vMapUv).rgb);
float dqBrakkaProceduralScar=max(dqBrakkaSurfaceMasks.x,dqBrakkaSurfaceMasks.y);
if(dqSkinActive>0.5){
 dqSkinUntintedBase=mix(dqSkinUntintedBase,dqBrakkaReconstructPaint(vDQBrakkaSkinPosition,dqSkinSourceColor)*diffuse,dqBrakkaPaintCleanup);
 vec2 dqBrakkaMouthDonorUV=vDQBrakkaSkinPosition.x<0.0?vec2(.73379476,.70160132):vec2(.79503305,.49895581);
 vec3 dqBrakkaMouthDonor=texture2D(dqSkinSourceColor,dqBrakkaMouthDonorUV).rgb*diffuse;
 vec3 dqBrakkaSlashDonor=dqBrakkaScarLocalColor(vDQBrakkaSkinPosition.y,dqSkinSourceColor)*diffuse;
 dqSkinUntintedBase=dqOgreReconstructMarkColor(dqSkinUntintedBase,dqBrakkaMouthDonor,dqBrakkaSurfaceMasks.x,0.0);
 dqSkinUntintedBase=dqOgreReconstructMarkColor(dqSkinUntintedBase,dqBrakkaSlashDonor,dqBrakkaSurfaceMasks.y,0.0);
 diffuseColor.rgb=dqSkinUntintedBase;
}`:""}
// Pigment changes precede marks. Their colors/detail use the untinted clean base.
float dqBrakkaSkinMask=${mask};
if(dqSkinActive<0.5)dqBrakkaSkinMask*=1.0-max(texture2D(dqSkinScarMask,vMapUv).r,texture2D(dqSkinTattooMask,vMapUv).r);
vec3 dqBrakkaAdaptedSkin=clamp(dqSkinUntintedBase*dqBrakkaSkinColor/max(dqBrakkaSkinReference,vec3(.0001)),0.0,1.0);
// Retain native lip hue/detail while allowing bounded brightness adaptation.
// This avoids pasting a light coral band onto deep custom skin. Source is exact.
float dqBrakkaLipMask=${r.head?"dqBrakkaLipWeight(vDQBrakkaSkinPosition,dqSkinUntintedBase)":"0.0"};
vec3 dqBrakkaSkinResult=mix(diffuseColor.rgb,dqBrakkaAdaptedSkin,dqBrakkaSkinMask);
dqBrakkaSkinResult+=diffuseColor.rgb*dqBrakkaLipMask*(dqBrakkaLipLuminanceScale-1.0);
diffuseColor.rgb=mix(diffuseColor.rgb,dqBrakkaSkinResult,dqBrakkaSkinAmount);
`;if(shader.fragmentShader=`uniform float dqBrakkaSkinAmount;
uniform vec3 dqBrakkaSkinColor;
uniform vec3 dqBrakkaSkinReference;
uniform float dqBrakkaLipLuminanceScale;
`+GLSL+(r.head?PAINT_GLSL+SCAR_COLOR_GLSL+OGRE_FEMALE_SURFACE_MARKS_GLSL:"")+shader.fragmentShader.replace(MARKER,MARKER+`
`+transform),r.head)shader.fragmentShader=shader.fragmentShader.replace("float tattooMask=texture2D(dqSkinTattooMask,vMapUv).r;","float tattooMask=max(texture2D(dqSkinTattooMask,vMapUv).r,dqBrakkaProceduralPaint);"),shader.fragmentShader=shader.fragmentShader.replace("float scarMask=texture2D(dqSkinScarMask,vMapUv).r;","float scarMask=max(texture2D(dqSkinScarMask,vMapUv).r,dqBrakkaProceduralScar);"),shader.fragmentShader=shader.fragmentShader.replace("mapN.xy *= normalScale;",`mapN.xy *= normalScale;
if(dqSkinActive>0.5)mapN=dqOgreReconstructMarkNormal(mapN,dqBrakkaProceduralScarNormal,dqSkinScarRelief);`)};let key=r.key.call(r.material);r.material.customProgramCacheKey=()=>key+"|dq-brakka-skin-tone-v7-local-scar-color-"+r.material.name,r.material.needsUpdate=!0}let current={...OGRE_FEMALE_SKIN_DEFAULTS},disposed=!1;active.add(root);function set(value){if(disposed)throw Error("Brakka skin tone is disposed.");let next=validateOgreFemaleSkinTone(value,{current});return current=next,uniforms.dqBrakkaSkinAmount.value=next.mode==="custom"?1:0,uniforms.dqBrakkaSkinColor.value.set(next.color),uniforms.dqBrakkaLipLuminanceScale.value=next.mode==="custom"?ogreFemaleLipLuminanceScale(uniforms.dqBrakkaSkinColor.value.toArray()):1,{...current}}function inspect(){return{revision:"brakka-skin-tone-v7-local-scar-color",state:{...current},disposed,method:"linear RGB pigment adaptation with separate measured native head/body references preserving texture detail",sourceMapsUnmodified:!0,proceduralSourcePaint:!0,proceduralScarRelief:!0,scarRegions:["mouth-corner inherited color/normal traces","forehead/nose scar-like trace"],normalsOutsideScarFootprintsUnchanged:!0,paintRegions:["eye bands","neck band","scalp underpaint"],paintMethod:"bounded eye pigment plus feathered spatial scalp/neck cleanup; calibrated local forehead/neck color samples; separate source paint overlay footprint",paintUsesSourceTattooControls:!0,marksUseUntintedDetail:!0,bakedBrowDarkPigmentProtected:!0,lipPigmentProtected:!0,lipCustomLuminanceScale:disposed?1:uniforms.dqBrakkaLipLuminanceScale.value,accessoriesNailsExcluded:!0,teethEyesHairCoverageExcluded:!0,materials:[...records.values()].map((r)=>({name:r.material.name,amount:disposed?0:uniforms.dqBrakkaSkinAmount.value,reference:"#"+r.reference.getHexString(),mapUuid:r.material.map.uuid,normalMapPreserved:r.material.normalMap===r.normalMap,materialColorPreserved:r.material.color.equals(r.color)}))}}function dispose(){if(disposed)return;for(let r of records.values())r.material.onBeforeCompile=r.compile,r.material.customProgramCacheKey=r.key,r.material.needsUpdate=!0;for(let[geometry,r]of geometries){if(r.original)geometry.setAttribute("dqOgreFemaleSkinPosition",r.original);else geometry.deleteAttribute("dqOgreFemaleSkinPosition");geometry.deleteAttribute("dqOgreFemalePaintEligible")}current={...OGRE_FEMALE_SKIN_DEFAULTS},disposed=!0,active.delete(root)}return{set,state:()=>({...current}),inspect,dispose}}
export{OGRE_FEMALE_SKIN_DEFAULTS,OGRE_FEMALE_SKIN_PRESETS,OGRE_FEMALE_SKIN_REFERENCES,OGRE_FEMALE_SCAR_COLOR_DONORS,validateOgreFemaleSkinTone,ogreFemaleLipLuminanceScale,ogreFemaleSkinProtection,ogreFemalePaintCleanZone,createOgreFemaleSkinTone};
