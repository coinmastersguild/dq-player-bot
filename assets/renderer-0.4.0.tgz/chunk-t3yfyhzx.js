import{appearanceMaterialRole,createAppearanceController}from"./chunk-an7xxq59.js";import"./chunk-c8spxrqh.js";import"./chunk-7jhxxf1p.js";export{createAppearanceController,appearanceMaterialRole};
